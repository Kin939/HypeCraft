package com.hardcorerevival.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** /revive — player commands, /revivaladmin — admin commands. */
public class HrCommands implements CommandExecutor, TabCompleter {

    private final HardcoreRevivalPlugin plugin;

    public HrCommands(HardcoreRevivalPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("revive")) {
            return handleRevive(sender, args);
        }
        return handleAdmin(sender, args);
    }

    private boolean handleRevive(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Component.text("Только для игроков.", NamedTextColor.RED));
            return true;
        }
        String sub = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "";
        switch (sub) {
            case "time", "status" -> RevivalLogic.status(p, plugin);
            case "star" -> {
                var map = plugin.store().starDropSnapshot();
                long now = System.currentTimeMillis();
                p.sendMessage(Component.text("— Таймеры звёзд по мирам —", NamedTextColor.DARK_PURPLE));
                if (map.isEmpty()) {
                    p.sendMessage(Component.text("  ни у одного мира таймер не запущен — звезда доступна",
                            NamedTextColor.GRAY));
                } else {
                    String current = p.getWorld().getName();
                    for (var e : map.entrySet()) {
                        long left = e.getValue() - now;
                        String status = left <= 0 ? "✅ звезда доступна"
                                : "⏳ доступно через: " + Effects.formatDuration(left);
                        String here = e.getKey().equals(current) ? " (ты здесь)" : "";
                        p.sendMessage(Component.text("  " + prettyWorld(e.getKey()) + here + ": " + status,
                                NamedTextColor.GRAY));
                    }
                }
                p.sendMessage(Component.text("Убей иссушителя — звезда попадёт сразу в инвентарь.",
                        NamedTextColor.DARK_GRAY));
            }
            case "list", "" -> {
                if (!plugin.store().isDead(p.getUniqueId())) {
                    RevivalLogic.openMenu(plugin, p);
                } else {
                    RevivalLogic.status(p, plugin);
                }
            }
            default -> p.sendMessage(Component.text("Использование: /revive [time]", NamedTextColor.GRAY));
        }
        return true;
    }

    /** Дружелюбное имя мира для игроков. */
    private static String prettyWorld(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.equals("world")) return "Обычный мир";
        if (n.contains("nether")) return "Незер";
        if (n.contains("end")) return "Энд";
        if (n.contains("test")) return "Песочница";
        return name;
    }

    private boolean handleAdmin(CommandSender sender, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(Component.text("Использование: /revivaladmin <revive|reviveall|spectate|settime|clear|star|unglow|reload> [ник] [сек]",
                    NamedTextColor.GRAY));
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);

        if (sub.equals("reload")) {
            plugin.reloadAll();
            sender.sendMessage(Component.text("✅ Конфиг перезагружен.", NamedTextColor.GREEN));
            return true;
        }
        // Эти подкоманды работают без ника.
        boolean nickless = sub.equals("reload") || sub.equals("star")
                || sub.equals("reviveall") || sub.equals("unglow");
        if (!nickless && args.length < 2) {
            sender.sendMessage(Component.text("⚠ Укажи ник игрока.", NamedTextColor.YELLOW));
            return true;
        }
        String name = args.length >= 2 ? args[1] : null;

        switch (sub) {
            case "revive" -> {
                if (name.equalsIgnoreCase("all")) {
                    reviveAll(sender);
                    return true;
                }
                UUID target = plugin.store().findDeadByName(name);
                if (target == null) {
                    sender.sendMessage(Component.text("⚠ \"" + name + "\" не найден среди мёртвых.", NamedTextColor.YELLOW));
                    return true;
                }
                Location near = sender instanceof Player sp ? sp.getLocation() : null;
                Revival.revive(plugin, target, near, " (возрождён администратором)");
                sender.sendMessage(Component.text("✅ Возрождён: " + plugin.store().deathName(target), NamedTextColor.GREEN));
            }
            case "spectate" -> {
                Player target = Bukkit.getPlayer(name);
                if (target == null) {
                    sender.sendMessage(Component.text("⚠ Игрок \"" + name + "\" не в сети.", NamedTextColor.YELLOW));
                    return true;
                }
                plugin.store().addDeath(target.getUniqueId(),
                        System.currentTimeMillis() + plugin.cfg().deathDurationMs(), target.getName());
                Revival.placeSpectator(plugin, target);
                sender.sendMessage(Component.text("☠ " + target.getName() + " отправлен наблюдателем.", NamedTextColor.GREEN));
            }
            case "settime" -> {
                if (args.length < 3) {
                    sender.sendMessage(Component.text("⚠ Использование: /revivaladmin settime <ник> <секунды>", NamedTextColor.YELLOW));
                    return true;
                }
                Player target = Bukkit.getPlayer(name);
                if (target == null) {
                    sender.sendMessage(Component.text("⚠ Игрок \"" + name + "\" не в сети.", NamedTextColor.YELLOW));
                    return true;
                }
                long seconds;
                try {
                    seconds = Long.parseLong(args[2]);
                } catch (NumberFormatException ex) {
                    sender.sendMessage(Component.text("⚠ Нужны секунды числом.", NamedTextColor.YELLOW));
                    return true;
                }
                if (!plugin.store().isDead(target.getUniqueId())) {
                    sender.sendMessage(Component.text("⚠ " + target.getName() + " не мёртв.", NamedTextColor.YELLOW));
                    return true;
                }
                plugin.store().addDeath(target.getUniqueId(),
                        System.currentTimeMillis() + seconds * 1000L, target.getName());
                sender.sendMessage(Component.text("⏱ Осталось: " + Effects.formatDuration(seconds * 1000L),
                        NamedTextColor.GREEN));
            }
            case "clear" -> {
                UUID target = plugin.store().findDeadByName(name);
                Player online = Bukkit.getPlayer(name);
                UUID id = online != null ? online.getUniqueId() : target;
                if (id == null) {
                    sender.sendMessage(Component.text("⚠ Игрок не найден.", NamedTextColor.YELLOW));
                    return true;
                }
                plugin.store().removeDeath(id);
                plugin.store().removeProtection(id);
                plugin.store().consumeReviveNextTo(id);
                if (online != null) {
                    plugin.ghostWatch().remove(online.getUniqueId());
                    online.setInvisible(false);
                    Ghost.removeVisuals(plugin, online);
                    try {
                        if (online.getSpectatorTarget() != null) online.setSpectatorTarget(null);
                    } catch (Throwable ignored) {
                    }
                    online.setGameMode(Bukkit.getDefaultGameMode());
                    online.teleport(Revival.worldSpawnSafe());
                }
                sender.sendMessage(Component.text("✅ Состояние сброшено: "
                        + (online != null ? online.getName() : name), NamedTextColor.GREEN));
            }
            case "unglow" -> {
                // Аварийный сброс свечения (например, застрявшего после старой версии или рестарта).
                Player target;
                if (name == null) {
                    if (!(sender instanceof Player sp)) {
                        sender.sendMessage(Component.text("⚠ Использование: /revivaladmin unglow <ник>",
                                NamedTextColor.YELLOW));
                        return true;
                    }
                    target = sp;
                } else {
                    target = Bukkit.getPlayer(name);
                    if (target == null) {
                        sender.sendMessage(Component.text("⚠ Игрок \"" + name + "\" не в сети.",
                                NamedTextColor.YELLOW));
                        return true;
                    }
                }
                plugin.starGlow().remove(target.getUniqueId());
                target.setGlowing(false);
                target.removePotionEffect(org.bukkit.potion.PotionEffectType.GLOWING);
                sender.sendMessage(Component.text("✨ Свечение сброшено: " + target.getName(), NamedTextColor.GREEN));
            }
            case "reviveall" -> reviveAll(sender);
            case "star" -> {
                // /revivaladmin star                  — статус таймеров по мирам
                // /revivaladmin star reset <мир|all>  — сброс таймера
                var store = plugin.store();
                if (args.length < 2 || args[1].equalsIgnoreCase("status")) {
                    var map = store.starDropSnapshot();
                    long now = System.currentTimeMillis();
                    sender.sendMessage(Component.text("— Таймеры звёзд по мирам —", NamedTextColor.DARK_PURPLE));
                    if (map.isEmpty()) {
                        sender.sendMessage(Component.text(
                                "  ни у одного мира таймер не запущен — звезда доступна", NamedTextColor.GRAY));
                    } else {
                        for (var e : map.entrySet()) {
                            long left = e.getValue() - now;
                            sender.sendMessage(Component.text("  " + e.getKey() + ": "
                                    + (left > 0 ? Effects.formatDuration(left) : "готово"), NamedTextColor.GRAY));
                        }
                    }
                    sender.sendMessage(Component.text("  Сброс: /revivaladmin star reset <мир|all>",
                            NamedTextColor.DARK_GRAY));
                    return true;
                }
                if (args[1].equalsIgnoreCase("reset")) {
                    if (args.length < 3) {
                        sender.sendMessage(Component.text(
                                "Использование: /revivaladmin star reset <мир|all>", NamedTextColor.GRAY));
                        return true;
                    }
                    String target = args[2];
                    if (target.equalsIgnoreCase("all")) {
                        int n = store.starDropSnapshot().size();
                        store.resetAllStarDrops();
                        sender.sendMessage(Component.text(
                                "✅ Таймеры сброшены во всех мирах (" + n + ").", NamedTextColor.GREEN));
                    } else {
                        store.resetStarDrop(target);
                        sender.sendMessage(Component.text(
                                "✅ Таймер сброшен для мира \"" + target + "\".", NamedTextColor.GREEN));
                    }
                    return true;
                }
                sender.sendMessage(Component.text("Использование: /revivaladmin star [reset <мир|all>]",
                        NamedTextColor.GRAY));
            }
            default -> sender.sendMessage(Component.text("⚠ Неизвестная подкоманда.", NamedTextColor.YELLOW));
        }
        return true;
    }

    /** Возродить всех мёртвых сразу (онлайн + оффлайн). */
    private boolean reviveAll(CommandSender sender) {
        var dead = plugin.store().deadSorted();
        if (dead.isEmpty()) {
            sender.sendMessage(Component.text("ℹ Мёртвых нет — все живы.", NamedTextColor.GRAY));
            return true;
        }
        Location near = sender instanceof Player sp ? sp.getLocation() : null;
        int online = 0, offline = 0;
        for (var e : dead) {
            UUID target = e.getKey();
            Player tp = Bukkit.getPlayer(target);
            boolean wasOnline = tp != null && tp.isOnline();
            Revival.revive(plugin, target, near, " (массовое возрождение)");
            if (wasOnline) online++;
            else offline++;
        }
        ReviveMenu.refreshAll();
        sender.sendMessage(Component.text("✅ Возрождено: " + (online + offline)
                + (offline > 0 ? " (оффлайн: " + offline + " — появятся на спавне при входе)" : ""),
                NamedTextColor.GREEN));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (cmd.getName().equalsIgnoreCase("revive")) {
            if (args.length == 1) return List.of("time", "star");
            return List.of();
        }
        if (args.length == 1) {
            return List.of("revive", "reviveall", "spectate", "settime", "clear", "star", "unglow", "reload").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        if (args.length == 2) {
            var names = new java.util.ArrayList<String>();
            if (args[0].equalsIgnoreCase("revive")) names.add("all");
            Bukkit.getOnlinePlayers().stream().map(Player::getName).forEach(names::add);
            return names.stream()
                    .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        return List.of();
    }
}
