package com.hardcorerevival.paper;

import org.bukkit.configuration.file.FileConfiguration;

/** Typed view over config.yml. */
public final class HrConfig {

    private final FileConfiguration raw;

    public HrConfig(HardcoreRevivalPlugin plugin) {
        this.raw = plugin.getConfig();
    }

    public void refresh(HardcoreRevivalPlugin plugin) {
        plugin.reloadConfig();
    }

    public long deathDurationMs() {
        return (long) (raw.getDouble("death.duration-hours", 72.0) * 3_600_000.0);
    }

    public long protectionMs() {
        return (long) (raw.getDouble("protection.duration-minutes", 60.0) * 60_000.0);
    }

    public int spectatorRadius() {
        return raw.getInt("spectator.radius-blocks", 100);
    }

    public boolean consumeStarOnRevive() {
        return raw.getBoolean("revive.consume-nether-star", true);
    }

    public boolean starSaveEnabled() {
        return raw.getBoolean("star-save.enabled", true);
    }

    public boolean starSaveConsume() {
        return raw.getBoolean("star-save.consume-star", true);
    }

    public long witherCooldownMs() {
        return (long) (raw.getDouble("wither.star-cooldown-hours", 24.0) * 3_600_000.0);
    }

    public boolean broadcast() {
        return raw.getBoolean("broadcast", true);
    }
}
