package com.necromancer.paper;

import org.bukkit.NamespacedKey;

/** Ключи PDC для предметов некроманта и его миньонов. */
public final class NecroKeys {

    public static NamespacedKey KIND;    // "flower" | "head" | "pet"
    public static NamespacedKey OWNER;   // UUID некроманта
    public static NamespacedKey MOB;     // тип моба (enum name)
    public static NamespacedKey LVL;     // уровень 0..4
    public static NamespacedKey UID;     // уникальный id головы (чтобы не стакались)
    public static NamespacedKey MODE;    // "hunt" | "patrol"
    public static NamespacedKey TARGET;  // UUID цели охоты
    public static NamespacedKey ANCHOR;  // "world;x;y;z" точка патруля

    private NecroKeys() {}

    static void init(NecromancerPlugin plugin) {
        KIND = new NamespacedKey(plugin, "kind");
        OWNER = new NamespacedKey(plugin, "owner");
        MOB = new NamespacedKey(plugin, "mob");
        LVL = new NamespacedKey(plugin, "lvl");
        UID = new NamespacedKey(plugin, "uid");
        MODE = new NamespacedKey(plugin, "mode");
        TARGET = new NamespacedKey(plugin, "target");
        ANCHOR = new NamespacedKey(plugin, "anchor");
    }
}
