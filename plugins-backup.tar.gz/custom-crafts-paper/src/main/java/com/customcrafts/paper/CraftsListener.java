package com.customcrafts.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Light;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.hanging.HangingBreakEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Дебаг-стик (только декор), невидимый свет, невидимая рамка. */
public final class CraftsListener implements Listener {

    /** Возможные значения декоративных свойств (порядок = порядок переключения). */
    private static final Map<String, List<String>> DECOR_PROPS = new LinkedHashMap<>();

    /** Блоки, которые палочкой трогать нельзя (технические/опасные). */
    private static final List<String> BLOCKED_BLOCKS = List.of(
            "PISTON", "OBSERVER", "REDSTONE", "REPEATER", "COMPARATOR", "DISPENSER",
            "DROPPER", "HOPPER", "TNT", "SPAWNER", "BEACON", "COMMAND", "STRUCTURE",
            "JIGSAW", "PORTAL", "SHRIEKER", "_BED", "CHEST", "_DOOR", "DAYLIGHT",
            "NOTE", "LECTERN", "COMPOSTER", "BEEHIVE", "BEE_NEST", "SCULK_SENSOR",
            "SCULK_CATALYST", "CAULDRON", "TRIPWIRE", "TARGET", "CRAFTER");

    /** Выбранное свойство игрока (переживает клики в этой сессии). */
    private final Map<UUID, String> selected = new ConcurrentHashMap<>();
    private final Map<UUID, Long> cooldown = new ConcurrentHashMap<>();

    static {
        DECOR_PROPS.put("facing", List.of("north", "east", "south", "west", "up", "down"));
        DECOR_PROPS.put("face", List.of("floor", "wall", "ceiling"));
        DECOR_PROPS.put("rotation", List.of("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"));
        DECOR_PROPS.put("axis", List.of("x", "y", "z"));
        DECOR_PROPS.put("half", List.of("top", "bottom", "upper", "lower"));
        DECOR_PROPS.put("shape", List.of("straight", "inner_left", "inner_right", "outer_left", "outer_right",
                "north_south", "east_west", "ascending_east", "ascending_west", "ascending_north", "ascending_south"));
        DECOR_PROPS.put("type", List.of("top", "bottom", "double", "single", "left", "right"));
        DECOR_PROPS.put("hanging", List.of("true", "false"));
        DECOR_PROPS.put("attachment", List.of("floor", "ceiling", "single_wall", "double_wall"));
        DECOR_PROPS.put("open", List.of("true", "false"));
        DECOR_PROPS.put("hinge", List.of("left", "right"));
        DECOR_PROPS.put("candles", List.of("1", "2", "3", "4"));
        DECOR_PROPS.put("pickles", List.of("1", "2", "3", "4"));
        DECOR_PROPS.put("layers", List.of("1", "2", "3", "4", "5", "6", "7", "8"));
    }

    private final CraftsPlugin plugin;

    public CraftsListener(CraftsPlugin plugin) {
        this.plugin = plugin;
    }

    /* ================= дебаг-стик ================= */

    private boolean usable(Block b) {
        String name = b.getType().name().toUpperCase(Locale.ROOT);
        for (String bad : BLOCKED_BLOCKS) {
            if (name.contains(bad)) return false;
        }
        return true;
    }

    private LinkedHashMap<String, String> parseProps(BlockData data) {
        LinkedHashMap<String, String> props = new LinkedHashMap<>();
        String s = data.getAsString();
        int l = s.indexOf('['), r = s.lastIndexOf(']');
        if (l < 0 || r < l) return props;
        for (String pair : s.substring(l + 1, r).split(",")) {
            String[] kv = pair.split("=", 2);
            if (kv.length == 2) props.put(kv[0].trim(), kv[1].trim());
        }
        return props;
    }

    private List<String> decorPropsOf(LinkedHashMap<String, String> props) {
        List<String> list = new ArrayList<>();
        for (String k : props.keySet()) {
            if (DECOR_PROPS.containsKey(k)) list.add(k);
        }
        return list;
    }

    private void apply(Block b, LinkedHashMap<String, String> props) {
        StringBuilder sb = new StringBuilder();
        for (var e : props.entrySet()) {
            if (sb.length() > 0) sb.append(',');
            sb.append(e.getKey()).append('=').append(e.getValue());
        }
        BlockData nd = org.bukkit.Bukkit.createBlockData(b.getType(), "[" + sb + "]");
        b.setBlockData(nd);
    }

    private void handleStick(Player p, Block b, boolean left, boolean sneak) {
        if (!usable(b)) {
            p.sendActionBar(Component.text("⚠ Этот блок нельзя настраивать", NamedTextColor.RED));
            return;
        }
        LinkedHashMap<String, String> props = parseProps(b.getBlockData());
        List<String> decor = decorPropsOf(props);
        if (decor.isEmpty()) {
            p.sendActionBar(Component.text("⚠ У блока нет декоративных свойств", NamedTextColor.YELLOW));
            return;
        }
        String cur = selected.get(p.getUniqueId());
        if (cur == null || !decor.contains(cur)) cur = decor.get(0);

        if (sneak) {
            // Выбор свойства: вперёд (Shift+ПКМ) или назад (Shift+ЛКМ).
            int i = decor.indexOf(cur);
            int n = left ? (i - 1 + decor.size()) % decor.size() : (i + 1) % decor.size();
            String next = decor.get(n);
            selected.put(p.getUniqueId(), next);
            p.sendActionBar(Component.text("🪄 Свойство: " + next + " = " + props.get(next)
                    + "  (" + (n + 1) + "/" + decor.size() + ")", NamedTextColor.LIGHT_PURPLE));
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.4f, 1.4f);
            return;
        }

        // Циклическое изменение значения текущего свойства.
        List<String> candidates = DECOR_PROPS.get(cur);
        int from = candidates.indexOf(props.get(cur));
        for (int step = 1; step <= candidates.size(); step++) {
            String candidate = candidates.get(((from < 0 ? 0 : from) + step) % candidates.size());
            LinkedHashMap<String, String> copy = new LinkedHashMap<>(props);
            copy.put(cur, candidate);
            try {
                apply(b, copy);
            } catch (IllegalArgumentException ignored) {
                continue; // у этого блока такого значения нет — пробуем следующее
            }
            selected.put(p.getUniqueId(), cur);
            p.sendActionBar(Component.text("🪄 " + cur + " = " + candidate, NamedTextColor.GREEN));
            p.playSound(p.getLocation(), Sound.BLOCK_STONE_BUTTON_CLICK_ON, 0.5f, 1.6f);
            return;
        }
        p.sendActionBar(Component.text("⚠ Значение не изменилось", NamedTextColor.YELLOW));
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        ItemStack it = e.getItem();
        if (it == null || !"debug_stick".equals(CraftsItems.kindOf(it))) return;
        Action a = e.getAction();
        if (a != Action.LEFT_CLICK_BLOCK && a != Action.RIGHT_CLICK_BLOCK) return;
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) return;

        long now = System.currentTimeMillis();
        long last = cooldown.getOrDefault(e.getPlayer().getUniqueId(), 0L);
        if (now - last < plugin.cooldownMs()) return;
        cooldown.put(e.getPlayer().getUniqueId(), now);

        handleStick(e.getPlayer(), e.getClickedBlock(),
                a == Action.LEFT_CLICK_BLOCK, e.getPlayer().isSneaking());
    }

    /* ================= невидимый свет ================= */

    @EventHandler(ignoreCancelled = true)
    public void onLightPlace(BlockPlaceEvent e) {
        if (!"invis_light".equals(CraftsItems.kindOf(e.getItemInHand()))) return;
        if (e.getBlockPlaced().getType() != Material.LIGHT) return;
        if (e.getBlockPlaced().getBlockData() instanceof Light l) {
            l.setLevel(plugin.lightLevel());
            e.getBlockPlaced().setBlockData(l);
        }
        e.getPlayer().sendActionBar(Component.text(
                "☀ Свет " + plugin.lightLevel() + " установлен (удалить: ударить)", NamedTextColor.YELLOW));
    }

    @EventHandler
    public void onLightBreak(PlayerInteractEvent e) {
        if (e.getAction() != Action.LEFT_CLICK_BLOCK) return;
        if (e.getClickedBlock() == null || e.getClickedBlock().getType() != Material.LIGHT) return;
        if (e.getPlayer().getGameMode() == org.bukkit.GameMode.CREATIVE) return; // креатив ломает сам
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) return;
        Block b = e.getClickedBlock();
        b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), CraftsItems.invisLight());
        b.setType(Material.AIR, false);
        b.getWorld().spawnParticle(org.bukkit.Particle.WHITE_SMOKE,
                b.getLocation().add(0.5, 0.5, 0.5), 8, 0.2, 0.2, 0.2, 0.01);
        b.getWorld().playSound(b.getLocation(), Sound.BLOCK_GLASS_BREAK, 0.5f, 1.6f);
    }

    /* ================= невидимая рамка ================= */

    @EventHandler(ignoreCancelled = true)
    public void onFramePlace(HangingPlaceEvent e) {
        if (!"invis_frame".equals(CraftsItems.kindOf(e.getItemStack()))) return;
        if (e.getEntity() instanceof ItemFrame f) {
            f.setInvisible(true);
            e.getEntity().getWorld().spawnParticle(org.bukkit.Particle.WHITE_SMOKE,
                    e.getEntity().getLocation(), 6, 0.2, 0.2, 0.2, 0.01);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onFrameBreak(HangingBreakEvent e) {
        if (!(e.getEntity() instanceof ItemFrame f) || !f.isVisible()) return;
        e.setCancelled(true);
        f.getWorld().dropItemNaturally(f.getLocation(), CraftsItems.invisFrame());
        f.remove();
    }
}
