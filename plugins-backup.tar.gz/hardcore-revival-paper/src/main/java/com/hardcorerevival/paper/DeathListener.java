package com.hardcorerevival.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.util.UUID;

/** Death (star save / spectator), respawn placement, join placement, wither drops. */
public class DeathListener implements Listener {

    private final HardcoreRevivalPlugin plugin;

    public DeathListener(HardcoreRevivalPlugin plugin) {
        this.plugin = plugin;
    }

    /* ---------------- death ---------------- */

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        Player p = event.getEntity();
        UUID id = p.getUniqueId();

        // Protection is lost on any death.
        plugin.store().removeProtection(id);

        // 1) Passive star totem: items dissolve, instant respawn at own point.
        if (Revival.tryStarSave(plugin, event)) {
            return;
        }

        // 2) Regular hardcore death → spectator countdown.
        long now = System.currentTimeMillis();
        plugin.store().addDeath(id, now + plugin.cfg().deathDurationMs(), p.getName());
        // Dropped stars (players' drops) glow so nobody loses track of them.
        Bukkit.getScheduler().runTaskLater(plugin,
                () -> Effects.glowNearbyStars(p.getLocation()), 2L);
        Effects.broadcast(plugin, Component.text("☠ ", NamedTextColor.DARK_RED)
                .append(Component.text(p.getName(), NamedTextColor.RED))
                .append(Component.text(" погиб — возрождение через "
                        + Effects.formatDuration(plugin.cfg().deathDurationMs()), NamedTextColor.GRAY)));

        // 3) Труп-зомби: вещи погибшего уезжают в зомби, дроп на землю не падает.
        Corpse.spawn(plugin, p, event);
    }

    /* ---------------- respawn ---------------- */

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player p = event.getPlayer();
        if (plugin.store().isDead(p.getUniqueId())) {
            // Hardcore rule: never at a bed — always world spawn.
            event.setRespawnLocation(Revival.worldSpawnSafe());
        }
        // Final polish one tick later (gamemode fixes, effects).
        Bukkit.getScheduler().runTaskLater(plugin, () -> finalizeRespawn(p), 1L);
    }

    private void finalizeRespawn(Player p) {
        if (!p.isOnline()) return;
        UUID id = p.getUniqueId();

        if (plugin.store().isDead(id)) {
            if (p.getGameMode() != org.bukkit.GameMode.SPECTATOR) {
                Revival.placeSpectator(plugin, p);
            }
            return;
        }

        // Star-saved player: hardcore respawn forces spectator — give them their mode back.
        if (plugin.justSaved().remove(id)) {
            if (p.getGameMode() == org.bukkit.GameMode.SPECTATOR) {
                p.setGameMode(Bukkit.getDefaultGameMode());
            }
            Location loc = p.getLocation();
            Effects.reviveBurst(loc);
            Effects.title(p, "✨ ЗВЕЗДА СПАСЛА ТЕБЯ ✨", NamedTextColor.GOLD,
                    "Вещи растворились звёздной пылью...", NamedTextColor.GRAY);
        }
    }

    /** Трупы из загруженных чанков попадают в реестр координат. */
    @EventHandler
    public void onEntitiesLoad(org.bukkit.event.world.EntitiesLoadEvent event) {
        for (org.bukkit.entity.Entity e : event.getEntities()) {
            if (Corpse.isCorpse(e)) Corpse.register(e, Corpse.ownerOf(e));
        }
    }

    /* ---------------- призрак ---------------- */

    /** Спектатор в ваниле сам: неуязвим, невидим, не мешает сну, не влияет на мир.
     *  Осталось только убрать парящую голову при выходе, чтобы не осталась сиротой. */
    @EventHandler
    public void onGhostQuit(org.bukkit.event.player.PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (plugin.store().isDead(p.getUniqueId())) {
            Ghost.removeVisuals(plugin, p);
        }
    }

    /* ---------------- join ---------------- */

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        UUID id = p.getUniqueId();

        // Авто-починка: застрял в спектаторе живым (гонка вселение+возрождение, падение
        // старой версии и т.п.) — режим спектатора сохранился в playerdata. Не трогаем
        // опов-админов: они садятся в спектатор сами и сознательно.
        if (p.getGameMode() == org.bukkit.GameMode.SPECTATOR
                && !plugin.store().isDead(id) && !p.isOp()) {
            p.setGameMode(Bukkit.getDefaultGameMode());
            plugin.getLogger().info("Авто-починка: " + p.getName() + " вытащен из застрявшего спектатора.");
        }

        // Revived while offline → appear next to the reviver (or at spawn).
        var pending = plugin.store().consumeReviveNextTo(id);
        if (pending != null) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!p.isOnline()) return;
                Location dest;
                if (pending.isPresent()) {
                    Player reviver = Bukkit.getPlayer(pending.get());
                    dest = reviver != null && reviver.isOnline()
                            ? reviver.getLocation()
                            : Revival.worldSpawnSafe();
                } else {
                    dest = Revival.worldSpawnSafe();
                }
                plugin.ghostWatch().remove(id);
                Ghost.removeVisuals(plugin, p);
                p.setGameMode(Bukkit.getDefaultGameMode());
                p.teleport(dest);
                Effects.reviveBurst(dest);
                Effects.title(p, "ТЫ ВОЗРОЖДЁН", NamedTextColor.GOLD,
                        "Защита от игроков: " + Effects.formatDuration(plugin.cfg().protectionMs()),
                        NamedTextColor.AQUA);
            }, 5L);
            return;
        }

        if (plugin.store().isDead(id)) {
            // Timer kept running while they were away — tick task will place them,
            // do it promptly here too.
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (p.isOnline() && plugin.store().isDead(id)) {
                    Revival.placeSpectator(plugin, p);
                }
            }, 5L);
        }
    }

    /* ---------------- wither star chance ---------------- */

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        if (Corpse.handleDeath(plugin, event)) return; // труп выпустил лут
        Revival.handleWitherDrop(plugin, event);
    }

    /** Труп-зомби не превращается (вода → утопленник и т.п.). */
    @EventHandler(ignoreCancelled = true)
    public void onCorpseTransform(org.bukkit.event.entity.EntityTransformEvent event) {
        if (Corpse.isCorpse(event.getEntity())) event.setCancelled(true);
    }

}
