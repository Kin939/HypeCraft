package com.anyportal.paper;

import org.bukkit.plugin.java.JavaPlugin;

/**
 * AnyPortal — порталы в незер любой формы.
 * Зажигаешь огнивом обсидиан — плагин заливкой находит замкнутый обсидианом
 * «пузырь» воздуха (любой силуэт: треугольник, ромб, буква…) и заполняет его
 * портальными блоками. Телепортация — ванильная. В Энде порталы запрещены.
 * Никаких сообщений в чат — плагин ведёт себя как ваниль.
 */
public final class AnyPortalPlugin extends JavaPlugin {

    private PortalRegistry registry;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        registry = new PortalRegistry(this);
        registry.load();

        getServer().getPluginManager().registerEvents(new PortalListener(this, registry), this);

        var cmd = getCommand("anyportal");
        if (cmd != null) {
            AnyPortalCommand exec = new AnyPortalCommand(this, registry);
            cmd.setExecutor(exec);
            cmd.setTabCompleter(exec);
        }
        getLogger().info("AnyPortal включён. Порталов в реестре: " + registry.all().size() + ".");
    }

    /** Максимум блоков нутра одного портала. */
    public int maxInteriorBlocks() {
        return Math.max(4, getConfig().getInt("max-interior-blocks", 128));
    }

    /** Защита рамки и нутра от взрывов. */
    public boolean protectExplosions() {
        return getConfig().getBoolean("protect-explosions", true);
    }

    /** Частицы при зажигании/тушении. */
    public boolean particles() {
        return getConfig().getBoolean("creation-particles", true);
    }

    /** Запретить порталы в Энде. */
    public boolean banEnd() {
        return getConfig().getBoolean("ban-end", true);
    }

    public PortalRegistry registry() {
        return registry;
    }
}
