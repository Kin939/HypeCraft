package com.dragonloader.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

/** События: установка/ломание яйца, защита от телепорта, яйцо с повторного дракона. */
public final class CLListener implements Listener {

    private final DragonLoaderPlugin plugin;

    public CLListener(DragonLoaderPlugin plugin) {
        this.plugin = plugin;
    }

    /* ---------------- установка и снятие ---------------- */

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (e.getBlockPlaced().getType() != Material.DRAGON_EGG) return;
        if (plugin.register(e.getBlockPlaced())) {
            e.getPlayer().sendMessage(Component.text(
                    "⚡ Прогрузчик активен: зона 3×3 чанков вокруг яйца загружена и работает даже без игроков.",
                    NamedTextColor.GREEN));
            e.getPlayer().playSound(e.getPlayer().getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1f, 0.7f);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (b.getType() != Material.DRAGON_EGG) return;
        var pos = DragonLoaderPlugin.Pos.of(b);
        if (!plugin.isRegistered(pos)) return;
        boolean survivalDropMissing = !e.isDropItems()
                && e.getPlayer().getGameMode() != org.bukkit.GameMode.CREATIVE;
        plugin.unregister(pos);
        e.getPlayer().sendMessage(Component.text("⚡ Прогрузчик снят: зона 3×3 чанков выгружена.", NamedTextColor.YELLOW));
        if (survivalDropMissing) {
            // Не тем инструментом — ваниль яйцо не уронит; вернём, чтобы прогрузчик не пропал.
            b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), new ItemStack(Material.DRAGON_EGG));
        }
    }

    /* ---------------- защита яйца ---------------- */

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        Block b = e.getClickedBlock();
        if (b == null || b.getType() != Material.DRAGON_EGG) return;
        if (!plugin.isRegistered(DragonLoaderPlugin.Pos.of(b))) return;
        e.setCancelled(true); // ваниль телепортировала бы яйцо — не даём
        e.getPlayer().sendActionBar(Component.text(
                "⚡ Прогрузчик 3×3 чанков активен (зона подсвечена искрами)", NamedTextColor.AQUA));
    }

    @EventHandler(ignoreCancelled = true)
    public void onFromTo(BlockFromToEvent e) {
        if (e.getBlock().getType() == Material.DRAGON_EGG
                && plugin.isRegistered(DragonLoaderPlugin.Pos.of(e.getBlock()))) {
            e.setCancelled(true); // телепорт яйца прочь — нельзя, прогрузчик стоит на месте
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (b.getType() == Material.DRAGON_EGG && plugin.isRegistered(DragonLoaderPlugin.Pos.of(b))) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) {
            if (b.getType() == Material.DRAGON_EGG && plugin.isRegistered(DragonLoaderPlugin.Pos.of(b))) {
                e.setCancelled(true);
                return;
            }
        }
    }

    /* ---------------- яйцо с повторного дракона ---------------- */

    @EventHandler
    public void onDragonDeath(EntityDeathEvent e) {
        if (e.getEntity().getType() != org.bukkit.entity.EntityType.ENDER_DRAGON) return;
        Player killer = e.getEntity().getKiller();
        if (killer == null) return;

        // Ваниль кладёт яйцо на портале только после ПЕРВОЙ победы.
        // Если дракон уже побеждал ранее (respawn) — выдаём яйцо убийце сами.
        var battle = e.getEntity().getWorld().getEnderDragonBattle();
        if (battle == null || !battle.hasBeenPreviouslyKilled()) return;

        var left = killer.getInventory().addItem(new ItemStack(Material.DRAGON_EGG));
        left.values().forEach(it -> killer.getWorld().dropItemNaturally(killer.getLocation(), it));
        Bukkit.broadcast(Component.text("🐉 ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text(killer.getName(), NamedTextColor.YELLOW))
                .append(Component.text(" поверг дракона и получает его яйцо!", NamedTextColor.LIGHT_PURPLE)));
        killer.playSound(killer.getLocation(), Sound.ENTITY_ENDER_DRAGON_DEATH, 0.6f, 1.4f);
    }
}
