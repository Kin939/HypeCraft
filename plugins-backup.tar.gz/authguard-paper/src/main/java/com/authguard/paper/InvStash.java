package com.authguard.paper;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Кладовка: инвентарь игрока на время авторизации.
 * Пока игрок в мире авторизации — инвентарь пуст; вещи хранятся в stash.yml
 * (сразу пишутся на диск, переживают падение сервера) и возвращаются после входа.
 */
public final class InvStash {

    private final AuthGuardPlugin plugin;
    private final File file;
    private final YamlConfiguration yaml = new YamlConfiguration();

    public InvStash(AuthGuardPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "stash.yml");
        if (file.isFile()) {
            try {
                yaml.load(file);
            } catch (Exception e) {
                plugin.getLogger().severe("Не читаю stash.yml: " + e.getMessage());
            }
        }
    }

    private String path(UUID id) {
        return "players." + id;
    }

    /** Инвентарь игрока уже на хранении? */
    public boolean has(UUID id) {
        return yaml.contains(path(id));
    }

    /** Запомнить инвентарь (сразу на диск) и спрятать его у игрока. */
    public void stash(Player p) {
        String path = path(p.getUniqueId());
        if (yaml.contains(path)) {
            // уже храним (прошлый заход без входа) — вещи не затираем, просто прячем текущие
            hide(p);
            return;
        }
        ItemStack[] all = p.getInventory().getContents();
        boolean any = false;
        for (int i = 0; i < all.length; i++) {
            ItemStack it = all[i];
            if (it == null || it.getType().isAir() || it.getAmount() <= 0) continue;
            yaml.set(path + "." + i, it);
            any = true;
        }
        yaml.set(path + ".held", p.getInventory().getHeldItemSlot());
        yaml.set(path + ".name", p.getName());
        save(); // вещи на диске ДО очистки — потерять их нельзя
        hide(p);
        if (any) {
            plugin.getLogger().info("Инвентарь " + p.getName() + " спрятан на время авторизации (stash.yml).");
        }
    }

    /** Вернуть вещи после входа. Возвращает излишки, если целевые слоты заняты. */
    public List<ItemStack> restore(Player p) {
        List<ItemStack> leftovers = new ArrayList<>();
        String path = path(p.getUniqueId());
        if (!yaml.contains(path)) return leftovers;

        ItemStack[] stashed = new ItemStack[p.getInventory().getSize()];
        ConfigurationSection sec = yaml.getConfigurationSection(path);
        if (sec != null) {
            for (String k : sec.getKeys(false)) {
                if ("held".equals(k) || "name".equals(k)) continue;
                int idx;
                try {
                    idx = Integer.parseInt(k);
                } catch (NumberFormatException ignored) {
                    continue;
                }
                ItemStack it = sec.getItemStack(k);
                if (it == null || it.getType().isAir() || it.getAmount() <= 0) continue;
                if (idx >= 0 && idx < stashed.length) stashed[idx] = it;
            }
        }

        ItemStack[] cur = p.getInventory().getContents();
        for (int i = 0; i < stashed.length; i++) {
            ItemStack want = stashed[i];
            if (want == null) continue;
            if (i < cur.length && (cur[i] == null || cur[i].getType().isAir() || cur[i].getAmount() <= 0)) {
                p.getInventory().setItem(i, want);
            } else {
                leftovers.add(want); // слот занят — не теряем, отдадим дропом
            }
        }
        int held = yaml.getInt(path + ".held", p.getInventory().getHeldItemSlot());
        if (held >= 0 && held < 9) p.getInventory().setHeldItemSlot(held);

        yaml.set(path, null);
        save();
        return leftovers;
    }

    private void hide(Player p) {
        p.getInventory().clear();
        p.getInventory().setArmorContents(new ItemStack[4]);
        p.getInventory().setItemInOffHand(null);
    }

    private void save() {
        try {
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Не сохраняю stash.yml: " + e.getMessage());
        }
    }
}
