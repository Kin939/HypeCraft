package com.necromancer.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Предметы некроманта: Мрачный мак и головы приручённых мобов. */
public final class NecroItems {

    public static final String KIND_FLOWER = "flower";
    public static final String KIND_HEAD = "head";

    private static final String[] TIER = {"Медный", "Железный", "Алмазный", "Незеритовый"};

    private NecroItems() {}

    /* ---------- проверка предметов ---------- */

    public static boolean isNecro(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(NecroKeys.KIND, PersistentDataType.STRING);
    }

    public static String kindOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(NecroKeys.KIND, PersistentDataType.STRING);
    }

    public static UUID ownerOf(ItemStack it) {
        String s = str(it, NecroKeys.OWNER);
        try {
            return s == null ? null : UUID.fromString(s);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public static NecroMob mobOf(ItemStack it) {
        String s = str(it, NecroKeys.MOB);
        if (s == null) return null;
        try {
            return NecroMob.valueOf(s);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public static int levelOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return 0;
        return it.getItemMeta().getPersistentDataContainer()
                .getOrDefault(NecroKeys.LVL, PersistentDataType.INTEGER, 0);
    }

    public static UUID uidOf(ItemStack it) {
        String s = str(it, NecroKeys.UID);
        try {
            return s == null ? null : UUID.fromString(s);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static String str(ItemStack it, org.bukkit.NamespacedKey key) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }

    /* ---------- Мрачный мак ---------- */

    public static ItemStack flower() {
        ItemStack it = new ItemStack(Material.POPPY);
        var meta = it.getItemMeta();
        meta.displayName(Component.text("⚜ Мрачный мак", NamedTextColor.DARK_PURPLE));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Приручает нежить: ПКМ по мобу.", NamedTextColor.GRAY));
        lore.add(Component.text("Зомби · Утопленник · Кадавр · Скелет", NamedTextColor.DARK_GRAY));
        lore.add(Component.text("Зимогор · Болотник · Пустынник", NamedTextColor.DARK_GRAY));
        lore.add(Component.text("Некромант чувствует его силу…", NamedTextColor.DARK_PURPLE));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(NecroKeys.KIND, PersistentDataType.STRING, KIND_FLOWER);
        it.setItemMeta(meta);
        return it;
    }

    /* ---------- Голова моба ---------- */

    public static ItemStack mobHead(UUID owner, NecroMob mob, int lvl) {
        ItemStack it = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) it.getItemMeta();
        applyMobTexture(meta, mob);
        fillHeadMeta(meta, mob, lvl);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(NecroKeys.KIND, PersistentDataType.STRING, KIND_HEAD);
        pdc.set(NecroKeys.OWNER, PersistentDataType.STRING, owner.toString());
        pdc.set(NecroKeys.MOB, PersistentDataType.STRING, mob.name());
        pdc.set(NecroKeys.LVL, PersistentDataType.INTEGER, lvl);
        pdc.set(NecroKeys.UID, PersistentDataType.STRING, UUID.randomUUID().toString());
        it.setItemMeta(meta);
        return it;
    }

    /** Обновить имя/лор головы по её PDC (после прокачки). */
    public static void refreshHead(ItemStack it) {
        NecroMob mob = mobOf(it);
        if (mob == null) return;
        SkullMeta meta = (SkullMeta) it.getItemMeta();
        fillHeadMeta(meta, mob, levelOf(it));
        it.setItemMeta(meta);
    }

    public static void setLevel(ItemStack it, int lvl) {
        var meta = it.getItemMeta();
        meta.getPersistentDataContainer().set(NecroKeys.LVL, PersistentDataType.INTEGER, lvl);
        it.setItemMeta(meta);
        refreshHead(it);
    }

    /** Накладывает настоящую текстуру моба (minecraft-heads) на голову. */
    private static void applyMobTexture(SkullMeta meta, NecroMob mob) {
        if (mob.texture == null || mob.texture.isEmpty()) return;
        var profile = org.bukkit.Bukkit.createProfile(
                UUID.nameUUIDFromBytes(mob.texture.getBytes(java.nio.charset.StandardCharsets.UTF_8)),
                "Necromancer");
        profile.setProperty(new com.destroystokyo.paper.profile.ProfileProperty("textures", mob.texture));
        meta.setPlayerProfile(profile);
    }

    private static void fillHeadMeta(SkullMeta meta, NecroMob mob, int lvl) {
        meta.displayName(Component.text("☠ ", NamedTextColor.DARK_RED)
                .append(Component.text(mob.ru, NamedTextColor.RED))
                .append(Component.text(" — " + NecroMob.levelName(lvl), NamedTextColor.GOLD)));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Уровень: " + lvl + "/4 (" + NecroMob.levelName(lvl) + ")", NamedTextColor.GRAY));
        lore.add(Component.text("❤ Здоровье: " + mob.baseHp, NamedTextColor.RED));
        lore.add(Component.text("⚔ Оружие: " + weaponName(mob, lvl), NamedTextColor.YELLOW));
        lore.add(Component.text("🛡 Броня: " + armorName(lvl), NamedTextColor.AQUA));
        lore.add(Component.text("ПКМ — меню легиона", NamedTextColor.DARK_GRAY));
        meta.lore(lore);
    }

    /* ---------- названия и цены ---------- */

    public static String weaponName(NecroMob m, int lvl) {
        if (lvl <= 0) return m.archer ? "Обычный лук" : "Когти";
        if (m.archer) {
            int power = lvl == 4 ? 5 : lvl;
            return TIER[lvl - 1] + " лук (Сила " + power + (lvl >= 3 ? " + Воспламенение 2" : "") + ")";
        }
        if (m == NecroMob.DROWNED && lvl == 3) return "Трезубец";
        return TIER[lvl - 1] + (m.axe ? " топор" : " меч");
    }

    public static String armorName(int lvl) {
        return lvl <= 0 ? "Нет" : TIER[lvl - 1] + " комплект";
    }

    /** Материал цены следующего уровня (nextLvl 1..4) или null. */
    public static Material upgradeMaterial(int nextLvl) {
        return switch (nextLvl) {
            case 1 -> Material.COPPER_INGOT;
            case 2 -> Material.IRON_INGOT;
            case 3 -> Material.DIAMOND;
            case 4 -> Material.NETHERITE_SCRAP;
            default -> null;
        };
    }

    public static int upgradeCount(int nextLvl) {
        return nextLvl == 4 ? 1 : 10;
    }

    public static String upgradePriceText(int nextLvl) {
        Material m = upgradeMaterial(nextLvl);
        if (m == null) return null;
        String n = switch (m) {
            case COPPER_INGOT -> "Медный слиток";
            case IRON_INGOT -> "Железный слиток";
            case DIAMOND -> "Алмаз";
            default -> "Незеритовый лом";
        };
        return upgradeCount(nextLvl) + "× " + n;
    }


}
