package com.hardcorerevival.logic;

import com.hardcorerevival.Config;
import com.hardcorerevival.data.RevivalSavedData;
import com.hardcorerevival.util.Msg;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Core logic: death → spectator → auto-revive → PvP protection. */
public final class RevivalManager {

    private RevivalManager() {
    }

    public static RevivalSavedData data(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(RevivalSavedData.TYPE);
    }

    public static long deathDurationMs() {
        return (long) (Config.DEATH_DURATION_HOURS.get() * 3_600_000.0);
    }

    public static long protectionDurationMs() {
        return (long) (Config.PROTECTION_DURATION_MINUTES.get() * 60_000.0);
    }

    /* ---------------- positions ---------------- */

    public static ServerLevel spawnLevel(MinecraftServer server) {
        return server.overworld();
    }

    private static Vec3 safeSpawnPos(ServerLevel level) {
        BlockPos pos = level.getRespawnData().pos();
        int x = pos.getX();
        int z = pos.getZ();
        // getHeight returns the topmost solid block, feet must be at +1.
        int y = Math.max(pos.getY(), level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) + 1);
        return new Vec3(x + 0.5, y, z + 0.5);
    }

    private static void teleportToSpawn(ServerPlayer player) {
        MinecraftServer server = player.level().getServer();
        ServerLevel level = spawnLevel(server);
        player.teleport(new TeleportTransition(
                level, safeSpawnPos(level), Vec3.ZERO,
                level.getRespawnData().yaw(), level.getRespawnData().pitch(),
                TeleportTransition.DO_NOTHING));
    }

    /* ---------------- transitions ---------------- */

    /** Player died → start spectator countdown. Vanilla handles the item drop. */
    public static void handleDeath(ServerPlayer player) {
        MinecraftServer server = player.level().getServer();
        RevivalSavedData data = data(server);
        data.removeProtection(player.getUUID());
        data.clearPlacement(player.getUUID());
        data.setDeath(player.getUUID(), System.currentTimeMillis() + deathDurationMs(),
                player.getName().getString());

        if (Config.BROADCAST.get()) {
            server.getPlayerList().broadcastSystemMessage(
                    Msg.icon("☠", ChatFormatting.DARK_RED, "")
                            .append(Component.literal(player.getName().getString()).withStyle(ChatFormatting.RED))
                            .append(Component.literal(" погиб и стал наблюдателем на "
                                    + Msg.formatDuration(deathDurationMs())).withStyle(ChatFormatting.GRAY)),
                    false);
        }
    }

    /** Player respawns (fresh entity, standing at world spawn) → make them a spectator. */
    public static void placeSpectator(ServerPlayer player) {
        UUID id = player.getUUID();
        if (data(player.level().getServer()).isSpectatorPlaced(id)) return;
        data(player.level().getServer()).markSpectatorPlaced(id);
        player.setGameMode(GameType.SPECTATOR);
        teleportToSpawn(player);
        RevivalSavedData data = data(player.level().getServer());
        RevivalSavedData.DeathEntry entry = data.deathEntry(player.getUUID());
        long left = entry != null ? entry.deadline() - System.currentTimeMillis() : deathDurationMs();
        title(player,
                Component.literal("РЕЖИМ НАБЛЮДАТЕЛЯ").withStyle(ChatFormatting.DARK_RED),
                Component.literal("Возрождение через " + Msg.formatDuration(left)).withStyle(ChatFormatting.GRAY));
        actionbar(player, Msg.icon("☠", ChatFormatting.RED,
                "Возрождение через " + Msg.formatDuration(left)));
        player.playSound(SoundEvents.WITHER_SPAWN, 0.4F, 1.6F);
    }

    /** Revive an online player: survival, world spawn, protection, effects. */
    public static void reviveOnline(ServerPlayer player, String causeLine) {
        MinecraftServer server = player.level().getServer();
        RevivalSavedData data = data(server);
        data.removeDeath(player.getUUID());
        data.clearPlacement(player.getUUID());
        if (protectionDurationMs() > 0) {
            data.setProtection(player.getUUID(), System.currentTimeMillis() + protectionDurationMs());
        }

        player.setGameMode(GameType.SURVIVAL);
        player.setRemainingFireTicks(0);
        teleportToSpawn(player);

        title(player,
                Component.literal("ВЫ ВОЗРОДИЛИСЬ").withStyle(ChatFormatting.GOLD),
                protectionDurationMs() > 0
                        ? Component.literal("Защита от игроков: " + Msg.formatDuration(protectionDurationMs()))
                                .withStyle(ChatFormatting.AQUA)
                        : null);
        player.playSound(SoundEvents.PLAYER_LEVELUP, 1.0F, 1.0F);
        player.playSound(SoundEvents.TOTEM_USE, 0.7F, 1.3F);

        Vec3 pos = player.position();
        ServerLevel level = spawnLevel(server);
        level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, pos.x, pos.y + 1.0, pos.z, 80, 0.7, 0.9, 0.7, 0.12);
        level.sendParticles(ParticleTypes.FIREWORK, pos.x, pos.y + 1.0, pos.z, 40, 0.6, 0.8, 0.6, 0.2);

        if (Config.BROADCAST.get()) {
            server.getPlayerList().broadcastSystemMessage(
                    Msg.icon("✨", ChatFormatting.GOLD, "")
                            .append(Component.literal(player.getName().getString()).withStyle(ChatFormatting.YELLOW))
                            .append(Component.literal(" возродился!" + causeLine).withStyle(ChatFormatting.GRAY)),
                    false);
        }
    }

    /**
     * Revives a player by UUID (online or offline).
     *
     * @return true if the player was dead and is now revived
     */
    public static boolean reviveById(MinecraftServer server, UUID targetId, String causeLine) {
        RevivalSavedData data = data(server);
        if (!data.isDead(targetId)) return false;
        ServerPlayer online = server.getPlayerList().getPlayer(targetId);
        if (online != null) {
            reviveOnline(online, causeLine);
        } else {
            // Revived while offline: they will be placed at spawn on next login.
            data.removeDeath(targetId);
            data.clearPlacement(targetId);
            data.clearSpectatorPlaced(targetId);
            if (protectionDurationMs() > 0) {
                data.setProtection(targetId, System.currentTimeMillis() + protectionDurationMs());
            }
            data.markPlacement(targetId);
        }
        return true;
    }

    /** Revived while offline → place at spawn now that they logged in. */
    public static void placeRevived(ServerPlayer player) {
        reviveOnline(player, " (с возвращением!)");
    }

    /* ---------------- per-tick housekeeping ---------------- */

    public static void serverTick(MinecraftServer server) {
        RevivalSavedData data = data(server);
        long now = System.currentTimeMillis();
        int tick = server.getTickCount();

        // Deadline checks — once per second is plenty.
        if (tick % 20 == 0) {
            for (Map.Entry<UUID, RevivalSavedData.DeathEntry> e : data.deathsSnapshot().entrySet()) {
                if (now >= e.getValue().deadline()) {
                    ServerPlayer online = server.getPlayerList().getPlayer(e.getKey());
                    if (online != null) {
                        reviveOnline(online, " (срок наблюдения истёк)");
                    } else {
                        // Expired while offline: apply on next login.
                        data.removeDeath(e.getKey());
                        data.clearPlacement(e.getKey());
                        data.clearSpectatorPlaced(e.getKey());
                        if (protectionDurationMs() > 0) {
                            data.setProtection(e.getKey(), now + protectionDurationMs());
                        }
                        data.markPlacement(e.getKey());
                    }
                }
            }
            for (Map.Entry<UUID, Long> e : data.protectionsSnapshot().entrySet()) {
                if (now >= e.getValue()) {
                    data.removeProtection(e.getKey());
                    ServerPlayer online = server.getPlayerList().getPlayer(e.getKey());
                    if (online != null) {
                        actionbar(online, Msg.icon("✦", ChatFormatting.RED, "Защита от игроков закончилась"));
                        online.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0F, 0.8F);
                    }
                }
            }
        }

        // Spectator leash — keep dead players near spawn so they don't load chunks.
        if (tick % 10 == 0) {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                if (data.isDead(p.getUUID())) {
                    // Safety net: if the respawn event never fired (e.g. hardcore
                    // "spectate world" path), place them within half a second.
                    if (!data.isSpectatorPlaced(p.getUUID())) {
                        placeSpectator(p);
                    }
                    enforceSpectator(p, data);
                }
            }
        }

        // Timers on the actionbar — once per second.
        if (tick % 20 == 0) {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                UUID id = p.getUUID();
                if (data.isDead(id)) {
                    RevivalSavedData.DeathEntry entry = data.deathEntry(id);
                    long left = (entry != null ? entry.deadline() : now) - now;
                    p.connection.send(new ClientboundSetActionBarTextPacket(
                            Msg.icon("☠", ChatFormatting.RED, "Возрождение через ")
                                    .append(Component.literal(Msg.formatDuration(left))
                                            .withStyle(ChatFormatting.BOLD, ChatFormatting.RED))));
                } else if (data.isProtected(id)) {
                    long left = data.protectionUntil(id) - now;
                    ChatFormatting color = left < 10_000 ? ChatFormatting.RED
                            : left < 60_000 ? ChatFormatting.YELLOW : ChatFormatting.GOLD;
                    p.connection.send(new ClientboundSetActionBarTextPacket(
                            Msg.icon("✦", ChatFormatting.GOLD, "Защита от игроков: ")
                                    .append(Component.literal(Msg.formatDuration(left)).withStyle(color))));
                }
            }
        }
    }

    private static void enforceSpectator(ServerPlayer p, RevivalSavedData data) {
        if (p.gameMode() != GameType.SPECTATOR) {
            p.setGameMode(GameType.SPECTATOR);
        }
        ServerLevel overworld = spawnLevel(p.level().getServer());
        if (p.level() != (Level) overworld) {
            teleportToSpawn(p);
            return;
        }
        int radius = Config.SPECTATOR_RADIUS.get();
        Vec3 center = safeSpawnPos(overworld);
        double dx = p.getX() - center.x;
        double dz = p.getZ() - center.z;
        if (dx * dx + dz * dz > (double) radius * radius) {
            teleportToSpawn(p);
            actionbar(p, Msg.icon("⚠", ChatFormatting.YELLOW, "Наблюдатель не может покидать зону спавна"));
            p.playSound(SoundEvents.NOTE_BLOCK_PLING.value(), 0.5F, 1.8F);
        }
    }

    /* ---------------- star menu ---------------- */

    /** Sends the clickable "pick a player to revive" chat menu. */
    public static void sendReviveMenu(ServerPlayer viewer) {
        MinecraftServer server = viewer.level().getServer();
        RevivalSavedData data = data(server);
        long now = System.currentTimeMillis();

        List<Map.Entry<UUID, RevivalSavedData.DeathEntry>> entries = new ArrayList<>(data.deathsSnapshot().entrySet());
        entries.sort((a, b) -> Long.compare(a.getValue().deadline(), b.getValue().deadline()));

        if (entries.isEmpty()) {
            viewer.sendSystemMessage(Msg.icon("✨", ChatFormatting.GREEN, "Никто не мёртв — все живы!"));
            return;
        }

        viewer.sendSystemMessage(Component.literal("⸻ ⸸ ВОЗРОЖДЕНИЕ ЗВЕЗДОЙ ВИЗЕРА ⸸ ⸻")
                .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD));
        for (Map.Entry<UUID, RevivalSavedData.DeathEntry> e : entries) {
            UUID id = e.getKey();
            String name = e.getValue().name();
            long left = e.getValue().deadline() - now;
            boolean online = server.getPlayerList().getPlayer(id) != null;

            MutableComponent line = Component.literal(" ▸ ").withStyle(ChatFormatting.DARK_GRAY);
            line.append(Component.literal(name).withStyle(s -> s
                    .withColor(ChatFormatting.AQUA)
                    .withClickEvent(new ClickEvent.RunCommand("/revive accept " + id))
                    .withHoverEvent(new HoverEvent.ShowText(Component.literal(
                            "Возродить " + name + " (звезда будет потрачена)")))));
            line.append(Component.literal(" — " + Msg.formatDuration(left) + (online ? "" : " (оффлайн)"))
                    .withStyle(ChatFormatting.DARK_GRAY));
            viewer.sendSystemMessage(line);
        }
        viewer.sendSystemMessage(Component.literal("Кликни по нику, чтобы потратить звезду и возродить игрока.")
                .withStyle(ChatFormatting.GRAY));
    }

    public static void sendStatus(ServerPlayer p) {
        RevivalSavedData data = data(p.level().getServer());
        UUID id = p.getUUID();
        long now = System.currentTimeMillis();
        if (data.isDead(id)) {
            RevivalSavedData.DeathEntry e = data.deathEntry(id);
            long left = (e != null ? e.deadline() : now) - now;
            p.sendSystemMessage(Msg.icon("☠", ChatFormatting.RED, "Ты мёртв. Возрождение через "
                    + Msg.formatDuration(left)));
        } else if (data.isProtected(id)) {
            p.sendSystemMessage(Msg.icon("✦", ChatFormatting.GOLD, "Защита от игроков: "
                    + Msg.formatDuration(data.protectionUntil(id) - now)));
        } else {
            p.sendSystemMessage(Msg.icon("✅", ChatFormatting.GREEN, "Ты жив и не защищён"));
        }
    }

    /* ---------------- admin helpers ---------------- */

    /** Removes all revival state and revives the player without protection. */
    public static void forceRelease(MinecraftServer server, ServerPlayer player) {
        RevivalSavedData data = data(server);
        data.removeDeath(player.getUUID());
        data.removeProtection(player.getUUID());
        data.clearPlacement(player.getUUID());
        player.setGameMode(server.getDefaultGameType());
        teleportToSpawn(player);
    }

    /** Forces a (still alive) player into spectator mode with a death timer. */
    public static void forceSpectate(MinecraftServer server, ServerPlayer player) {
        RevivalSavedData data = data(server);
        data.removeProtection(player.getUUID());
        data.clearPlacement(player.getUUID());
        data.clearSpectatorPlaced(player.getUUID());
        data.setDeath(player.getUUID(), System.currentTimeMillis() + deathDurationMs(),
                player.getName().getString());
        placeSpectator(player);
    }

    /* ---------------- UI helpers ---------------- */

    public static void actionbar(ServerPlayer p, Component msg) {
        p.connection.send(new ClientboundSetActionBarTextPacket(msg));
    }

    public static void title(ServerPlayer p, Component title, Component subtitle) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(5, 70, 20));
        if (subtitle != null) {
            p.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
        }
        p.connection.send(new ClientboundSetTitleTextPacket(title));
    }
}
