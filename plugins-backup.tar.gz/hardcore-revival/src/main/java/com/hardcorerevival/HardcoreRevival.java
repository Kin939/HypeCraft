package com.hardcorerevival;

import com.hardcorerevival.event.GameEvents;
import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.IExtensionPoint;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import org.slf4j.Logger;

import java.util.function.Predicate;

/**
 * Hardcore Revival — server-side mod for Minecraft Forge 26.3.
 *
 * <p>When a player dies they become a spectator anchored near world spawn for a
 * configurable period (default: 3 real days; the timer keeps running while the
 * player is offline and survives server restarts). After the timer expires the
 * player respawns at world spawn (never at a bed) and receives temporary
 * PvP protection. A living player may spend a Nether Star to revive a dead
 * player early.
 */
@Mod(HardcoreRevival.MODID)
public class HardcoreRevival {
    public static final String MODID = "hardcore_revival";
    public static final Logger LOGGER = LogUtils.getLogger();

    public HardcoreRevival(FMLJavaModLoadingContext context) {
        context.registerConfig(ModConfig.Type.SERVER, Config.SPEC);
        // Server-only mod: let vanilla (modless) clients join.
        context.registerDisplayTest(IExtensionPoint.DisplayTest.IGNORE_ALL_VERSION);

        // Annotated listeners (death, respawn, login, star, ticks, commands).
        MinecraftForge.EVENT_BUS.register(new GameEvents());

        // PvP guard — predicate listeners on the cancellable event buses:
        // returning true cancels the damage event.
        Predicate<LivingHurtEvent> hurtGuard = GameEvents::pvpHurtGuard;
        Predicate<LivingAttackEvent> attackGuard = GameEvents::pvpAttackGuard;
        LivingHurtEvent.BUS.addListener(hurtGuard);
        LivingAttackEvent.BUS.addListener(attackGuard);

        LOGGER.info("[Hardcore Revival] initialized — death is only the beginning");
    }
}
