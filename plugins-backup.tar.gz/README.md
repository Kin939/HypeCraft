# Хэндофф: плагины Paper 26.3 — продолжить в новом чате (GitHub)

Дата: 2026-11-05. Всё ниже — проверенное состояние. Новому чату: читай этот файл целиком.

## Активная задача

**«Полный реворк и багфикст всех плагинов»** — очередь задал юзер, порядок уточнять у него.
Пройдено: **AnyPortal 1.0.1** (запрет порталов в Энде + убраны сообщения в чат — ванильное поведение).
Следующий плагин — **спросить юзера**.

## Проекты (каждый = отдельный git-репозиторий, ветка main, jars закоммичены)

| Проект | Версия | Готовый jar | Статус |
|---|---|---|---|
| `anyportal-paper/` | 1.0.1 | anyportal-paper-1.0.1.jar | реворк-пункт 1 ✅ |
| `authguard-paper/` | 1.3.0 | authguard-paper-1.3.0.jar | реворк pending |
| `custom-crafts-paper/` | 1.2.0 | custom-crafts-paper-1.2.0.jar | реворк pending |
| `hardcore-revival-paper/` | 1.7.7 | hardcore-revival-paper-1.7.7.jar | реворк pending |
| `dragon-loader-paper/` | 1.0.0 | dragon-loader-paper-1.0.0.jar | FINAL |
| `necromancer-paper/` | 1.1.2 | necromancer-paper-1.1.2.jar | FINAL |
| `testworld-paper/` | 1.1.1 | testworld-paper-1.1.1.jar | FINAL |

`paper-test/` — тестовый стенд: **paper.jar (26.3-211) уже лежит там**, eula.txt готов,
server.properties настроен (RCON 25585 / пароль `testpass`, online-mode=false,
pause-when-empty-seconds=0, spawn-protection=0). Плагины кладутся в `paper-test/plugins/`.
`hardcore-revival/` — старый Forge-проект (legacy, не трогать). `uploads/` — картинки CustomCrafts.

## Сборка (каждый ход заново — .cache стирается!)

```bash
mkdir -p /home/user/.cache/tools && cd /home/user/.cache/tools
curl -sSL -o jdk.tar.gz "https://api.adoptium.net/v3/binary/latest/25/ga/linux/x64/jdk/hotspot/normal/eclipse" &
curl -sSL -o gradle.zip "https://services.gradle.org/distributions/gradle-9.8.2-bin.zip" &
wait
tar xzf jdk.tar.gz && rm jdk.tar.gz
python3 -c "import zipfile; zipfile.ZipFile('gradle.zip').extractall('.')" && rm gradle.zip
chmod +x gradle-9.8.2/bin/gradle
echo "/home/user/.cache/tools/$(ls -d jdk-25* | head -1)" > jdkpath
```

Сборка проекта:
```bash
export JAVA_HOME=$(cat /home/user/.cache/tools/jdkpath)
export GRADLE_USER_HOME=/home/user/.cache/gradle-home
/home/user/.cache/tools/gradle-9.8.2/bin/gradle build --console=plain
ls build/libs/   # ОБЯЗАТЕЛЬНО: grep по выводу build маскирует fail
```
Готовый jar копировать в корень проекта (build/ не попадает в снапшот).

## Тест-стенд

```bash
# старт (start_process):  cd /home/user/paper-test && export JAVA_HOME=$(cat /home/user/.cache/tools/jdkpath) && exec $JAVA_HOME/bin/java -Xms512M -Xmx1300M -jar paper.jar nogui > console.log 2>&1
# RCON (python): socket 127.0.0.1:25585, пакеты struct('<ii',rid,type)+payload+b'\x00\x00' с length-префиксом; type 3 = auth, type 2 = cmd
```
- Кириллица в console.log битая — НОРМА, RCON читает нормально.
- RCON-команды для кастомных миров: `execute in minecraft:<имя-с-дефисом> ...` (например `auth-world`).
  Без `in` — исполняется в Overworld (был ложный баг «всё воздух»).
- Перед проверками блоков — `forceload add <x> <z>`.
- Стенд чистить после тестов: `rm -rf world* logs cache libraries console.log` — иначе снапшот
  воркспейса рвётся (лимит ~10k файлов; однажды из-за этого ПОТЕРЯЛАСЬ папка src/).
- `execute if block` (без execute) — невалидно; `if blocks` при воздух==воздух всегда passes.
- Файлы писать питоном, не heredoc (глючит); python replace — всегда `assert old in s`.

## GitHub (в новом чате)

1. Юзер подключит GitHub-коннектор.
2. На каждый проект — свой репозиторий (стиль хостинга юзера: один jar = один плагин).
3. `cd /home/user/<proj> && git remote add origin <url> && git push -u origin main`.
4. `.gitignore` уже в каждом: build/, .gradle/, *.log, run/, .idea/.
5. Если юзер захочет монорепу — `git subtree` из этих репо, история сохранится.

## Правила и решения юзера (НЕ ТЕРЯТЬ)

### AuthGuard 1.3.0 (мир-пустота auth-world, barrier-платформа 3×3 на 8,79,8)
- Пароли PBKDF2; сессия 3 дня ТОЛЬКО при том же IP; кик 60 сек; мягкий отказ без бана.
- Тайтлы дословно: «РЕГИСТРИРУЙСЯ СВИНОТА»/«ЛОГИНЬСЯ СВИНОТА», после входа «Приятной игры /
  на сервере догорай игрок!», при живой сессии «Не умри.». Полный фриз (даже голова),
  разморозка в момент входа. Свиной концерт КАЖДУЮ секунду: death 40%/hurt 30%/ambient 20%/saddle 10%.
- Инвентарь прячется в stash.yml (диск сразу), возврат при входе; застрявших вынимает onJoin.
- Возврат на ПОСЛЕДНЕЕ место (и при регистрации — pendingLast для незарегистрированных).
- `/login` и `/register` открыты всем: permission `authguard.use` default true (иначе только оп!).
- 350 перевёрнутых «Т» из палитры 710 декор-блоков, ОДИН раз (флаг letters-generated), 320×320.
- `/authadmin bypass add|remove|list` — белый список IP-проверки (data.yml ip-bypass):
  пуск с любых IP + других аккаунтов, без кика «IP мёртвого» и без пароля при смене IP.

### Hardcore Revival 1.7.7
- Смерть = 72 реальных часа спектатора (vanilla SPECTATOR); звезда визера: per-world таймер 24h,
  киллеру в инвентарь; тотем-звезда = vanish + респаун на своей точке; /reviveall;
  chest-GUI мёртвых (головы, ЛКМ); труп-зомби хранит инвентарь; звёзды светятся.
- Фикс 1.7.7: голова-манекен призрака — rig ЗА спиной взгляда + re-hide hideEntity раз в секунду
  (сессионное скрытие слетало); оффлайн-возрождение звездой — removeDeath СРАЗУ (иначе TickTask
  возвращал в призраки, звезда впустую).
- Stuck-spectator triple: eject-before-GM + ghostWatch + onJoin auto-fix (опов не трогать).

### CustomCrafts 1.2.0
- Имя файла картинки = крафтимый предмет; дебаг-стик `everyone_decor` — только декоративные свойства.
- Окисление меди: авто-пары X→EXPOSED_X→WEATHERED_X→OXIDIZED_X (1:1), кроме обычных медных
  БЛОКОВ — те 2→2 shapeless (2 блока в любой раскладке → 2 следующей стадии), т.к. COPPER=слиток.
  WAXED_ исключены, обратного крафта нет. Статуя голема: вырезанная тыква СВЕРХУ медного блока.
- LIGHT: " R "/"TSC"/" U " → 4×; DEBUG_STICK: "XEE"/"EBE"/"EEX" → ×1; FRAME: "FS" → ×1. `/cc give ...|statue`.

### Общее
- Хостинг юзера: один jar на плагин; `pause-when-empty-seconds=0` в server.properties (vanilla-ключ,
  в paper-global.yml его НЕТ).
- plugin.yml `description` в кавычках; api-version '26.3'.
- DCL: END_ROD колонна каждую секунду; Necromancer: FINAL 1.1.2; Ghost rig = ItemDisplay+TextDisplay.
- Revive никогда не оставляет невидимым (eject spectator до GM-свитча).

## Грабли Paper 26.3 (проверено болью)

- `ShapedRecipe.setResult()` НЕ существует — результат только в конструкторе.
- `AsyncChatEvent` = `io.papermc.paper.event.player.AsyncChatEvent` (НЕ org.bukkit).
- `Axis` = org.bukkit.Axis; `BlockFace` = org.bukkit.block.BlockFace.
- CHM forbids nulls; `ItemStack.setAmount()` void; init-order: реестры ДО store.load().
- Display traps: org.bukkit.util.Transformation; Team NAME_TAG_VISIBILITY; Billboard FIXED + rotY 180.
- Lazy spawn: без игроков setblock → «not loaded» — сначала forceload.
- console.log портит кириллицу; `grep -c ERROR console.log` после stop.
- start_process может фейкнуться — retry; ждать порт 25565/25585 через get_process_output(wait_for port).
