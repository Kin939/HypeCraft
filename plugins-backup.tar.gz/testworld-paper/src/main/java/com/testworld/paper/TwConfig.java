package com.testworld.paper;

import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Typed view over config.yml. */
public final class TwConfig {

    private FileConfiguration raw;

    public TwConfig(TestWorldPlugin plugin) {
        this.raw = plugin.getConfig();
    }

    public void refresh(TestWorldPlugin plugin) {
        plugin.reloadConfig();
        this.raw = plugin.getConfig();
    }

    public String worldName() {
        return raw.getString("world-name", "testworld");
    }

    public List<String> allowedPlayers() {
        return raw.getStringList("allowed-players");
    }

    public boolean opInTest() {
        return raw.getBoolean("op-in-test", true);
    }

    /** Null = keep the player's current gamemode (config KEEP or invalid). */
    public org.bukkit.GameMode sandboxGamemode() {
        String s = raw.getString("gamemode-in-test", "CREATIVE");
        if (s == null) return org.bukkit.GameMode.CREATIVE;
        s = s.trim().toUpperCase(Locale.ROOT);
        if (s.equals("KEEP")) return null;
        try {
            return org.bukkit.GameMode.valueOf(s);
        } catch (IllegalArgumentException ex) {
            return org.bukkit.GameMode.CREATIVE;
        }
    }

    public int borderRadius() {
        return raw.getInt("worldborder-radius", 500);
    }

    /** Raw gamerules section as name → boolean. */
    public java.util.Map<String, Boolean> gamerules() {
        java.util.Map<String, Boolean> out = new java.util.LinkedHashMap<>();
        var section = raw.getConfigurationSection("gamerules");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                Object v = section.get(key);
                if (v instanceof Boolean b) {
                    out.put(key, b);
                }
            }
        }
        return out;
    }

    /** true if the player may use the sandbox (listed or has the permission). */
    public boolean isAllowed(org.bukkit.entity.Player p) {
        if (p.hasPermission("testworld.use")) return true;
        return allowedPlayers().stream().anyMatch(n -> n.equalsIgnoreCase(p.getName()));
    }
}
