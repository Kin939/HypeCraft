package com.necromancer.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.stream.Stream;

/** /necroadmin — выдача/снятие роли некроманта и выдача предметов. */
public final class NecroAdminCommand implements CommandExecutor, TabCompleter {

    private final NecromancerPlugin plugin;

    public NecroAdminCommand(NecromancerPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 0) {
            usage(sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "grant" -> grant(sender, args);
            case "remove" -> remove(sender);
            case "status" -> status(sender);
            case "give" -> give(sender, args);
            default -> usage(sender);
        }
        return true;
    }

    /**
     * Полное снятие роли: легион умирает сразу, остаточные эффекты (регенерация,
     * ночное зрение, горение) снимаются, предметы некроманта становятся бесполезны
     * (проверка владельца остаётся, а роль уже не совпадает).
     */
    private void stripRole(UUID old) {
        Minions.killAll(plugin, old, true);
        Player op = Bukkit.getPlayer(old);
        if (op != null) {
            op.removePotionEffect(org.bukkit.potion.PotionEffectType.REGENERATION);
            op.removePotionEffect(org.bukkit.potion.PotionEffectType.NIGHT_VISION);
            op.setFireTicks(0);
            op.getWorld().spawnParticle(org.bukkit.Particle.LARGE_SMOKE,
                    op.getLocation().add(0, 1, 0), 30, 0.4, 0.9, 0.4, 0.03);
            op.playSound(op.getLocation(), org.bukkit.Sound.PARTICLE_SOUL_ESCAPE, 1f, 0.5f);
            op.sendMessage(Component.text("⚠ Тьма покинула тебя. Ты больше не некромант: "
                    + "легион обратился в прах, тёмные силы угасли.", NamedTextColor.DARK_PURPLE));
        }
    }

    private void usage(CommandSender s) {
        s.sendMessage(Component.text("Использование:", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/necroadmin grant <ник> — выдать роль некроманта", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/necroadmin remove — снять роль (легион гибнет)", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/necroadmin status — кто некромант", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/necroadmin give <ник> flower|head <моб> [ур] — выдать предмет", NamedTextColor.GRAY));
    }

    private void grant(CommandSender s, String[] args) {
        if (args.length < 2) {
            s.sendMessage(Component.text("⚠ Использование: /necroadmin grant <ник>", NamedTextColor.YELLOW));
            return;
        }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null) {
            s.sendMessage(Component.text("⚠ Игрок \"" + args[1] + "\" не в сети.", NamedTextColor.YELLOW));
            return;
        }
        UUID old = plugin.necromancer();
        if (old != null && old.equals(t.getUniqueId())) {
            s.sendMessage(Component.text("ℹ " + t.getName() + " уже некромант.", NamedTextColor.GRAY));
            return;
        }
        if (old != null) {
            stripRole(old);
        }
        plugin.setNecromancer(t.getUniqueId(), t.getName());
        t.sendMessage(Component.text("☠ Тьма выбрала тебя. Ты — НЕКРОМАНТ этого сервера.", NamedTextColor.DARK_PURPLE));
        t.sendMessage(Component.text("Нежить не тронет тебя, жители в страхе бегут, а големы видят в тебе врага.",
                NamedTextColor.GRAY));
        t.sendMessage(Component.text("Крафть Мрачный мак и приручай легион.", NamedTextColor.DARK_PURPLE));
        t.getWorld().spawnParticle(Particle.LARGE_SMOKE,
                t.getLocation().add(0, 1, 0), 40, 0.4, 0.9, 0.4, 0.03);
        t.playSound(t.getLocation(), Sound.PARTICLE_SOUL_ESCAPE, 1f, 0.6f);
        s.sendMessage(Component.text("✅ Некромант: " + t.getName(), NamedTextColor.GREEN));
    }

    private void remove(CommandSender s) {
        UUID old = plugin.necromancer();
        if (old == null) {
            s.sendMessage(Component.text("ℹ Некроманта нет.", NamedTextColor.GRAY));
            return;
        }
        Player op = Bukkit.getPlayer(old);
        stripRole(old);
        plugin.setNecromancer(null, null);
        String name = op != null ? op.getName() : old.toString();
        s.sendMessage(Component.text("✅ Роль снята: " + name
                + ". Легион обращён в прах, эффекты убраны, предметы некроманта больше не работают.",
                NamedTextColor.GREEN));
    }

    private void status(CommandSender s) {
        UUID id = plugin.necromancer();
        if (id == null) {
            s.sendMessage(Component.text("ℹ Некромант не назначен.", NamedTextColor.GRAY));
            return;
        }
        String name = Bukkit.getOfflinePlayer(id).getName();
        s.sendMessage(Component.text("☠ Некромант: " + (name != null ? name : id)
                + ", миньонов: " + Minions.countPets(plugin, id) + "/" + NecromancerPlugin.MAX_PETS,
                NamedTextColor.DARK_PURPLE));
    }

    private void give(CommandSender s, String[] args) {
        if (args.length < 3) {
            s.sendMessage(Component.text("⚠ Использование: /necroadmin give <ник> flower|head <моб> [ур]",
                    NamedTextColor.YELLOW));
            return;
        }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null) {
            s.sendMessage(Component.text("⚠ Игрок \"" + args[1] + "\" не в сети.", NamedTextColor.YELLOW));
            return;
        }
        String what = args[2].toLowerCase(Locale.ROOT);
        switch (what) {
            case "flower", "мак" -> {
                t.getInventory().addItem(NecroItems.flower());
                ok(s, "Мрачный мак → " + t.getName());
            }
            case "head", "голова" -> {
                if (args.length < 4) {
                    s.sendMessage(Component.text("⚠ Укажи моба: зомби|утопленник|кадавр|скелет|зимогор|болотник|пустынник",
                            NamedTextColor.YELLOW));
                    return;
                }
                NecroMob mob = NecroMob.parse(args[3]);
                if (mob == null) {
                    s.sendMessage(Component.text("⚠ Неизвестный моб.", NamedTextColor.YELLOW));
                    return;
                }
                int lvl = 0;
                if (args.length >= 5) {
                    try {
                        lvl = Math.max(0, Math.min(4, Integer.parseInt(args[4])));
                    } catch (NumberFormatException ex) {
                        s.sendMessage(Component.text("⚠ Уровень — число 0-4.", NamedTextColor.YELLOW));
                        return;
                    }
                }
                t.getInventory().addItem(NecroItems.mobHead(t.getUniqueId(), mob, lvl));
                ok(s, mob.ru + " (ур. " + lvl + ") → " + t.getName());
            }
            default -> s.sendMessage(Component.text("⚠ Что выдавать: flower|head.", NamedTextColor.YELLOW));
        }
    }

    private void ok(CommandSender s, String m) {
        s.sendMessage(Component.text("✅ " + m, NamedTextColor.GREEN));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            return Stream.of("grant", "remove", "status", "give")
                    .filter(x -> x.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 2) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        if (args.length == 3) {
            return Stream.of("flower", "head")
                    .filter(x -> x.startsWith(args[2].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 4) {
            return Stream.of(NecroMob.values()).map(m -> m.ru.toLowerCase(Locale.ROOT))
                    .filter(x -> x.startsWith(args[3].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 5) {
            return List.of("0", "1", "2", "3", "4");
        }
        return List.of();
    }
}
