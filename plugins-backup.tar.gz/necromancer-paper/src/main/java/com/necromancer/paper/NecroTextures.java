package com.necromancer.paper;

/** Текстуры голов с minecraft-heads.com (категория humanoid). */
public final class NecroTextures {

    public static final String ZOMBIE =
            "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZGNhMjdmYjJm" +
            "YWY3NDhjNmMzNTcyODhhYjE0MWE2NDgyNzU5MzUyNmQxOWY0MmE1ZGMwMjE0ZGM5YTM1OWU3MCJ9fX0="
            ;

    public static final String DROWNED =
            "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNDRjN2I3NGE2" +
            "MWIyMTc0Yzc5NzQ5YjlkODk2OTgxY2Y1M2JlMzI5YjQ4NTlhMjRhNTU4YWVmYTI3Zjg1MDg0MiJ9fX0="
            ;

    public static final String HUSK =
            "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOWI5ZGE2Yjhk" +
            "MDZjZDI4ZDQ0MTM5OGI5Njc2NmMzYjRmMzcwZGU4NWM3ODk4MjA1ZTVjNDI5ZjE3OGEyNDU5NyJ9fX0="
            ;

    public static final String STRAY =
            "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYWE4ZGM4ZDg2" +
            "ODM1YTg5Yjc4YjUwYTcwYWUyMTA2ZjYxOGYzMjFlMDNiYjdmYjgwZmU0YWMzNjJmZGZkODc5YiJ9fX0="
            ;

    public static final String BOGGED =
            "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYTNiOTAwM2Jh" +
            "MmQwNTU2MmM3NTExOWI4YTYyMTg1YzY3MTMwZTkyODJmN2FjYmFjNGJjMjgyNGMyMWViOTVkOSJ9fX0="
            ;

    public static final String PARCHED =
            "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMjRhZWNlZmY1" +
            "ZjI2ZGQ4NDEzYzVjMDM1NDdjMjM0YWMwMzEwOGQxODdhZjBiOWNkODM0YThjZTEyNTk4NTkxYyJ9fX0="
            ;

    public static final String SKELETON =
            "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOTg4NTgzYjA4" +
            "ZjNiMWIxZWZkZTIxZDZhNDE2ZmI4OGEyM2MxNjliMjUxNDJmMmY1YjZhYTQ3ZmRmYzNiMDM3In19fQ=="
            ;

    private NecroTextures() {}
}