package com.hardcorerevival.paper;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.UUID;

/** 10-tick heartbeat: star-carrier glow, spectator leash, deadlines, action-bar timers. */
final class TickTask implements Runnable {

    private final HardcoreRevivalPlugin plugin;
    private int tick = 0;

    TickTask(HardcoreRevivalPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        tick++;
        var store = plugin.store();
        long now = System.currentTimeMillis();
        boolean slow = tick % 2 == 0; // every 20 ticks

        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();

            // Страховка: наш призрак больше не мёртв по хранилищу, но застрял в спектаторе.
            if (plugin.ghostWatch().remove(id) && !store.isDead(id)
                    && p.getGameMode() == GameMode.SPECTATOR) {
                try {
                    if (p.getSpectatorTarget() != null) p.setSpectatorTarget(null);
                } catch (Throwable ignored) {
                }
                p.setGameMode(Bukkit.getDefaultGameMode());
                p.teleport(Revival.worldSpawnSafe());
                continue;
            }

            // Star carriers glow constantly — only players we glowed ourselves.
            if (p.isDead()) {
                if (plugin.starGlow().remove(id)) {
                    p.setGlowing(false);
                }
            } else {
                boolean hasStar = p.getInventory().contains(org.bukkit.Material.NETHER_STAR);
                if (hasStar && !p.isGlowing()) {
                    p.setGlowing(true);
                    plugin.starGlow().add(id);
                } else if (!hasStar && plugin.starGlow().remove(id)) {
                    p.setGlowing(false);
                } else if (!hasStar && p.isGlowing()
                        && !p.hasPotionEffect(org.bukkit.potion.PotionEffectType.GLOWING)) {
                    // Флаг свечения сохраняется в playerdata: если игрок светился со звездой
                    // при остановке/падении сервера (или при смене версии плагина), после
                    // рестарта он «залипает» подсвеченным навсегда. Гасим такой хвост:
                    // без звезды и без эффекта свечения (спектральная стрелка) подсветки быть не должно.
                    p.setGlowing(false);
                }
            }

            if (store.isDead(id)) {
                long left = store.deadline(id) - now;
                if (left <= 0) {
                    Revival.reviveOnline(plugin, p, null, " (срок наблюдения истёк)");
                    continue;
                }
                // Safety net: ghost mode lost (respawn glitch / another plugin) — reapply.
                if (!p.isDead() && p.getGameMode() != GameMode.SPECTATOR) {
                    Revival.placeSpectator(plugin, p);
                    continue;
                }
                // Белые частицы призрака — редкие и ненавязчивые.
                if (slow) {
                    p.getWorld().spawnParticle(org.bukkit.Particle.WHITE_SMOKE,
                            p.getLocation().add(0, 1.4, 0), 2, 0.25, 0.35, 0.25, 0.005);
                }
                if (tick % 6 == 0) {
                    p.getWorld().spawnParticle(org.bukkit.Particle.SNOWFLAKE,
                            p.getLocation().add(0, 1.0, 0), 1, 0.3, 0.4, 0.3, 0.0);
                }
                if (slow) {
                    String corpse = Corpse.coordsFor(p);
                    if (corpse != null) {
                        p.sendActionBar(net.kyori.adventure.text.Component.text()
                                .append(net.kyori.adventure.text.Component.text(
                                        "☠ Возрождение через " + Effects.formatDuration(left), NamedTextColor.RED))
                                .append(net.kyori.adventure.text.Component.text(
                                        "   •   " + corpse, NamedTextColor.DARK_GRAY))
                                .build());
                    } else {
                        Effects.actionbar(p, "☠ Возрождение через " + Effects.formatDuration(left), NamedTextColor.RED);
                    }
                }
            } else if (slow && store.isProtected(id)) {
                long left = store.protectionUntil(id) - now;
                if (left <= 0) {
                    store.removeProtection(id);
                    Effects.actionbar(p, "✦ Защита от игроков закончилась", NamedTextColor.RED);
                    p.playSound(p.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 0.8f);
                } else {
                    NamedTextColor color = left < 10_000 ? NamedTextColor.RED
                            : left < 60_000 ? NamedTextColor.YELLOW : NamedTextColor.GOLD;
                    String corpse = Corpse.coordsFor(p);
                    if (corpse != null) {
                        p.sendActionBar(net.kyori.adventure.text.Component.text()
                                .append(net.kyori.adventure.text.Component.text(
                                        "✦ Защита от игроков: " + Effects.formatDuration(left), color))
                                .append(net.kyori.adventure.text.Component.text(
                                        "   •   " + corpse, NamedTextColor.DARK_GRAY))
                                .build());
                    } else {
                        Effects.actionbar(p, "✦ Защита от игроков: " + Effects.formatDuration(left), color);
                    }
                }
            } else if (slow) {
                String corpse = Corpse.coordsFor(p);
                if (corpse != null) {
                    Effects.actionbar(p, corpse, NamedTextColor.DARK_GREEN);
                }
            }
        }

        if (tick % 40 == 0) {
            store.save();
            ReviveMenu.refreshAll();
        }
    }
}
