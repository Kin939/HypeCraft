package com.hardcorerevival.paper;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** World-independent persistence: deaths, protections, revive-next-to markers. */
public final class DeathStore {

    private final File file;
    private final Map<UUID, Long> deathDeadline = new ConcurrentHashMap<>();
    private final Map<UUID, String> deathNames = new ConcurrentHashMap<>();
    private final Map<UUID, Long> protections = new ConcurrentHashMap<>();
    /** target → reviver (empty Optional = revive at world spawn). */
    private final Map<UUID, Optional<UUID>> reviveNextTo = new ConcurrentHashMap<>();
    /** World name → epoch ms when the next nether star may drop there (per-world limit). */
    private final Map<String, Long> starDropUnlock = new ConcurrentHashMap<>();

    public DeathStore(File file) {
        this.file = file;
    }

    public synchronized void load() {
        deathDeadline.clear();
        deathNames.clear();
        protections.clear();
        reviveNextTo.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection d = yml.getConfigurationSection("deaths");
        if (d != null) {
            for (String key : d.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(key);
                    deathDeadline.put(id, d.getLong(key + ".deadline"));
                    deathNames.put(id, d.getString(key + ".name", "???"));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        ConfigurationSection p = yml.getConfigurationSection("protections");
        if (p != null) {
            for (String key : p.getKeys(false)) {
                try {
                    protections.put(UUID.fromString(key), p.getLong(key));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        ConfigurationSection r = yml.getConfigurationSection("revive-next-to");
        if (r != null) {
            for (String key : r.getKeys(false)) {
                try {
                    UUID target = UUID.fromString(key);
                    String reviver = r.getString(key, "");
                    if (reviver != null && !reviver.isEmpty()) {
                        reviveNextTo.put(target, Optional.of(UUID.fromString(reviver)));
                    } else {
                        reviveNextTo.put(target, Optional.empty());
                    }
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        ConfigurationSection sd = yml.getConfigurationSection("star-drop.worlds");
        if (sd != null) {
            for (String key : sd.getKeys(false)) {
                starDropUnlock.put(key, sd.getLong(key));
            }
        } else {
            // Migration from v1.2.0 single-server key: treat it as the main world's timer.
            long legacy = yml.getLong("star-drop.unlock-at", 0L);
            if (legacy > 0) {
                starDropUnlock.put("world", legacy);
            }
        }
    }

    public synchronized void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Long> e : deathDeadline.entrySet()) {
            yml.set("deaths." + e.getKey() + ".deadline", e.getValue());
            yml.set("deaths." + e.getKey() + ".name", deathNames.getOrDefault(e.getKey(), "???"));
        }
        for (Map.Entry<UUID, Long> e : protections.entrySet()) {
            yml.set("protections." + e.getKey(), e.getValue());
        }
        for (Map.Entry<UUID, Optional<UUID>> e : reviveNextTo.entrySet()) {
            yml.set("revive-next-to." + e.getKey(), e.getValue().map(UUID::toString).orElse(""));
        }
        for (Map.Entry<String, Long> e : starDropUnlock.entrySet()) {
            yml.set("star-drop.worlds." + e.getKey(), e.getValue());
        }
        try {
            yml.save(file);
        } catch (IOException ex) {
            HardcoreRevivalPlugin.getPlugin(HardcoreRevivalPlugin.class).getLogger()
                    .warning("Не удалось сохранить deaths.yml: " + ex.getMessage());
        }
    }

    /* ---------------- deaths ---------------- */

    public void addDeath(UUID id, long deadline, String name) {
        deathDeadline.put(id, deadline);
        deathNames.put(id, name);
        save();
    }

    public void removeDeath(UUID id) {
        if (deathDeadline.remove(id) != null) {
            deathNames.remove(id);
            save();
        }
    }

    public boolean isDead(UUID id) {
        return deathDeadline.containsKey(id);
    }

    public long deadline(UUID id) {
        return deathDeadline.getOrDefault(id, 0L);
    }

    public String deathName(UUID id) {
        String n = deathNames.get(id);
        if (n != null) return n;
        var off = Bukkit.getOfflinePlayer(id);
        return off != null && off.getName() != null ? off.getName() : "???";
    }

    /** Entries sorted by deadline ascending (longest dead first). */
    public List<Map.Entry<UUID, Long>> deadSorted() {
        List<Map.Entry<UUID, Long>> list = new ArrayList<>();
        for (Map.Entry<UUID, Long> e : deathDeadline.entrySet()) {
            list.add(Map.entry(e.getKey(), e.getValue()));
        }
        list.sort(Map.Entry.comparingByValue());
        return list;
    }

    public UUID findDeadByName(String name) {
        for (Map.Entry<UUID, String> e : deathNames.entrySet()) {
            if (e.getValue().equalsIgnoreCase(name)) return e.getKey();
        }
        return null;
    }

    /* ---------------- protections ---------------- */

    public void setProtection(UUID id, long until) {
        protections.put(id, until);
        save();
    }

    public void removeProtection(UUID id) {
        if (protections.remove(id) != null) save();
    }

    public boolean isProtected(UUID id) {
        return protections.containsKey(id);
    }

    public long protectionUntil(UUID id) {
        return protections.getOrDefault(id, 0L);
    }

    /* ---------------- star drop limit (per world) ---------------- */

    /** Epoch ms when the next nether star may drop from a wither. */
    public long starDropUnlock(String worldName) {
        return starDropUnlock.getOrDefault(worldName, 0L);
    }

    /** Records that a star has just dropped; starts the server-wide cooldown. */
    public void markStarDropped(String worldName, long now, long cooldownMs) {
        starDropUnlock.put(worldName, now + cooldownMs);
        save();
    }

    /** Clears the cooldown for one world (star may drop there immediately). */
    public void resetStarDrop(String worldName) {
        if (starDropUnlock.remove(worldName) != null) save();
    }

    /** Clears every world's cooldown. */
    public void resetAllStarDrops() {
        if (!starDropUnlock.isEmpty()) {
            starDropUnlock.clear();
            save();
        }
    }

    /** Snapshot of per-world cooldowns for display. */
    public Map<String, Long> starDropSnapshot() {
        return Map.copyOf(starDropUnlock);
    }

    /* ---------------- revive placement ---------------- */

    /** @param reviver empty = revive at world spawn instead. */
    public void setReviveNextTo(UUID target, Optional<UUID> reviver) {
        reviveNextTo.put(target, reviver == null ? Optional.empty() : reviver);
        save();
    }

    /** Removes and returns the pending placement (empty = spawn), or null if none. */
    public Optional<UUID> consumeReviveNextTo(UUID target) {
        if (!reviveNextTo.containsKey(target)) return null;
        Optional<UUID> reviver = reviveNextTo.remove(target);
        save();
        return reviver;
    }
}
