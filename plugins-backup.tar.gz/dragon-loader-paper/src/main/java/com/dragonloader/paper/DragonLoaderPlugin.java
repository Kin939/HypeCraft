package com.dragonloader.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Яйцо дракона — прогрузчик чанков 3×3.
 * Поставленное яйцо держит 3×3 чанков загруженными и тикающими даже без игроков.
 * Контуры зоны — куб/колонна из частиц END_ROD. Повторное убийство дракона даёт
 * яйцо убийце (ваниль кладёт яйцо только после первой победы).
 */
public final class DragonLoaderPlugin extends JavaPlugin {

    /** Позиция яйца (блока). */
    public record Pos(String world, int x, int y, int z) {
        static Pos of(Block b) {
            return new Pos(b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
        }

        static Pos parse(String s) {
            String[] p = s.split(";");
            try {
                return new Pos(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]));
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        public String toString() {
            return world + ";" + x + ";" + y + ";" + z;
        }
    }

    private final Set<Pos> loaders = new HashSet<>();
    /** Подтверждение исчезновения яйца: 2 тика подряд после успешной верификации. */
    private final java.util.Map<Pos, Integer> missing = new java.util.concurrent.ConcurrentHashMap<>();
    /** Лоадеры, у которых яйцо хотя бы раз прочиталось честно (чанк дозагрузился). */
    private final java.util.Set<Pos> verified = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private File dataFile;

    public int radius() {
        return Math.max(0, getConfig().getInt("chunk-radius", 1));
    }

    public Set<Pos> loaders() {
        return loaders;
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "loaders.yml");
        loadRegistry();

        // Гарантируем force по реестру (загрузка чанков асинхронная — это нормально).
        for (Pos p : loaders) {
            World w = Bukkit.getWorld(p.world());
            if (w != null) forceAround(w, p.x(), p.z(), true);
        }
        // Яйца, исчезнувшие без события (setblock и т.п.) — по мере загрузки чанков
        // проверяет тик эффектов (с подтверждением 2 тика подряд).

        Bukkit.getPluginManager().registerEvents(new CLListener(this), this);
        var cmd = getCommand("chunkloader");
        var exec = new CLCommand(this);
        cmd.setExecutor(exec);
        cmd.setTabCompleter(exec);

        long interval = Math.max(5, getConfig().getLong("effect.interval-ticks", 20L));
        Bukkit.getScheduler().runTaskTimer(this, () -> CLEffects.tick(this), interval, interval);


        getLogger().info("Яйца-прогрузчики: " + loaders.size() + ". Дракон ждёт.");
    }

    @Override
    public void onDisable() {
        Bukkit.getScheduler().cancelTasks(this);
        saveRegistry();
        for (World w : Bukkit.getWorlds()) {
            for (Pos p : List.copyOf(loaders)) {
                if (p.world().equals(w.getName())) forceAround(w, p.x(), p.z(), false);
            }
        }
    }

    /* ---------------- force 3x3 ---------------- */

    public void forceAround(World w, int blockX, int blockZ, boolean force) {
        int cx = blockX >> 4, cz = blockZ >> 4, r = radius();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                w.setChunkForceLoaded(cx + dx, cz + dz, force);
            }
        }
    }

    /** Снять force у зоны убранного яйца, кроме чанков, покрытых другими яйцами. */
    public void unforceExceptOthers(Pos removed) {
        Set<String> stillCovered = new HashSet<>();
        for (Pos p : loaders) {
            int r = radius();
            int cx = p.x() >> 4, cz = p.z() >> 4;
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    stillCovered.add((cx + dx) + ":" + (cz + dz) + ":" + p.world());
                }
            }
        }
        World w = Bukkit.getWorld(removed.world());
        if (w == null) return;
        int r = radius();
        int cx = removed.x() >> 4, cz = removed.z() >> 4;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (!stillCovered.contains((cx + dx) + ":" + (cz + dz) + ":" + removed.world())) {
                    w.setChunkForceLoaded(cx + dx, cz + dz, false);
                }
            }
        }
    }

    /* ---------------- реестр ---------------- */

    public boolean register(Block egg) {
        Pos p = Pos.of(egg);
        verified.remove(p);
        missing.remove(p);
        if (!loaders.add(p)) return false;
        forceAround(egg.getWorld(), p.x(), p.z(), true);
        saveRegistry();
        return true;
    }

    public boolean unregister(Pos p) {
        missing.remove(p);
        verified.remove(p);
        if (!loaders.remove(p)) return false;
        unforceExceptOthers(p);
        saveRegistry();
        return true;
    }

    public boolean isRegistered(Pos p) {
        return loaders.contains(p);
    }

    public java.util.Map<Pos, Integer> missing() {
        return missing;
    }

    public java.util.Set<Pos> verified() {
        return verified;
    }

    /** Явная зачистка force-чанков, не покрытых ни одним прогрузчиком. */
    public int unforceOrphans(CommandSender feedback) {
        Set<String> covered = new HashSet<>();
        for (Pos p : loaders) {
            int r = radius();
            int cx = p.x() >> 4, cz = p.z() >> 4;
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    covered.add((cx + dx) + ":" + (cz + dz) + ":" + p.world());
                }
            }
        }
        int removed = 0;
        for (World w : Bukkit.getWorlds()) {
            for (var chunk : List.copyOf(w.getForceLoadedChunks())) {
                String key = chunk.getX() + ":" + chunk.getZ() + ":" + w.getName();
                if (!covered.contains(key)) {
                    w.setChunkForceLoaded(chunk.getX(), chunk.getZ(), false);
                    removed++;
                }
            }
        }
        if (feedback != null && removed == 0) {
            feedback.sendMessage(Component.text("ℹ Сирот-прогрузок нет.", NamedTextColor.GRAY));
        }
        return removed;
    }

    /** Убрать яйца, которых физически больше нет (setblock и прочие обходы событий). */
    public void validateAll() {
        for (Pos p : List.copyOf(loaders)) {
            World w = Bukkit.getWorld(p.world());
            if (w == null) continue;
            // Незагруженный чанк — блок ещё нельзя читать честно, проверим позже.
            if (!w.isChunkLoaded(p.x() >> 4, p.z() >> 4)) continue;
            if (w.getBlockAt(p.x(), p.y(), p.z()).getType() != Material.DRAGON_EGG) {
                loaders.remove(p);
                unforceExceptOthers(p);
                getLogger().info("Яйцо-прогрузчик исчез: " + p + " — зона снята.");
            }
        }
        saveRegistry();
    }



    private void loadRegistry() {
        loaders.clear();
        verified.clear();
        missing.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        for (String s : y.getStringList("loaders")) {
            Pos p = Pos.parse(s);
            if (p != null) loaders.add(p);
        }
    }

    public void saveRegistry() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("loaders", loaders.stream().map(Pos::toString).toList());
        try {
            getDataFolder().mkdirs();
            y.save(dataFile);
        } catch (Exception e) {
            getLogger().warning("loaders.yml: " + e.getMessage());
        }
    }

    /* ---------------- утилиты ---------------- */

    public static String prettyWorld(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.equals("world")) return "Обычный мир";
        if (n.contains("nether")) return "Незер";
        if (n.contains("end")) return "Энд";
        return name;
    }
}
