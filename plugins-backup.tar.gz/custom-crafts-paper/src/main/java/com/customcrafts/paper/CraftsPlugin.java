package com.customcrafts.paper;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

/** CustomCrafts: дебаг-стик (декор), невидимый свет ×4, невидимая рамка. */
public final class CraftsPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        CraftsItems.init(this);
        CraftsItems.register(this);

        Bukkit.getPluginManager().registerEvents(new CraftsListener(this), this);

        PluginCommand cc = getCommand("customcrafts");
        CraftsCommand exec = new CraftsCommand(this);
        if (cc != null) {
            cc.setExecutor(exec);
            cc.setTabCompleter(exec);
        }
        getLogger().info("Рецепты зарегистрированы: невидимый свет ×4, палочка отладки, невидимая рамка.");
    }

    public long cooldownMs() {
        return Math.max(0, getConfig().getLong("debug-stick.cooldown-ms", 150L));
    }

    public int lightLevel() {
        return Math.max(0, Math.min(15, getConfig().getInt("light.level", 15)));
    }
}
