package com.hardcorerevival.event;

import com.hardcorerevival.command.ReviveCommands;
import com.hardcorerevival.data.RevivalSavedData;
import com.hardcorerevival.logic.RevivalManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.listener.SubscribeEvent;

import java.util.UUID;

/**
 * Game-bus event handlers (annotated listeners registered via
 * {@code MinecraftForge.EVENT_BUS.register(...)}). The PvP damage guards are
 * predicate listeners registered on the static cancellable event buses.
 */
public class GameEvents {

    /* ---------------- death / respawn ---------------- */

    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            RevivalManager.handleDeath(player);
        }
    }

    /**
     * Forge 26.3 has no respawn-position event: let vanilla respawn the fresh
     * player, then pull them to world spawn and flip them into spectator mode.
     * (A per-tick safety net covers exotic paths like the hardcore
     * "spectate world" button.)
     */
    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        RevivalSavedData data = RevivalManager.data(player.level().getServer());
        if (data.isDead(player.getUUID())) {
            RevivalManager.placeSpectator(player);
        }
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        RevivalSavedData data = RevivalManager.data(player.level().getServer());
        if (data.isDead(player.getUUID())) {
            // Timer kept running while they were away.
            RevivalManager.placeSpectator(player);
        } else if (data.isProtected(player.getUUID()) && data.needsPlacement(player.getUUID())) {
            // Revived while offline (timer ran out or someone used a star).
            data.clearPlacement(player.getUUID());
            RevivalManager.placeRevived(player);
        }
    }

    /* ---------------- PvP protection (two-way) ---------------- */

    /** Guard for {@link LivingHurtEvent} — return true to cancel. */
    public static boolean pvpHurtGuard(LivingHurtEvent event) {
        return pvpGuard(event.getEntity(), event.getSource());
    }

    /** Guard for {@link LivingAttackEvent} — return true to cancel. */
    public static boolean pvpAttackGuard(LivingAttackEvent event) {
        return pvpGuard(event.getEntity(), event.getSource());
    }

    private static boolean pvpGuard(LivingEntity victim, DamageSource source) {
        if (!(victim instanceof ServerPlayer victimPlayer)) return false;
        Entity cause = source.getEntity();
        if (!(cause instanceof ServerPlayer attacker) || attacker == victimPlayer) return false;
        RevivalSavedData data = RevivalManager.data(victimPlayer.level().getServer());
        // Protected players neither take nor deal player damage.
        return data.isProtected(victimPlayer.getUUID()) || data.isProtected(attacker.getUUID());
    }

    /* ---------------- nether star revive ---------------- */

    @SubscribeEvent
    public void onStarUse(PlayerInteractEvent.RightClickItem event) {
        if (event.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!event.getItemStack().is(Items.NETHER_STAR)) return;

        RevivalSavedData data = RevivalManager.data(player.level().getServer());
        if (data.isDead(player.getUUID())) return;

        RevivalManager.sendReviveMenu(player);
    }

    /* ---------------- housekeeping ---------------- */

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent.Post event) {
        RevivalManager.serverTick(event.server());
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        ReviveCommands.register(event.getDispatcher());
    }
}
