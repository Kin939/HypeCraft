package com.testworld.paper;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Per-player sandbox state, persisted in state.yml (survives restarts/crashes).
 *
 * <p>Inventories are captured and replayed verbatim through semantic Bukkit APIs
 * (storage contents, armor, off-hand, ender chest, XP) — the plugin never assumes
 * slot counts, so it works with any inventory layout (including Paper 26.3).
 */
public final class TwState {

    /** One side of the split: main world or sandbox. */
    public static final class Side {
        public ItemStack[] storage;   // PlayerInventory#getStorageContents (verbatim)
        public ItemStack[] armor;     // PlayerInventory#getArmorContents (verbatim)
        public ItemStack offhand;     // PlayerInventory#getItemInOffHand
        public ItemStack[] ender;     // ender chest#getContents (verbatim)
        public int[] xp = {0, 0, 0};  // {level, exp*1000, totalExperience}

        public boolean isEmpty() {
            return storage == null && armor == null && offhand == null && ender == null;
        }
    }

    /** Everything we need to restore a player when they leave the sandbox. */
    public static final class Rec {
        public boolean inTest;
        public boolean oppedByPlugin;
        public GameMode gmBefore;      // null = gamemode untouched
        public String mainWorld;       // world name they came from
        public double[] mainLoc;       // x, y, z, yaw, pitch
        public double[] testLoc;       // last position inside the sandbox
        public Side mainSide = new Side();
        public Side testSide = new Side();
        public boolean mainInitialized;
    }

    private final File file;
    private final Map<UUID, Rec> recs = new ConcurrentHashMap<>();

    public TwState(File file) {
        this.file = file;
    }

    public Rec get(UUID id) {
        return recs.computeIfAbsent(id, k -> new Rec());
    }

    public synchronized void load() {
        recs.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yml.getConfigurationSection("players");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                String base = "players." + key;
                Rec r = new Rec();
                r.inTest = root.getBoolean(key + ".in-test", false);
                r.oppedByPlugin = root.getBoolean(key + ".opped-by-plugin", false);
                String gm = root.getString(key + ".gm-before", "");
                if (!gm.isEmpty()) {
                    try {
                        r.gmBefore = GameMode.valueOf(gm);
                    } catch (IllegalArgumentException ignored) {
                    }
                }
                r.mainWorld = root.getString(key + ".main-world", "world");
                r.mainLoc = readDoubles(root, key + ".main-loc");
                r.testLoc = readDoubles(root, key + ".test-loc");
                Side main = loadSide(root, base + ".main");
                if (main != null) r.mainSide = main;
                Side test = loadSide(root, base + ".test");
                if (test != null) r.testSide = test;
                r.mainInitialized = root.getBoolean(key + ".main-initialized", false);
                recs.put(id, r);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    public synchronized void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Rec> e : recs.entrySet()) {
            String base = "players." + e.getKey();
            Rec r = e.getValue();
            yml.set(base + ".in-test", r.inTest);
            yml.set(base + ".opped-by-plugin", r.oppedByPlugin);
            yml.set(base + ".gm-before", r.gmBefore == null ? "" : r.gmBefore.name());
            yml.set(base + ".main-world", r.mainWorld == null ? "world" : r.mainWorld);
            writeDoubles(yml, base + ".main-loc", r.mainLoc);
            writeDoubles(yml, base + ".test-loc", r.testLoc);
            saveSide(yml, base + ".main", r.mainSide);
            saveSide(yml, base + ".test", r.testSide);
            yml.set(base + ".main-initialized", r.mainInitialized);
        }
        try {
            yml.save(file);
        } catch (IOException ex) {
            Bukkit.getLogger().warning("[TestWorld] Не удалось сохранить state.yml: " + ex.getMessage());
        }
    }

    /* ---------------- side serialization ---------------- */

    private static void saveSide(YamlConfiguration yml, String path, Side s) {
        if (s == null) return;
        if (s.storage != null) {
            yml.set(path + ".storage-len", s.storage.length);
            saveItems(yml, path + ".storage", s.storage);
        }
        if (s.armor != null) {
            saveItems(yml, path + ".armor", s.armor);
        }
        if (s.offhand != null) {
            yml.set(path + ".offhand", s.offhand);
        }
        if (s.ender != null) {
            yml.set(path + ".ender-len", s.ender.length);
            saveItems(yml, path + ".ender", s.ender);
        }
        yml.set(path + ".xp", java.util.List.of(s.xp[0], s.xp[1], s.xp[2]));
    }

    private static Side loadSide(ConfigurationSection root, String path) {
        if (root.getConfigurationSection(path) == null) return null;
        Side s = new Side();
        int storageLen = root.getInt(path + ".storage-len", -1);
        if (storageLen > 0) {
            s.storage = new ItemStack[storageLen];
            fillItems(root.getConfigurationSection(path + ".storage"), s.storage);
        }
        ItemStack[] armor = new ItemStack[4];
        if (fillItems(root.getConfigurationSection(path + ".armor"), armor) > 0) {
            s.armor = armor;
        }
        s.offhand = root.getItemStack(path + ".offhand");
        int enderLen = root.getInt(path + ".ender-len", -1);
        if (enderLen > 0) {
            s.ender = new ItemStack[enderLen];
            fillItems(root.getConfigurationSection(path + ".ender"), s.ender);
        }
        var xp = root.getIntegerList(path + ".xp");
        for (int i = 0; i < 3 && i < xp.size(); i++) s.xp[i] = xp.get(i);
        return s;
    }

    private static void saveItems(YamlConfiguration yml, String path, ItemStack[] items) {
        for (int i = 0; i < items.length; i++) {
            if (items[i] != null) {
                yml.set(path + "." + i, items[i]);
            }
        }
    }

    /** @return number of restored entries. */
    private static int fillItems(ConfigurationSection sec, ItemStack[] target) {
        if (sec == null) return 0;
        int n = 0;
        for (String key : sec.getKeys(false)) {
            try {
                int idx = Integer.parseInt(key);
                ItemStack item = sec.getItemStack(key);
                if (idx >= 0 && idx < target.length && item != null) {
                    target[idx] = item;
                    n++;
                }
            } catch (NumberFormatException ignored) {
            }
        }
        return n;
    }

    private static double[] readDoubles(ConfigurationSection root, String path) {
        var list = root.getDoubleList(path);
        if (list.size() < 3) return null;
        double[] arr = new double[5];
        for (int i = 0; i < 5 && i < list.size(); i++) arr[i] = list.get(i);
        return arr;
    }

    private static void writeDoubles(YamlConfiguration yml, String path, double[] arr) {
        if (arr == null) return;
        yml.set(path, java.util.List.of(arr[0], arr[1], arr[2], arr[3], arr[4]));
    }
}
