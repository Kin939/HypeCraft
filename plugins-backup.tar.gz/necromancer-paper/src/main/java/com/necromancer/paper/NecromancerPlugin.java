package com.necromancer.paper;

import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Некромант — злодей сервера: приручение нежити, легион мертвецов, тёмные пассивки.
 * Один некромант на сервер; роль выдаётся через /necroadmin grant.
 */
public final class NecromancerPlugin extends JavaPlugin {

    /** Максимум одновременно живых миньонов у некроманта. */
    public static final int MAX_PETS = 10;

    private NecroData data;
    /** petEntityUuid -> Pet */
    private final Map<UUID, Pet> pets = new ConcurrentHashMap<>();
    /** Предметы некроманта, изъятые при смерти (возврат на респавне). */
    private final Map<UUID, List<ItemStack>> deathStash = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        NecroKeys.init(this);
        this.data = NecroData.load(this);

        Bukkit.getPluginManager().registerEvents(new NecroListener(this), this);
        var cmd = getCommand("necroadmin");
        var ac = new NecroAdminCommand(this);
        cmd.setExecutor(ac);
        cmd.setTabCompleter(ac);

        Bukkit.getScheduler().runTaskTimer(this, new NecroTick(this), 20L, 20L);

        registerRecipes();

        Minions.scanAllWorlds(this);
        getLogger().info("Некромант готов: легион ждёт хозяина.");
    }

    public boolean isNecromancer(UUID id) {
        return id != null && id.equals(data.necro());
    }

    public boolean isNecromancer(org.bukkit.entity.Player p) {
        return isNecromancer(p.getUniqueId());
    }

    public UUID necromancer() {
        return data.necro();
    }

    public void setNecromancer(UUID id, String name) {
        data.set(id, name);
        data.save();
    }

    public Map<UUID, Pet> pets() {
        return pets;
    }

    /** Мрачный мак: только некромант получает результат (см. NecroListener.onCraft). */
    private void registerRecipes() {
        var recipe = new org.bukkit.inventory.ShapedRecipe(
                new org.bukkit.NamespacedKey(this, "grim_poppy"), NecroItems.flower());
        recipe.shape("ABA", "CDC", "AEA");
        recipe.setIngredient('A', org.bukkit.Material.BLACK_DYE);
        recipe.setIngredient('B', org.bukkit.Material.ROTTEN_FLESH);
        recipe.setIngredient('C', org.bukkit.Material.BONE);
        recipe.setIngredient('D', org.bukkit.Material.DANDELION);
        recipe.setIngredient('E', org.bukkit.Material.ENDER_PEARL);
        Bukkit.addRecipe(recipe);
    }

    public Map<UUID, List<ItemStack>> deathStash() {
        return deathStash;
    }
}
