package com.hardcorerevival.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Труп-зомби: после обычной смерти игрока на месте гибели поднимается зомби,
 * носящий его броню и оружие. Никогда не деспавнится, постоянно светится.
 * Убит — выпадает весь инвентарь погибшего (хранится в PDC зомби).
 */
public final class Corpse {

    /** Реестр живых трупов: uuid зомби -> данные (для координат владельцу). */
    public static final class Info {
        public final UUID owner;
        public volatile String world;
        public volatile double x, y, z;

        Info(UUID owner, Location l) {
            this.owner = owner;
            this.world = l.getWorld().getName();
            this.x = l.getX();
            this.y = l.getY();
            this.z = l.getZ();
        }
    }

    private static final java.util.concurrent.ConcurrentHashMap<UUID, Info> REGISTRY =
            new java.util.concurrent.ConcurrentHashMap<>();

    private Corpse() {}

    /** Зарегистрировать труп (при спавне, загрузке чанка или старте сервера). */
    public static void register(Entity z, UUID owner) {
        REGISTRY.put(z.getUniqueId(), new Info(owner, z.getLocation()));
    }

    public static void unregister(Entity z) {
        REGISTRY.remove(z.getUniqueId());
    }

    /** Восстановить реестр после рестарта: все загруженные трупы. */
    public static void scanLoaded() {
        for (org.bukkit.World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (isCorpse(e)) register(e, ownerOf(e));
            }
        }
    }

    /**
     * Строка координат ближайшего живого трупа игрока (для экшнбара) или null.
     * Труп в выгруженном чанке показывается приблизительно (с тильдой).
     */
    public static String coordsFor(Player p) {
        if (REGISTRY.isEmpty()) return null;
        UUID id = p.getUniqueId();
        Info bestLive = null;
        Entity bestEntity = null;
        double bestDist = Double.MAX_VALUE;
        Info approx = null;
        for (var en : REGISTRY.entrySet()) {
            if (!en.getValue().owner.equals(id)) continue;
            Entity e = Bukkit.getEntity(en.getKey());
            if (e instanceof Zombie z && !z.isDead()) {
                Location l = z.getLocation();
                Info i = en.getValue();
                i.world = l.getWorld().getName();
                i.x = l.getX();
                i.y = l.getY();
                i.z = l.getZ();
                double d = l.getWorld().equals(p.getWorld())
                        ? l.distanceSquared(p.getLocation()) : Double.MAX_VALUE / 2;
                if (d < bestDist) {
                    bestDist = d;
                    bestLive = i;
                    bestEntity = z;
                }
            } else if (e == null && approx == null) {
                approx = en.getValue(); // выгружен — лежит, где оставался
            }
        }
        Info best = bestLive != null ? bestLive : approx;
        if (best == null) return null;
        boolean approxFlag = bestLive == null;
        org.bukkit.World w = Bukkit.getWorld(best.world);
        String worldPrefix;
        if (w == null) worldPrefix = best.world + ": ";
        else worldPrefix = switch (w.getEnvironment()) {
            case NETHER -> "Незер: ";
            case THE_END -> "Энд: ";
            default -> "";
        };
        String s = "Труп: " + worldPrefix + (approxFlag ? "~" : "")
                + (int) Math.floor(best.x) + " " + (int) Math.floor(best.y) + " " + (int) Math.floor(best.z);
        if (bestLive != null && bestDist < Double.MAX_VALUE / 2) {
            s += " (" + (int) Math.sqrt(bestDist) + "м)";
        }
        return s;
    }

    /* ---------------- создание ---------------- */

    /** Спавнит труп-зомби на месте смерти и очищает дроп (вещи уезжают в зомби). */
    public static void spawn(HardcoreRevivalPlugin plugin, Player victim, PlayerDeathEvent event) {
        List<ItemStack> loot = new ArrayList<>();
        for (ItemStack it : event.getDrops()) {
            loot.add(it == null ? null : it.clone());
        }
        if (loot.isEmpty()) return; // нечего охранять — голый труп не нужен
        event.getDrops().clear();

        Location loc = victim.getLocation();
        // Вещи на момент смерти (инвентарь ещё не очищен — ваниль чистит его после события).
        ItemStack helmet = victim.getInventory().getHelmet();
        ItemStack chest = victim.getInventory().getChestplate();
        ItemStack legs = victim.getInventory().getLeggings();
        ItemStack boots = victim.getInventory().getBoots();
        ItemStack offhand = victim.getInventory().getItemInOffHand();
        ItemStack weapon = victim.getInventory().getItemInMainHand();

        Zombie z = loc.getWorld().spawn(loc, Zombie.class);
        z.setRemoveWhenFarAway(false);
        z.setPersistent(true);
        z.setCanPickupItems(false);
        z.customName(Component.text(victim.getName(), NamedTextColor.DARK_RED));
        z.setCustomNameVisible(true);
        // Постоянное свечение — труп видно сквозь стены, его легко найти.
        z.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING,
                PotionEffect.INFINITE_DURATION, 0, false, false, false));
        // Скрытая огнестойкость: труп не сгорит на солнце вместе с вещами.
        z.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE,
                PotionEffect.INFINITE_DURATION, 0, false, false, false));

        // Экипировка жертвы — на зомби (визуально).
        var eq = z.getEquipment();
        if (eq != null) {
            eq.setHelmetDropChance(0f);
            eq.setChestplateDropChance(0f);
            eq.setLeggingsDropChance(0f);
            eq.setBootsDropChance(0f);
            eq.setItemInMainHandDropChance(0f);
            eq.setItemInOffHandDropChance(0f);
            if (helmet != null) eq.setHelmet(helmet.clone());
            else eq.setHelmet(playerHead(victim)); // скин игрока вместо шлема
            if (chest != null) eq.setChestplate(chest.clone());
            if (legs != null) eq.setLeggings(legs.clone());
            if (boots != null) eq.setBoots(boots.clone());
            if (offhand != null) eq.setItemInOffHand(offhand.clone());
            if (weapon != null && weapon.getType() != Material.AIR) eq.setItemInMainHand(weapon.clone());
        }

        // Весь лут — в PDC зомби (переживает рестарты).
        PersistentDataContainer pdc = z.getPersistentDataContainer();
        pdc.set(HardcoreRevivalPlugin.corpseKindKey(), PersistentDataType.STRING, "corpse");
        pdc.set(HardcoreRevivalPlugin.corpseOwnerKey(), PersistentDataType.STRING, victim.getUniqueId().toString());
        pdc.set(HardcoreRevivalPlugin.corpseNameKey(), PersistentDataType.STRING, victim.getName());
        pdc.set(HardcoreRevivalPlugin.corpseLootKey(), PersistentDataType.BYTE_ARRAY,
                ItemStack.serializeItemsAsBytes(loot));

        register(z, victim.getUniqueId());

        victim.sendMessage(Component.text("☠ Твой труп поднялся на месте гибели и бродит там со всеми твоими вещами. "
                + "Он светится — найди и убей его, чтобы вернуть своё.", NamedTextColor.DARK_RED));
    }

    /** Голова с профилем погибшего (для зомби без шлема) — скин игрока. */
    private static ItemStack playerHead(Player victim) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        try {
            meta.setPlayerProfile(victim.getPlayerProfile());
        } catch (Throwable ignored) {
            // без профиля останется стев-голова — не критично
        }
        head.setItemMeta(meta);
        return head;
    }

    /* ---------------- проверки ---------------- */

    public static boolean isCorpse(Entity e) {
        if (!(e instanceof Zombie)) return false;
        return "corpse".equals(e.getPersistentDataContainer()
                .get(HardcoreRevivalPlugin.corpseKindKey(), PersistentDataType.STRING));
    }

    /** Владелец трупа из PDC или null. */
    public static UUID ownerOf(Entity e) {
        String s = e.getPersistentDataContainer()
                .get(HardcoreRevivalPlugin.corpseOwnerKey(), PersistentDataType.STRING);
        try {
            return s == null ? null : UUID.fromString(s);
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    public static boolean isOwner(Entity corpse, UUID player) {
        String s = corpse.getPersistentDataContainer()
                .get(HardcoreRevivalPlugin.corpseOwnerKey(), PersistentDataType.STRING);
        try {
            return s != null && UUID.fromString(s).equals(player);
        } catch (IllegalArgumentException ex) {
            return false;
        }
    }

    /* ---------------- смерть трупа ---------------- */

    /** true, если событие обработано (мёртвый труп выпускает лут). */
    public static boolean handleDeath(HardcoreRevivalPlugin plugin, EntityDeathEvent event) {
        if (!isCorpse(event.getEntity())) return false;
        unregister(event.getEntity());
        byte[] data = event.getEntity().getPersistentDataContainer()
                .get(HardcoreRevivalPlugin.corpseLootKey(), PersistentDataType.BYTE_ARRAY);
        String name = event.getEntity().getPersistentDataContainer()
                .get(HardcoreRevivalPlugin.corpseNameKey(), PersistentDataType.STRING);
        if (data != null) {
            try {
                for (ItemStack it : ItemStack.deserializeItemsFromBytes(data)) {
                    if (it != null && !it.getType().isAir()) event.getDrops().add(it);
                }
            } catch (Exception ex) {
                plugin.getLogger().warning("corpse loot: " + ex.getMessage());
            }
        }
        if (event.getEntity().getKiller() instanceof Player k) {
            k.sendMessage(Component.text("☠ Труп " + (name != null ? name : "игрока")
                    + " повержен — вещи выпали на землю.", NamedTextColor.GRAY));
        }
        var loc = event.getEntity().getLocation();
        loc.getWorld().spawnParticle(org.bukkit.Particle.LARGE_SMOKE,
                loc.add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.02);
        for (Player p : loc.getWorld().getNearbyPlayers(loc, 16)) {
            p.playSound(loc, Sound.ENTITY_ZOMBIE_DEATH, 0.8f, 0.6f);
        }
        return true;
    }
}
