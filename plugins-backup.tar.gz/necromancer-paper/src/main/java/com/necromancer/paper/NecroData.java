package com.necromancer.paper;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.UUID;

/** data.yml — кто некромант (переживает рестарт). */
final class NecroData {

    private final NecromancerPlugin plugin;
    private final File file;
    private UUID necro;
    private String name;

    private NecroData(NecromancerPlugin plugin, File file) {
        this.plugin = plugin;
        this.file = file;
    }

    static NecroData load(NecromancerPlugin plugin) {
        File f = new File(plugin.getDataFolder(), "data.yml");
        NecroData d = new NecroData(plugin, f);
        if (f.exists()) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
            String id = y.getString("necromancer.uuid", "");
            if (!id.isEmpty()) {
                try {
                    d.necro = UUID.fromString(id);
                } catch (IllegalArgumentException e) {
                    d.necro = null;
                }
            }
            d.name = y.getString("necromancer.name");
        }
        return d;
    }

    UUID necro() {
        return necro;
    }

    void set(UUID id, String name) {
        this.necro = id;
        this.name = name;
    }

    void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("necromancer.uuid", necro == null ? "" : necro.toString());
        y.set("necromancer.name", name == null ? "" : name);
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (Exception e) {
            plugin.getLogger().warning("data.yml: " + e.getMessage());
        }
    }
}
