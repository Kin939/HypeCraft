package com.anyportal.paper;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Реестр кастомных порталов. Ключи — упакованные в long координаты
 * (стандартная упаковка Minecraft: 26 бит x, 26 бит z, 12 бит y).
 */
public final class PortalRegistry {

    /** Один портал: мир + набор блоков-нутра. */
    public static final class Portal {
        public final String id;
        public final String world;
        public final Set<Long> blocks;

        Portal(String id, String world, Set<Long> blocks) {
            this.id = id;
            this.world = world;
            this.blocks = blocks;
        }
    }

    private final AnyPortalPlugin plugin;
    private final File file;
    private final Map<String, Portal> portals = new ConcurrentHashMap<>();
    /** world name → (packed pos → portal id) — быстрый lookup из физик-событий. */
    private final Map<String, Map<Long, String>> index = new ConcurrentHashMap<>();

    public PortalRegistry(AnyPortalPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "portals.yml");
    }

    /* ---------------- упаковка координат ---------------- */

    public static long pack(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFFL);
    }

    public static int unpackX(long v) {
        return (int) (v >> 38);
    }

    public static int unpackY(long v) {
        return (int) (v << 52 >> 52);
    }

    public static int unpackZ(long v) {
        return (int) (v << 26 >> 38);
    }

    /* ---------------- доступ ---------------- */

    public Map<String, Portal> all() {
        return portals;
    }

    /** Портал, которому принадлежит блок (или null). */
    public Portal locate(String world, int x, int y, int z) {
        Map<Long, String> m = index.get(world);
        if (m == null) return null;
        String id = m.get(pack(x, y, z));
        return id == null ? null : portals.get(id);
    }

    public Portal byPrefix(String idPrefix) {
        String p = idPrefix.toLowerCase(Locale.ROOT);
        Portal exact = portals.get(p);
        if (exact != null) return exact;
        for (Portal portal : portals.values()) {
            if (portal.id.startsWith(p)) return portal;
        }
        return null;
    }

    /* ---------------- изменение ---------------- */

    /** Создать портал из блоков. @return id или null, если место занято другим порталом. */
    public String create(World world, List<Long> cells) {
        Map<Long, String> m = index.computeIfAbsent(world.getName(), k -> new ConcurrentHashMap<>());
        for (Long cell : cells) {
            if (m.containsKey(cell)) return null; // пересечение с существующим
        }
        String id = UUID.randomUUID().toString().substring(0, 8);
        for (Long cell : cells) m.put(cell, id);
        portals.put(id, new Portal(id, world.getName(), new java.util.HashSet<>(cells)));
        save();
        return id;
    }

    /** Удалить портал из реестра (блоки чистит вызывающий). */
    public Portal remove(String id) {
        Portal removed = portals.remove(id);
        if (removed == null) return null;
        Map<Long, String> m = index.get(removed.world);
        if (m != null) {
            m.values().removeIf(v -> v.equals(id));
        }
        save();
        return removed;
    }

    public void clear() {
        portals.clear();
        index.clear();
        save();
    }

    /* ---------------- файл ---------------- */

    public void load() {
        portals.clear();
        index.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("portals");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            String world = root.getString(id + ".world");
            List<String> raw = root.getStringList(id + ".blocks");
            if (world == null || raw.isEmpty()) continue;
            Set<Long> cells = new java.util.HashSet<>();
            for (String s : raw) {
                String[] parts = s.split(",");
                try {
                    cells.add(pack(Integer.parseInt(parts[0].trim()),
                            Integer.parseInt(parts[1].trim()),
                            Integer.parseInt(parts[2].trim())));
                } catch (Exception ignored) {
                }
            }
            if (cells.isEmpty()) continue;
            portals.put(id, new Portal(id, world, cells));
            Map<Long, String> m = index.computeIfAbsent(world, k -> new HashMap<>());
            for (Long cell : cells) m.put(cell, id);
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Portal p : portals.values()) {
            List<String> raw = new ArrayList<>(p.blocks.size());
            for (Long v : p.blocks) {
                raw.add(unpackX(v) + "," + unpackY(v) + "," + unpackZ(v));
            }
            y.set("portals." + p.id + ".world", p.world);
            y.set("portals." + p.id + ".blocks", raw);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (Exception ex) {
            plugin.getLogger().warning("portals.yml: " + ex.getMessage());
        }
    }
}
