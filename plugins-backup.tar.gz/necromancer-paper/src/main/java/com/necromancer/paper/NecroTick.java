package com.necromancer.paper;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

/**
 * Тик некроманта (раз в секунду):
 * пассивки (регенерация/ночное зрение без частиц), страх жителей, агрессия големов,
 * редкий чёрный дым + дисциплина легиона (охота/патруль, огнестойкость).
 */
final class NecroTick implements Runnable {

    private final NecromancerPlugin plugin;
    private int t = 0;

    NecroTick(NecromancerPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        t++;
        boolean slow = t % 2 == 0;  // каждые ~2 сек
        boolean rarer = t % 3 == 0; // каждые ~3 сек

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!plugin.isNecromancer(p) || p.isDead()) continue;

            if (slow) {
                // Регенерация 1 и ночное зрение — частицы и иконки выключены.
                p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 70, 0, false, false, false));
                p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 600, 0, false, false, false));
            }
            if (rarer) {
                // Редкие незаметные чёрные частицы.
                p.getWorld().spawnParticle(Particle.SMOKE,
                        p.getLocation().add(0, 1.1, 0), 2, 0.35, 0.45, 0.35, 0.002);
            }
            if (slow) {
                burnInSun(p);
            }
            if (slow) {
                // Големы видят в некроманте врага.
                for (Entity e : p.getNearbyEntities(12, 12, 12)) {
                    if (e instanceof IronGolem g && g.isValid() && !g.isDead()) g.setTarget(p);
                }
                // Жители в ужасе разбегаются.
                for (Entity e : p.getNearbyEntities(8, 8, 8)) {
                    if (!(e instanceof Villager v)) continue;
                    Vector away = v.getLocation().toVector().subtract(p.getLocation().toVector());
                    away.setY(0);
                    if (away.lengthSquared() < 0.05) {
                        away = new Vector(Math.random() - 0.5, 0, Math.random() - 0.5);
                    }
                    if (away.lengthSquared() > 0) {
                        v.setVelocity(away.normalize().multiply(0.35).setY(0.12));
                    }
                    if (t % 6 == 0) {
                        v.getWorld().spawnParticle(Particle.ANGRY_VILLAGER,
                                v.getLocation().add(0, 2, 0), 1, 0, 0, 0, 0);
                    }
                }
            }
        }

        maintainPets();
    }

    /**
     * Некромант — тоже нежить: горит на солнце без шлема.
     * Спасает любой шлем в слоте головы; в воде, под крышей, ночью, в грозу
     * и в креативе/наблюдателе горения нет.
     */
    private void burnInSun(Player p) {
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        if (p.getInventory().getHelmet() != null || p.isInWater()) return;
        var w = p.getWorld();
        if (w.getEnvironment() != org.bukkit.World.Environment.NORMAL) return;
        long dayTick = w.getTime() % 24000L;
        if (dayTick >= 12300L || w.hasStorm()) return; // ночь или гроза
        if (p.getLocation().getBlock().getLightFromSky() < 14) return; // под крышей/в тени
        p.setFireTicks(Math.max(p.getFireTicks(), 50));
        if (t % 5 == 0) {
            p.sendActionBar(net.kyori.adventure.text.Component.text(
                    "☀ Солнце жжёт некроманта! Спасёт только шлем.",
                    net.kyori.adventure.text.format.NamedTextColor.GOLD));
        }
    }

    private void maintainPets() {
        boolean slow = t % 2 == 0;
        var it = plugin.pets().entrySet().iterator();
        while (it.hasNext()) {
            var entry = it.next();
            Pet pet = entry.getValue();
            Entity en = Bukkit.getEntity(entry.getKey());
            if (!(en instanceof Mob mob) || mob.isDead()) {
                it.remove();
                continue;
            }
            if (slow) {
                mob.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE,
                        PotionEffect.INFINITE_DURATION, 0, false, false, false));
            }
            if (pet.isHunting()) {
                Player tgt = pet.target == null ? null : Bukkit.getPlayer(pet.target);
                boolean gone = tgt == null || tgt.isDead()
                        || tgt.getGameMode() == GameMode.SPECTATOR
                        || tgt.getWorld() != mob.getWorld();
                if (gone) {
                    // Цель недосягаема (умер/вышел/сменил мир) — миньон замирает и патрулирует.
                    pet.mode = "patrol";
                    pet.anchor = mob.getLocation().clone();
                    Minions.writePdc(mob, pet);
                    mob.setTarget(null);
                    continue;
                }
                mob.setTarget(tgt);
            } else if (pet.anchor != null) {
                if (!mob.getWorld().equals(pet.anchor.getWorld())) {
                    mob.teleport(pet.anchor);
                    continue;
                }
                if (mob.getLocation().distanceSquared(pet.anchor) > 100) {
                    mob.setTarget(null);
                    mob.getPathfinder().moveTo(pet.anchor, 1.1);
                }
            }
        }
    }
}
