package com.hardcorerevival.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;
import java.util.UUID;

/** Shared death → spectator → revive flow. */
public final class Revival {

    private Revival() {
    }

    public static Location worldSpawnSafe() {
        Location spawn = Bukkit.getWorlds().get(0).getSpawnLocation();
        return new Location(spawn.getWorld(),
                spawn.getX() + 0.5,
                spawn.getWorld().getHighestBlockYAt(spawn.getBlockX(), spawn.getBlockZ()) + 1.0,
                spawn.getZ() + 0.5,
                spawn.getYaw(),
                spawn.getPitch());
    }

    /* ---------------- spectator placement ---------------- */

    public static void placeSpectator(HardcoreRevivalPlugin plugin, Player p) {
        if (p.isDead()) return; // death screen — will be handled after respawn
        UUID id = p.getUniqueId();
        long left = plugin.store().deadline(id) - System.currentTimeMillis();
        plugin.ghostWatch().add(id); // под контролем: если застрянет в спектаторе живым — вытащим
        Ghost.applyMode(plugin, p);
        Ghost.spawnVisuals(plugin, p);
        p.teleport(worldSpawnSafe());
        Effects.title(p, "ТЫ ПРИЗРАК", NamedTextColor.DARK_RED,
                "Лети свободно · ЛКМ по игроку или мобу — телепорт", NamedTextColor.GRAY);
        Effects.actionbar(p, "☠ Возрождение через " + Effects.formatDuration(left), NamedTextColor.RED);
        Effects.spectateDoom(p.getLocation());
    }

    /* ---------------- revives ---------------- */

    /**
     * Revives a player. {@code near} — reviver location (may be null → world spawn).
     *
     * @return true if the player was actually revived now (online)
     */
    public static boolean revive(HardcoreRevivalPlugin plugin, UUID target, Location near, String cause) {
        if (!plugin.store().isDead(target)) return false;
        plugin.store().removeDeath(target);
        Player online = Bukkit.getPlayer(target);
        if (online != null && online.isOnline()) {
            reviveOnline(plugin, online, near, cause);
            return true;
        }
        // Offline: schedule placement on next join.
        plugin.store().setProtection(target, System.currentTimeMillis() + plugin.cfg().protectionMs());
        plugin.store().setReviveNextTo(target, Optional.empty()); // empty = world spawn
        Effects.broadcast(plugin, Component.text("✨ ", NamedTextColor.GOLD)
                .append(Component.text(plugin.store().deathName(target), NamedTextColor.YELLOW))
                .append(Component.text(" возродился!" + cause + " (зайди на сервер)", NamedTextColor.GRAY)));
        return false;
    }

    public static void reviveOnline(HardcoreRevivalPlugin plugin, Player p, Location near, String cause) {
        UUID id = p.getUniqueId();
        plugin.store().removeDeath(id);
        plugin.store().setProtection(id, System.currentTimeMillis() + plugin.cfg().protectionMs());

        Location dest = near != null ? near.clone() : worldSpawnSafe();
        plugin.ghostWatch().remove(id);
        Ghost.removeVisuals(plugin, p);
        // Призрак мог быть вселён в игрока/моба: при смене режима прямо из чужой
        // камеры клиент остаётся «отсоединённым», и игрок для всех невидим.
        try {
            if (p.getSpectatorTarget() != null) p.setSpectatorTarget(null);
        } catch (Throwable ignored) {
        }
        p.setGameMode(Bukkit.getDefaultGameMode());
        p.teleport(dest);
        Effects.reviveBurst(dest);
        Effects.title(p, "ТЫ ВОЗРОЖДЁН", NamedTextColor.GOLD,
                "Защита от игроков: " + Effects.formatDuration(plugin.cfg().protectionMs()), NamedTextColor.AQUA);
        Effects.broadcast(plugin, Component.text("✨ ", NamedTextColor.GOLD)
                .append(Component.text(p.getName(), NamedTextColor.YELLOW))
                .append(Component.text(" возродился!" + cause, NamedTextColor.GRAY)));
        // Страховка от гонок (респавн/вселение в момент возрождения): если через
        // 2 тика игрок всё ещё в спектаторе без причины — вытаскиваем принудительно.
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && !plugin.store().isDead(p.getUniqueId())
                    && p.getGameMode() == GameMode.SPECTATOR) {
                p.setGameMode(Bukkit.getDefaultGameMode());
                p.teleport(dest);
            }
        }, 2L);
    }

    /* ---------------- star passive save ---------------- */

    /** @return true if the star saved the player (drops cleared, respawn scheduled). */
    public static boolean tryStarSave(HardcoreRevivalPlugin plugin, PlayerDeathEvent event) {
        Player p = event.getEntity();
        if (!plugin.cfg().starSaveEnabled()) return false;
        if (!p.getInventory().contains(Material.NETHER_STAR)) return false;

        // Things dissolve — nothing drops.
        event.getDrops().clear();
        if (plugin.cfg().starSaveConsume()) {
            p.getInventory().removeItem(new ItemStack(Material.NETHER_STAR, 1));
        }
        plugin.store().removeDeath(p.getUniqueId());
        plugin.justSaved().add(p.getUniqueId());

        Effects.broadcast(plugin, Component.text("✨ ", NamedTextColor.GOLD)
                .append(Component.text(p.getName(), NamedTextColor.YELLOW))
                .append(Component.text(" спасён звездой Визера! Вещи растворились звёздной пылью...", NamedTextColor.GRAY)));

        // Auto-respawn shortly after the death screen appears.
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && p.isDead()) {
                try {
                    p.spigot().respawn();
                } catch (Exception ex) {
                    // Player will respawn manually; justSaved flag still applies.
                }
            }
        }, 3L);
        return true;
    }

    /* ---------------- wither star (direct reward, per world) ---------------- */

    /**
     * The wither never drops the star physically. The killer receives it straight
     * into their inventory — but only if this world's cooldown is over. Killing
     * the wither without a player killer changes nothing (no star, no timer).
     */
    public static void handleWitherDrop(HardcoreRevivalPlugin plugin, org.bukkit.event.entity.EntityDeathEvent event) {
        if (!(event.getEntity() instanceof org.bukkit.entity.Wither)) return;
        // Vanilla star drop is removed unconditionally — the star is never on the ground.
        event.getDrops().removeIf(item -> item != null && item.getType() == Material.NETHER_STAR);

        Player killer = event.getEntity().getKiller();
        if (killer == null) return;

        long now = System.currentTimeMillis();
        var store = plugin.store();
        String worldName = event.getEntity().getWorld().getName();

        if (now < store.starDropUnlock(worldName)) {
            long left = store.starDropUnlock(worldName) - now;
            Effects.broadcast(plugin, Component.text("☠ ", NamedTextColor.DARK_PURPLE)
                    .append(Component.text(killer.getName(), NamedTextColor.LIGHT_PURPLE))
                    .append(Component.text(" поверг иссушителя. ", NamedTextColor.GRAY))
                    .append(Component.text("Вы сможете получить незер звезду через: "
                            + Effects.formatDuration(left), NamedTextColor.YELLOW)));
            return;
        }

        // Cooldown over: hand the star to the killer and start this world's timer.
        store.markStarDropped(worldName, now, plugin.cfg().witherCooldownMs());
        var leftover = killer.getInventory().addItem(new ItemStack(Material.NETHER_STAR));
        boolean droppedAtFeet = false;
        for (var rest : leftover.values()) {
            var dropped = killer.getWorld().dropItemNaturally(killer.getLocation(), rest);
            dropped.setGlowing(true);
            droppedAtFeet = true;
        }
        Effects.broadcast(plugin, Component.text("☠ ", NamedTextColor.DARK_PURPLE)
                .append(Component.text(killer.getName(), NamedTextColor.LIGHT_PURPLE))
                .append(Component.text(" поверг иссушителя и получает ", NamedTextColor.GRAY))
                .append(Component.text("звезду Визера! ✨", NamedTextColor.AQUA))
                .append(droppedAtFeet
                        ? Component.text(" (инвентарь полон — звезда упала под ногами и светится)",
                                NamedTextColor.DARK_GRAY)
                        : Component.empty()));
    }
}
