package com.necromancer.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Меню легиона (открывается ПКМ по голове моба):
 * слот 4 — голова моба с данными, 13 — прокачка (зелёная панель),
 * 19-21 — онлайн-игроки (охота), 22 — оранжевая панель-страницы, 25 — призыв к себе (патруль).
 */
public final class NecroMenu implements InventoryHolder {

    private final NecromancerPlugin plugin;
    private final Player player;
    private final int handSlot;
    private final UUID headUid;
    private final NecroMob mob;
    private int page;
    private Inventory inv;

    private NecroMenu(NecromancerPlugin plugin, Player player, int handSlot, UUID headUid, NecroMob mob) {
        this.plugin = plugin;
        this.player = player;
        this.handSlot = handSlot;
        this.headUid = headUid;
        this.mob = mob;
    }

    public static void open(NecromancerPlugin plugin, Player p) {
        ItemStack held = p.getInventory().getItemInMainHand();
        NecroMob mob = NecroItems.mobOf(held);
        if (mob == null) return;
        NecroMenu m = new NecroMenu(plugin, p, p.getInventory().getHeldItemSlot(),
                NecroItems.uidOf(held), mob);
        m.inv = Bukkit.createInventory(m, 27,
                Component.text("☠ Легион: ", NamedTextColor.DARK_RED)
                        .append(Component.text(mob.ru, NamedTextColor.RED)));
        m.rebuild();
        p.openInventory(m.inv);
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }

    /** Голова в той же руке, что открывала меню (по уникальному id). */
    private ItemStack heldValid() {
        ItemStack held = player.getInventory().getItem(handSlot);
        if (held == null || !NecroItems.KIND_HEAD.equals(NecroItems.kindOf(held))) return null;
        if (!headUid.equals(NecroItems.uidOf(held))) return null;
        return held;
    }

    private List<Player> targets() {
        List<Player> list = new ArrayList<>();
        for (Player pl : Bukkit.getOnlinePlayers()) {
            if (!pl.getUniqueId().equals(player.getUniqueId())) list.add(pl);
        }
        list.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        return list;
    }

    private void rebuild() {
        inv.clear();
        ItemStack held = heldValid();
        int lvl = held == null ? 0 : NecroItems.levelOf(held);

        // Слот 4 — голова моба со свежими данными
        if (held != null) {
            ItemStack icon = held.clone();
            NecroItems.refreshHead(icon);
            inv.setItem(4, icon);
        }

        inv.setItem(13, upgradeButton(lvl));

        List<Player> targets = targets();
        int perPage = 3;
        int pages = Math.max(1, (targets.size() + perPage - 1) / perPage);
        if (page >= pages) page = pages - 1;
        for (int i = 0; i < perPage; i++) {
            int idx = page * perPage + i;
            if (idx < targets.size()) inv.setItem(19 + i, playerHead(targets.get(idx)));
        }
        if (targets.isEmpty()) {
            inv.setItem(19, simple(Material.BARRIER, "Никого нет",
                    new String[]{"Некому охотиться — сервер пуст."}, NamedTextColor.GRAY));
        }
        boolean more = page + 1 < pages;
        inv.setItem(22, simple(Material.ORANGE_STAINED_GLASS_PANE,
                more ? "Ещё игроки → (стр. " + (page + 2) + "/" + pages + ")" : "Игроков больше нет",
                more ? new String[]{"Клик — следующая страница"} : null,
                more ? NamedTextColor.GOLD : NamedTextColor.GRAY));

        // Слот 25 — сам некромант: призыв в патруль
        ItemStack self = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) self.getItemMeta();
        sm.setOwningPlayer(player);
        sm.displayName(Component.text("☠ Призвать к себе", NamedTextColor.DARK_PURPLE));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text(mob.ru + " выкопается рядом с тобой", NamedTextColor.GRAY));
        lore.add(Component.text("и будет патрулировать местность (радиус 10)", NamedTextColor.GRAY));
        sm.lore(lore);
        self.setItemMeta(sm);
        inv.setItem(25, self);
    }

    private ItemStack upgradeButton(int lvl) {
        if (lvl >= 4) {
            return simple(Material.GRAY_STAINED_GLASS_PANE, "⬆ Максимальный уровень",
                    new String[]{"Незеритовая мощь достигнута."}, NamedTextColor.DARK_GRAY);
        }
        ItemStack it = new ItemStack(Material.LIME_STAINED_GLASS_PANE);
        ItemMeta meta = it.getItemMeta();
        int next = lvl + 1;
        meta.displayName(Component.text("⬆ Прокачать: " + NecroMob.levelName(next), NamedTextColor.GREEN));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Цена: " + NecroItems.upgradePriceText(next), NamedTextColor.YELLOW));
        lore.add(Component.text("Предметы возьмутся из инвентаря", NamedTextColor.GRAY));
        lore.add(Component.text("Станет: " + NecroItems.armorName(next)
                + ", " + NecroItems.weaponName(mob, next), NamedTextColor.AQUA));
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack playerHead(Player t) {
        ItemStack it = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) it.getItemMeta();
        meta.setOwningPlayer(t);
        meta.displayName(Component.text("⚔ Охота: ", NamedTextColor.DARK_RED)
                .append(Component.text(t.getName(), NamedTextColor.RED)));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Клик — " + mob.ru + " выкопается рядом с " + t.getName(), NamedTextColor.GRAY));
        lore.add(Component.text("и бросится на него. Тише воды, трава ниже…", NamedTextColor.DARK_GRAY));
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack simple(Material m, String name, String[] lore, NamedTextColor color) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text(name, color));
        if (lore != null) {
            List<Component> lc = new ArrayList<>();
            for (String s : lore) lc.add(Component.text(s, NamedTextColor.DARK_GRAY));
            meta.lore(lc);
        }
        it.setItemMeta(meta);
        return it;
    }

    void click(int slot, Player who) {
        if (who != player) return;
        ItemStack held = heldValid();
        if (held == null) {
            player.closeInventory();
            player.sendMessage(Component.text("⚠ Голова пропала из руки — меню закрыто.", NamedTextColor.YELLOW));
            return;
        }
        switch (slot) {
            case 13 -> upgrade(held);
            case 19, 20, 21 -> summonHunt(slot - 19);
            case 22 -> {
                page++;
                rebuild();
            }
            case 25 -> summon(null);
            default -> {}
        }
    }

    private void upgrade(ItemStack held) {
        int lvl = NecroItems.levelOf(held);
        if (lvl >= 4) {
            player.sendMessage(Component.text("ℹ Это уже незеритовый уровень.", NamedTextColor.GRAY));
            return;
        }
        int next = lvl + 1;
        Material mat = NecroItems.upgradeMaterial(next);
        int count = NecroItems.upgradeCount(next);
        if (!player.getInventory().containsAtLeast(new ItemStack(mat), count)) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.6f);
            player.sendMessage(Component.text("✖ Не хватает: " + NecroItems.upgradePriceText(next),
                    NamedTextColor.YELLOW));
            return;
        }
        player.getInventory().removeItem(new ItemStack(mat, count));
        NecroItems.setLevel(held, next);
        player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_USE, 0.35f, 1.5f);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.6f);
        player.sendMessage(Component.text("⬆ " + mob.ru + " прокачан: " + NecroMob.levelName(lvl)
                + " → " + NecroMob.levelName(next), NamedTextColor.GREEN));
        rebuild();
    }

    private void summonHunt(int idxInPage) {
        List<Player> targets = targets();
        int idx = page * 3 + idxInPage;
        if (idx >= targets.size()) return;
        summon(targets.get(idx));
    }

    private void summon(Player target) {
        int count = Minions.countPets(plugin, player.getUniqueId());
        if (count >= NecromancerPlugin.MAX_PETS) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.6f);
            player.sendMessage(Component.text("☠ Легион полон: " + count + "/" + NecromancerPlugin.MAX_PETS
                    + ". Дождись гибели миньона.", NamedTextColor.YELLOW));
            return;
        }
        ItemStack held = heldValid();
        if (held == null) return;
        Location base = (target != null ? target.getLocation() : player.getLocation()).clone();
        Location loc = Minions.findSpawnSpot(base);
        Mob m = Minions.summon(plugin, player, held, loc, target == null ? null : target.getUniqueId());
        if (m == null) return;
        player.closeInventory();
        if (target != null) {
            player.sendMessage(Component.text("☠ " + mob.ru + " выкопался возле " + target.getName()
                    + " и пошёл по его след… (" + (count + 1) + "/" + NecromancerPlugin.MAX_PETS + ")",
                    NamedTextColor.DARK_PURPLE));
        } else {
            player.sendMessage(Component.text("☠ " + mob.ru + " выкопался рядом и встал в дозор. ("
                    + (count + 1) + "/" + NecromancerPlugin.MAX_PETS + ")", NamedTextColor.DARK_PURPLE));
        }
    }
}
