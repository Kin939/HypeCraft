package com.testworld.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;

/**
 * /tw                 — go to the sandbox (or back if already there)
 * /tw back            — return to the main world
 * /tw create          — pre-create the sandbox world (console-friendly)
 * /tw add|remove <ник>— manage the allowed list (testworld.admin / console)
 * /tw reload | info
 */
public class TwCommands implements CommandExecutor, TabCompleter {

    private final TestWorldPlugin plugin;

    public TwCommands(TestWorldPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);

        switch (sub) {
            case "" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(Component.text("Консоль: используйте  tw create  для создания мира.",
                            NamedTextColor.GRAY));
                    return true;
                }
                if (!plugin.cfg().isAllowed(p)) {
                    p.sendMessage(Component.text("⚠ Песочница только для тестовых админов. "
                            + "Владелец может добавить вас: tw add " + p.getName(), NamedTextColor.YELLOW));
                    return true;
                }
                if (plugin.manager().inTest(p)) {
                    plugin.manager().exit(p);
                } else {
                    plugin.manager().enter(p);
                }
            }
            case "back" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(Component.text("Только для игроков.", NamedTextColor.RED));
                    return true;
                }
                if (!plugin.manager().inTest(p)) {
                    p.sendMessage(Component.text("ℹ Ты и так в обычном мире.", NamedTextColor.GRAY));
                    return true;
                }
                plugin.manager().exit(p);
            }
            case "go" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(Component.text("Только для игроков.", NamedTextColor.RED));
                    return true;
                }
                if (!plugin.cfg().isAllowed(p)) {
                    p.sendMessage(Component.text("⚠ Песочница только для тестовых админов.", NamedTextColor.YELLOW));
                    return true;
                }
                plugin.manager().enter(p);
            }
            case "create" -> {
                World w = plugin.manager().testWorld();
                sender.sendMessage(w != null
                        ? Component.text("✅ Тестовый мир готов: " + w.getName()
                                + " (spawn " + w.getSpawnLocation().getBlockX() + ","
                                + w.getSpawnLocation().getBlockY() + ","
                                + w.getSpawnLocation().getBlockZ() + ")", NamedTextColor.GREEN)
                        : Component.text("⚠ Не удалось создать мир, смотри лог.", NamedTextColor.RED));
            }
            case "add" -> {
                if (!requireAdmin(sender)) return true;
                if (args.length < 2) {
                    sender.sendMessage(Component.text("Использование: tw add <ник>", NamedTextColor.GRAY));
                    return true;
                }
                var list = new java.util.ArrayList<>(plugin.cfg().allowedPlayers());
                String nick = args[1];
                if (list.stream().anyMatch(n -> n.equalsIgnoreCase(nick))) {
                    sender.sendMessage(Component.text("ℹ " + nick + " уже в списке.", NamedTextColor.GRAY));
                    return true;
                }
                list.add(nick);
                plugin.getConfig().set("allowed-players", list);
                plugin.saveConfig();
                plugin.reloadAll();
                sender.sendMessage(Component.text("✅ " + nick + " добавлен в тестовые админы.", NamedTextColor.GREEN));
            }
            case "remove" -> {
                if (!requireAdmin(sender)) return true;
                if (args.length < 2) {
                    sender.sendMessage(Component.text("Использование: tw remove <ник>", NamedTextColor.GRAY));
                    return true;
                }
                var list = new java.util.ArrayList<>(plugin.cfg().allowedPlayers());
                if (list.removeIf(n -> n.equalsIgnoreCase(args[1]))) {
                    plugin.getConfig().set("allowed-players", list);
                    plugin.saveConfig();
                    plugin.reloadAll();
                    sender.sendMessage(Component.text("✅ " + args[1] + " убран из списка.", NamedTextColor.GREEN));
                } else {
                    sender.sendMessage(Component.text("ℹ " + args[1] + " не найден в списке.", NamedTextColor.GRAY));
                }
            }
            case "reload" -> {
                if (!requireAdmin(sender)) return true;
                plugin.reloadAll();
                sender.sendMessage(Component.text("✅ Конфиг перечитан. Мир: "
                        + plugin.cfg().worldName() + ", в списке: "
                        + plugin.cfg().allowedPlayers().size(), NamedTextColor.GREEN));
            }
            case "info" -> {
                World w = Bukkit.getWorld(plugin.cfg().worldName());
                sender.sendMessage(Component.text("— TestWorld —", NamedTextColor.DARK_PURPLE));
                sender.sendMessage(Component.text("Мир: " + plugin.cfg().worldName()
                        + (w != null ? " (создан)" : " (будет создан при первом входе)"), NamedTextColor.GRAY));
                sender.sendMessage(Component.text("Список доступа: "
                        + String.join(", ", plugin.cfg().allowedPlayers()), NamedTextColor.GRAY));
                if (sender instanceof Player p) {
                    sender.sendMessage(Component.text("Вы: " + (plugin.manager().inTest(p) ? "в песочнице (OP)"
                            : "в основном мире" + (p.isOp() ? " (OP)" : "")), NamedTextColor.GRAY));
                }
            }
            default -> sender.sendMessage(Component.text(
                    "Использование: /tw [back|create|add|remove|reload|info]", NamedTextColor.GRAY));
        }
        return true;
    }

    private boolean requireAdmin(CommandSender sender) {
        if (sender instanceof Player p) {
            return p.hasPermission("testworld.admin");
        }
        return true; // console
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("back", "create", "add", "remove", "reload", "info").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("add") || args[0].equalsIgnoreCase("remove"))) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        return List.of();
    }
}
