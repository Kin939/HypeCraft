package com.hardcorerevival.data;

import com.hardcorerevival.HardcoreRevival;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.resources.Identifier;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * World-persisted state of the revival system.
 *
 * <p>Stored via the codec-based {@link SavedDataType} system, so the data
 * survives server restarts. All timestamps are epoch milliseconds (real time),
 * which is why timers keep ticking while a player is offline.
 */
public class RevivalSavedData extends SavedData {

    /** A dead player: when the spectator period ends and the name for chat UI. */
    public record DeathEntry(long deadline, String name) {
        public static final Codec<DeathEntry> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.LONG.fieldOf("deadline").forGetter(DeathEntry::deadline),
                Codec.STRING.optionalFieldOf("name", "?").forGetter(DeathEntry::name)
        ).apply(i, DeathEntry::new));
    }

    private final Map<UUID, DeathEntry> deaths = new HashMap<>();
    private final Map<UUID, Long> protections = new HashMap<>();
    private final Set<UUID> needsPlacement = new HashSet<>();
    private final Set<UUID> spectatorPlaced = new HashSet<>();

    private static final Codec<UUID> UUID_CODEC = Codec.STRING.xmap(UUID::fromString, UUID::toString);
    private static final Codec<Map<UUID, DeathEntry>> DEATHS_CODEC = Codec.unboundedMap(UUID_CODEC, DeathEntry.CODEC);
    private static final Codec<Map<UUID, Long>> TIME_MAP_CODEC = Codec.unboundedMap(UUID_CODEC, Codec.LONG);
    private static final Codec<List<UUID>> UUID_LIST_CODEC = UUID_CODEC.listOf();

    public static final Codec<RevivalSavedData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            DEATHS_CODEC.optionalFieldOf("deaths", Map.of()).forGetter(d -> Map.copyOf(d.deaths)),
            TIME_MAP_CODEC.optionalFieldOf("protections", Map.of()).forGetter(d -> Map.copyOf(d.protections)),
            UUID_LIST_CODEC.optionalFieldOf("needs_placement", List.of()).forGetter(d -> List.copyOf(d.needsPlacement)),
            UUID_LIST_CODEC.optionalFieldOf("spectator_placed", List.of()).forGetter(d -> List.copyOf(d.spectatorPlaced))
    ).apply(instance, RevivalSavedData::new));

    /**
     * The {@code dataFixTypes} argument is {@code null}: this data is brand new
     * and never existed in older versions, so no datafixer is required
     * (NeoForge itself ships a {@code SavedDataType} with a null fixer).
     */
    public static final SavedDataType<RevivalSavedData> TYPE = new SavedDataType<>(
            Identifier.fromNamespaceAndPath(HardcoreRevival.MODID, "revival"),
            RevivalSavedData::new,
            CODEC,
            (DataFixTypes) null);

    private RevivalSavedData(Map<UUID, DeathEntry> deaths, Map<UUID, Long> protections, List<UUID> placement, List<UUID> placed) {
        this.deaths.putAll(deaths);
        this.protections.putAll(protections);
        this.needsPlacement.addAll(placement);
        this.spectatorPlaced.addAll(placed);
    }

    public RevivalSavedData() {
    }

    /* ---------------- deaths ---------------- */

    public void setDeath(UUID id, long deadline, String name) {
        deaths.put(id, new DeathEntry(deadline, name));
        setDirty();
    }

    public void removeDeath(UUID id) {
        if (deaths.remove(id) != null) setDirty();
    }

    public boolean isDead(UUID id) {
        return deaths.containsKey(id);
    }

    public DeathEntry deathEntry(UUID id) {
        return deaths.get(id);
    }

    /** Snapshot copy, safe to iterate while mutating. */
    public Map<UUID, DeathEntry> deathsSnapshot() {
        return Map.copyOf(deaths);
    }

    /** Finds a dead player by (case-insensitive) name. */
    public UUID findDeadByName(String name) {
        for (Map.Entry<UUID, DeathEntry> e : deaths.entrySet()) {
            if (e.getValue().name().equalsIgnoreCase(name)) return e.getKey();
        }
        return null;
    }

    /* ---------------- protections ---------------- */

    public void setProtection(UUID id, long until) {
        protections.put(id, until);
        setDirty();
    }

    public void removeProtection(UUID id) {
        if (protections.remove(id) != null) setDirty();
    }

    public boolean isProtected(UUID id) {
        return protections.containsKey(id);
    }

    public long protectionUntil(UUID id) {
        return protections.getOrDefault(id, 0L);
    }

    public Map<UUID, Long> protectionsSnapshot() {
        return Map.copyOf(protections);
    }

    /* ---------------- pending placement (revived while offline) ---------------- */

    public void markPlacement(UUID id) {
        if (needsPlacement.add(id)) setDirty();
    }

    public void clearPlacement(UUID id) {
        if (needsPlacement.remove(id)) setDirty();
    }

    public boolean needsPlacement(UUID id) {
        return needsPlacement.contains(id);
    }

    /* ---------------- spectator placed flag ---------------- */

    /** Marks that the player has already been turned into an anchored spectator. */
    public void markSpectatorPlaced(UUID id) {
        if (spectatorPlaced.add(id)) setDirty();
    }

    public void clearSpectatorPlaced(UUID id) {
        if (spectatorPlaced.remove(id)) setDirty();
    }

    public boolean isSpectatorPlaced(UUID id) {
        return spectatorPlaced.contains(id);
    }

    /* ---------------- helpers ---------------- */

    public String deathName(UUID id) {
        DeathEntry e = deaths.get(id);
        return e != null ? e.name() : id.toString();
    }

}
