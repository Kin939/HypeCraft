package com.testworld.paper;

import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

/**
 * TestWorld — a private flat sandbox world for server admins.
 *
 * <p>{@code /tw} teleports the admin to a separate flat world where they are
 * automatically granted OP (and optionally a gamemode). Leaving the sandbox —
 * by command, quit, or even a server crash — always strips the OP again, so
 * they stay a regular player in the main world.
 */
public final class TestWorldPlugin extends JavaPlugin {

    private TwConfig cfg;
    private TwState state;
    private TwManager manager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        cfg = new TwConfig(this);
        state = new TwState(new File(getDataFolder(), "state.yml"));
        state.load();
        manager = new TwManager(this);

        var pm = getServer().getPluginManager();
        pm.registerEvents(new TwListener(this), this);

        var cmd = getCommand("testworld");
        TwCommands executor = new TwCommands(this);
        if (cmd != null) {
            cmd.setExecutor(executor);
            cmd.setTabCompleter(executor);
        }

        // Safety: if the server crashed while an admin was opped in the sandbox,
        // strip the OP now (they may have relogged into the main world).
        manager.stripStrayOps();

        getLogger().info("TestWorld готов: /tw — в песочницу, /tw back — обратно");
    }

    @Override
    public void onDisable() {
        // Never leave temporary OPs behind.
        for (var p : getServer().getOnlinePlayers()) {
            manager.restoreAll(p);
        }
        state.save();
    }

    public TwConfig cfg() {
        return cfg;
    }

    public TwState state() {
        return state;
    }

    public TwManager manager() {
        return manager;
    }

    public void reloadAll() {
        reloadConfig();
        cfg.refresh(this);
    }
}
