package com.testworld.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

/** OP/inventory safety on quit/join, sandbox respawn, portal isolation, foreign teleports. */
public class TwListener implements Listener {

    private final TestWorldPlugin plugin;

    public TwListener(TestWorldPlugin plugin) {
        this.plugin = plugin;
    }

    /* ---------------- quit: never keep temp OPs ---------------- */

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onQuit(PlayerQuitEvent event) {
        Player p = event.getPlayer();
        var r = plugin.state().get(p.getUniqueId());
        World test = Bukkit.getWorld(plugin.cfg().worldName());
        if (test != null && p.getWorld().equals(test)) {
            r.testLoc = new double[]{p.getLocation().getX(), p.getLocation().getY(),
                    p.getLocation().getZ(), p.getLocation().getYaw(), p.getLocation().getPitch()};
        }
        // OP persists in ops.txt across restarts — strip it right away.
        if (r.oppedByPlugin && p.isOp()) {
            p.setOp(false);
            r.oppedByPlugin = false;
        }
        plugin.state().save();
    }

    /* ---------------- join: restore context ---------------- */

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        var r = plugin.state().get(p.getUniqueId());
        World test = Bukkit.getWorld(plugin.cfg().worldName());

        // Crash safety net: opped by us but sitting in the main world → deop.
        if (r.oppedByPlugin && p.isOp() && (test == null || !p.getWorld().equals(test))) {
            p.setOp(false);
            r.oppedByPlugin = false;
            plugin.state().save();
            return;
        }

        // Crash mid-exit: flagged as "in test" but physically in the main world — finish the swap.
        if (r.inTest && (test == null || !p.getWorld().equals(test))) {
            plugin.manager().swapOutOfTest(p, r);
            plugin.state().save();
            return;
        }

        // Rejoined straight inside the sandbox.
        if (test != null && p.getWorld().equals(test)) {
            if (plugin.cfg().isAllowed(p)) {
                if (plugin.cfg().opInTest() && !p.isOp()) {
                    p.setOp(true);
                    r.oppedByPlugin = true;
                    plugin.state().save();
                }
            } else {
                // Not on the list — escort them out with their main inventory.
                if (r.mainInitialized) {
                    plugin.manager().swapOutOfTest(p, r);
                } else {
                    plugin.manager().restoreAll(p);
                    r.inTest = false;
                    plugin.state().save();
                }
                p.teleport(plugin.manager().safeSpawn(Bukkit.getWorlds().get(0)));
                p.sendMessage(Component.text("⚠ Песочница недоступна: тебя нет в списке тестовых админов.",
                        NamedTextColor.YELLOW));
            }
        }
    }

    /* ---------------- world change: keep sides consistent ---------------- */

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player p = event.getPlayer();
        var r = plugin.state().get(p.getUniqueId());
        World test = Bukkit.getWorld(plugin.cfg().worldName());
        boolean inside = test != null && p.getWorld().equals(test);

        if (inside && !r.inTest) {
            // A foreign plugin teleported them into the sandbox — isolate properly.
            World fromWorld = event.getFrom();
            plugin.manager().swapIntoTest(p, r,
                    fromWorld == null ? null : fromWorld.getSpawnLocation());
        } else if (!inside && r.inTest) {
            // A foreign plugin teleported them out — hand over main inventory, strip OP.
            plugin.manager().swapOutOfTest(p, r);
        }
    }

    /* ---------------- respawn: stay in the sandbox ---------------- */

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player p = event.getPlayer();
        var r = plugin.state().get(p.getUniqueId());
        if (!r.inTest) return;
        World test = Bukkit.getWorld(plugin.cfg().worldName());
        if (test != null) {
            event.setRespawnLocation(plugin.manager().safeSpawn(test));
        } else {
            event.setRespawnLocation(plugin.manager().safeSpawn(Bukkit.getWorlds().get(0)));
        }
    }

    /* ---------------- portals: keep the sandbox isolated ---------------- */

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPortal(PlayerTeleportEvent event) {
        var cause = event.getCause();
        if (cause != PlayerTeleportEvent.TeleportCause.NETHER_PORTAL
                && cause != PlayerTeleportEvent.TeleportCause.END_PORTAL) {
            return;
        }
        World test = Bukkit.getWorld(plugin.cfg().worldName());
        if (test == null) return;
        boolean fromTest = event.getFrom().getWorld() != null && event.getFrom().getWorld().equals(test);
        boolean toTest = event.getTo() != null && event.getTo().getWorld() != null
                && event.getTo().getWorld().equals(test);
        if (fromTest || toTest) {
            event.setCancelled(true);
            event.getPlayer().sendActionBar(Component.text(
                    "Порталы в песочнице отключены — используйте /tw", NamedTextColor.GRAY));
        }
    }
}
