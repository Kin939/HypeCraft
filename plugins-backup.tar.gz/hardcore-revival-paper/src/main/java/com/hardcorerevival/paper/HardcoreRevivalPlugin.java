package com.hardcorerevival.paper;

import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Hardcore Revival — Paper 26.3 plugin.
 *
 * <p>Death makes a player an anchored spectator for a configurable period
 * (default 3 real days; the timer runs while offline and survives restarts).
 * A living player can open the nether-star revival GUI and bring a dead player
 * back right next to them. A nether star kept in the inventory acts as a
 * passive totem: items are lost, but the player instantly respawns at their own
 * respawn point. Wither drops a nether star only with a configurable chance.
 */
public final class HardcoreRevivalPlugin extends JavaPlugin {

    private HrConfig cfg;
    private DeathStore store;

    /** Players whose death was just cancelled by the star (need gamemode restore). */
    private final Set<UUID> justSaved = ConcurrentHashMap.newKeySet();

    /** Currently open revival menus — refreshed after every revive. */
    private final Set<ReviveMenu> openMenus = ConcurrentHashMap.newKeySet();

    /** Players currently glowing because they carry a nether star. */
    private final Set<UUID> starGlow = ConcurrentHashMap.newKeySet();

    /** Призраки нашей системы (в спектаторе от плагина) — для авто-починки. */
    private final Set<UUID> ghostWatch = ConcurrentHashMap.newKeySet();

    // PDC-ключи трупов-зомби (статические — читаются из Corpse без инстанса).
    private static org.bukkit.NamespacedKey corpseKindKey;
    private static org.bukkit.NamespacedKey corpseOwnerKey;
    private static org.bukkit.NamespacedKey corpseNameKey;
    private static org.bukkit.NamespacedKey corpseLootKey;
    private static org.bukkit.NamespacedKey ghostVisualKey;

    public static org.bukkit.NamespacedKey corpseKindKey() { return corpseKindKey; }

    public static org.bukkit.NamespacedKey corpseOwnerKey() { return corpseOwnerKey; }

    public static org.bukkit.NamespacedKey corpseNameKey() { return corpseNameKey; }

    public static org.bukkit.NamespacedKey corpseLootKey() { return corpseLootKey; }

    public static org.bukkit.NamespacedKey keysGhostVisual() { return ghostVisualKey; }

    public Set<UUID> ghostWatch() {
        return ghostWatch;
    }

    @Override
    public void onEnable() {
        corpseKindKey = new org.bukkit.NamespacedKey(this, "corpse_kind");
        corpseOwnerKey = new org.bukkit.NamespacedKey(this, "corpse_owner");
        corpseNameKey = new org.bukkit.NamespacedKey(this, "corpse_name");
        corpseLootKey = new org.bukkit.NamespacedKey(this, "corpse_loot");
        ghostVisualKey = new org.bukkit.NamespacedKey(this, "ghost_visual");

        saveDefaultConfig();
        cfg = new HrConfig(this);
        store = new DeathStore(new File(getDataFolder(), "deaths.yml"));
        store.load();

        var pm = getServer().getPluginManager();
        pm.registerEvents(new DeathListener(this), this);
        pm.registerEvents(new MenuListener(this), this);
        pm.registerEvents(new StarListener(this), this);
        pm.registerEvents(new ProtectionListener(this), this);

        Corpse.scanLoaded();
        Ghost.cleanupOrphans(this);

        var reviveCmd = getCommand("revive");
        var adminCmd = getCommand("revivaladmin");
        HrCommands executor = new HrCommands(this);
        if (reviveCmd != null) reviveCmd.setExecutor(executor);
        if (adminCmd != null) adminCmd.setExecutor(executor);

        getServer().getScheduler().runTaskTimer(this, new TickTask(this), 10L, 10L);

        getLogger().info("Hardcore Revival включён — смерть только начало!");
    }

    @Override
    public void onDisable() {
        store.save();
        openMenus.clear();
    }

    public HrConfig cfg() {
        return cfg;
    }

    public DeathStore store() {
        return store;
    }

    public Set<UUID> justSaved() {
        return justSaved;
    }

    public Set<ReviveMenu> openMenus() {
        return openMenus;
    }

    public Set<UUID> starGlow() {
        return starGlow;
    }

    public void reloadAll() {
        reloadConfig();
        cfg.refresh(this);
    }
}
