package com.necromancer.paper;

import org.bukkit.entity.Bogged;
import org.bukkit.entity.Drowned;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Husk;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Parched;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Stray;
import org.bukkit.entity.Zombie;

import java.util.Locale;

/** Приручаемая нежить — ровно 7 типов, всё остальное запрещено. */
public enum NecroMob {
    ZOMBIE("Зомби", EntityType.ZOMBIE, Zombie.class, false, false, 20, NecroTextures.ZOMBIE),
    DROWNED("Утопленник", EntityType.DROWNED, Drowned.class, false, false, 20, NecroTextures.DROWNED),
    HUSK("Кадавр", EntityType.HUSK, Husk.class, false, true, 20, NecroTextures.HUSK),
    SKELETON("Скелет", EntityType.SKELETON, Skeleton.class, true, false, 20, NecroTextures.SKELETON),
    STRAY("Зимогор", EntityType.STRAY, Stray.class, true, false, 20, NecroTextures.STRAY),
    BOGGED("Болотник", EntityType.BOGGED, Bogged.class, true, false, 16, NecroTextures.BOGGED),
    PARCHED("Пустынник", EntityType.PARCHED, Parched.class, true, false, 20, NecroTextures.PARCHED);

    public final String ru;
    public final EntityType type;
    public final Class<? extends Mob> clazz;
    public final boolean archer;
    public final boolean axe;
    public final int baseHp;
    public final String texture; // base64-текстура головы с minecraft-heads

    NecroMob(String ru, EntityType type, Class<? extends Mob> clazz,
             boolean archer, boolean axe, int baseHp, String texture) {
        this.ru = ru;
        this.type = type;
        this.clazz = clazz;
        this.archer = archer;
        this.axe = axe;
        this.baseHp = baseHp;
        this.texture = texture;
    }

    public static NecroMob of(EntityType t) {
        for (NecroMob m : values()) {
            if (m.type == t) return m;
        }
        return null;
    }

    /** Разбор имени для /give: «зомби», «husk», «пустынник»… */
    public static NecroMob parse(String s) {
        String q = s.toLowerCase(Locale.ROOT).strip();
        for (NecroMob m : values()) {
            if (m.name().toLowerCase(Locale.ROOT).equals(q)) return m;
            if (m.ru.toLowerCase(Locale.ROOT).equals(q)) return m;
        }
        return null;
    }

    private static final String[] LEVELS = {"Дикий", "Медный", "Железный", "Алмазный", "Незеритовый"};

    public static String levelName(int lvl) {
        return LEVELS[Math.max(0, Math.min(4, lvl))];
    }
}
