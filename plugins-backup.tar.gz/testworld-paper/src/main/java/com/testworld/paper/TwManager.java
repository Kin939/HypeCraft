package com.testworld.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.time.Duration;

/**
 * World creation, enter/exit transitions and OP/gamemode/inventory restoration.
 *
 * <p>Inventories are fully isolated per side. Sides are captured and replayed
 * verbatim through semantic Bukkit APIs — never through raw {@code setContents}
 * with assumed sizes, so any server inventory layout works.
 */
public final class TwManager {

    private final TestWorldPlugin plugin;

    TwManager(TestWorldPlugin plugin) {
        this.plugin = plugin;
    }

    /* ---------------- world ---------------- */

    /** @return the sandbox world, creating it on first use (flat, bordered). */
    public World testWorld() {
        String name = plugin.cfg().worldName();
        World w = Bukkit.getWorld(name);
        if (w != null) return w;

        w = new WorldCreator(name)
                .type(WorldType.FLAT)
                .environment(World.Environment.NORMAL)
                .generateStructures(false)
                .createWorld();
        if (w == null) return null;

        for (var e : plugin.cfg().gamerules().entrySet()) {
            GameRule<Boolean> rule = GameRule.getByName(e.getKey());
            if (rule != null) {
                w.setGameRule(rule, e.getValue());
            }
        }

        int radius = plugin.cfg().borderRadius();
        if (radius > 0) {
            var border = w.getWorldBorder();
            border.setCenter(w.getSpawnLocation());
            border.setSize(radius * 2.0);
        }
        w.setTime(1000L);

        plugin.getLogger().info("Создан тестовый мир \"" + name + "\" (плоский, граница "
                + (radius > 0 ? radius + " блоков" : "нет") + ")");
        return w;
    }

    /* ---------------- enter / exit ---------------- */

    public void enter(Player p) {
        World w = testWorld();
        if (w == null) {
            p.sendMessage(Component.text("⚠ Не удалось создать тестовый мир, смотри лог сервера.",
                    NamedTextColor.RED));
            return;
        }
        var r = plugin.state().get(p.getUniqueId());

        // 1) Snapshot the main-world side before touching the player.
        r.mainWorld = p.getWorld().getName();
        r.mainLoc = locArr(p.getLocation());
        r.mainSide = captureSide(p);
        r.mainInitialized = true;

        // 2) Claim the flag first so our own world-change listener stays idle,
        //    then cross over and swap belongings.
        r.inTest = true;
        plugin.state().save();

        Location dest = r.testLoc != null ? toLoc(w, r.testLoc) : safeSpawn(w);
        snapSafe(dest);
        p.teleport(dest);
        applySide(p, r.testSide);

        // 3) OP and gamemode — inside the sandbox only.
        if (plugin.cfg().opInTest() && !p.isOp()) {
            p.setOp(true);
            r.oppedByPlugin = true;
        }
        GameMode target = plugin.cfg().sandboxGamemode();
        if (target != null && target != p.getGameMode()) {
            r.gmBefore = p.getGameMode();
            p.setGameMode(target);
        }
        plugin.state().save();

        p.showTitle(Title.title(
                Component.text("ПЕСОЧНИЦА").color(NamedTextColor.DARK_PURPLE).decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                Title.Times.times(Duration.ofMillis(150), Duration.ofSeconds(3), Duration.ofMillis(600))));
        p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.2f);
        p.playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.7f, 1.6f);
    }

    public void exit(Player p) {
        var r = plugin.state().get(p.getUniqueId());
        World test = Bukkit.getWorld(plugin.cfg().worldName());

        // 1) Snapshot the sandbox side while still inside it.
        if (test != null && p.getWorld().equals(test)) {
            r.testLoc = locArr(p.getLocation());
            r.testSide = captureSide(p);
        }

        // 2) Claim the flag first, then cross back and swap belongings.
        r.inTest = false;
        plugin.state().save();

        World destWorld = Bukkit.getWorld(r.mainWorld != null ? r.mainWorld : "world");
        if (destWorld == null) destWorld = Bukkit.getWorlds().get(0);
        Location dest = r.mainLoc != null ? toLoc(destWorld, r.mainLoc) : safeSpawn(destWorld);
        snapSafe(dest);
        p.teleport(dest);

        if (r.mainInitialized) {
            applySide(p, r.mainSide);
        }
        restoreAll(p);
        plugin.state().save();

        p.showTitle(Title.title(
                Component.text("ОСНОВНОЙ МИР").color(NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                Title.Times.times(Duration.ofMillis(150), Duration.ofSeconds(2), Duration.ofMillis(500))));
        p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.9f);
    }

    public boolean inTest(Player p) {
        World w = Bukkit.getWorld(plugin.cfg().worldName());
        return w != null && p.getWorld().equals(w);
    }

    /* ---------------- listener-facing swaps (already crossed over) ---------------- */

    /**
     * The player has just arrived in the sandbox world by a foreign teleport:
     * snapshot the main side they carried in, put on the sandbox side.
     *
     * @param from their position in the main world (may be null)
     */
    public void swapIntoTest(Player p, TwState.Rec r, Location from) {
        if (from != null && from.getWorld() != null) {
            r.mainWorld = from.getWorld().getName();
            r.mainLoc = locArr(from);
        }
        r.mainSide = captureSide(p);
        r.mainInitialized = true;
        r.inTest = true;
        plugin.state().save();

        applySide(p, r.testSide);

        if (plugin.cfg().opInTest() && !p.isOp()) {
            p.setOp(true);
            r.oppedByPlugin = true;
        }
        GameMode target = plugin.cfg().sandboxGamemode();
        if (target != null && target != p.getGameMode()) {
            r.gmBefore = p.getGameMode();
            p.setGameMode(target);
        }
        plugin.state().save();
    }

    /**
     * The player has just left the sandbox world by a foreign teleport (or a kick
     * from the list): hand the main side back and strip the OP.
     */
    public void swapOutOfTest(Player p, TwState.Rec r) {
        World test = Bukkit.getWorld(plugin.cfg().worldName());
        if (test != null && p.getWorld().equals(test)) {
            r.testLoc = locArr(p.getLocation());
            r.testSide = captureSide(p);
        }
        r.inTest = false;
        if (r.mainInitialized) {
            applySide(p, r.mainSide);
        }
        restoreAll(p);
        plugin.state().save();
    }

    /* ---------------- inventory side switching ---------------- */

    /** Snapshots the player's current side through semantic APIs (verbatim arrays). */
    public TwState.Side captureSide(Player p) {
        TwState.Side s = new TwState.Side();
        var pi = p.getInventory();
        s.storage = cloneItems(pi.getStorageContents());
        s.armor = cloneItems(pi.getArmorContents());
        ItemStack off = pi.getItemInOffHand();
        s.offhand = off == null ? null : off.clone();
        s.ender = cloneItems(p.getEnderChest().getContents());
        s.xp = captureXp(p);
        return s;
    }

    /**
     * Applies a stored side; an empty side yields a clean, empty inventory.
     * Each array is replayed only into the API that produced it, with a
     * slot-by-slot fallback if a length ever disagrees.
     */
    public void applySide(Player p, TwState.Side s) {
        var pi = p.getInventory();
        pi.clear();
        pi.setItemInOffHand(null);

        if (s != null && !s.isEmpty()) {
            if (s.storage != null) {
                try {
                    pi.setStorageContents(s.storage);
                } catch (IllegalArgumentException ex) {
                    plugin.getLogger().warning("setStorageContents(" + s.storage.length
                            + ") отклонён (" + ex.getMessage() + ") — заполняю по слотам");
                    pi.clear();
                    setBySlot(pi, s.storage);
                }
            }
            if (s.armor != null) {
                try {
                    pi.setArmorContents(s.armor);
                } catch (IllegalArgumentException ignored) {
                }
            }
            if (s.offhand != null) {
                pi.setItemInOffHand(s.offhand);
            }
            if (s.ender != null) {
                Inventory ec = p.getEnderChest();
                try {
                    ec.setContents(s.ender);
                } catch (IllegalArgumentException ex) {
                    ec.clear();
                    setBySlot(ec, s.ender);
                }
            }
            applyXp(p, s.xp);
        }
        p.updateInventory();
    }

    private static void setBySlot(Inventory inv, ItemStack[] items) {
        int n = Math.min(items.length, inv.getSize());
        for (int i = 0; i < n; i++) {
            inv.setItem(i, items[i]);
        }
    }

    private static ItemStack[] cloneItems(ItemStack[] src) {
        if (src == null) return null;
        ItemStack[] out = new ItemStack[src.length];
        for (int i = 0; i < src.length; i++) {
            out[i] = src[i] == null ? null : src[i].clone();
        }
        return out;
    }

    private static int[] captureXp(Player p) {
        return new int[]{p.getLevel(), Math.round(p.getExp() * 1000f), p.getTotalExperience()};
    }

    private static void applyXp(Player p, int[] xp) {
        if (xp != null && (xp[0] != 0 || xp[1] != 0 || xp[2] != 0)) {
            p.setLevel(xp[0]);
            p.setExp(Math.max(0f, Math.min(0.999f, xp[1] / 1000f)));
            p.setTotalExperience(xp[2]);
        } else {
            p.setLevel(0);
            p.setExp(0f);
            p.setTotalExperience(0);
        }
    }

    /* ---------------- restoration & safety ---------------- */

    /** Strips plugin-granted OP and restores the gamemode. */
    public void restoreAll(Player p) {
        var r = plugin.state().get(p.getUniqueId());
        if (r.oppedByPlugin && p.isOp()) {
            p.setOp(false);
        }
        r.oppedByPlugin = false;
        if (r.gmBefore != null && p.getGameMode() != r.gmBefore) {
            p.setGameMode(r.gmBefore);
        }
        r.gmBefore = null;
    }

    /** Startup/join safety: if a crash left a temp-OP on someone in the main world — remove it. */
    public void stripStrayOps() {
        World test = Bukkit.getWorld(plugin.cfg().worldName());
        for (Player p : Bukkit.getOnlinePlayers()) {
            var r = plugin.state().get(p.getUniqueId());
            boolean inside = test != null && p.getWorld().equals(test);
            if (r.oppedByPlugin && p.isOp() && !inside) {
                p.setOp(false);
                r.oppedByPlugin = false;
                plugin.getLogger().info("Снята забытая OP-плашка с " + p.getName()
                        + " (сервер был остановлен, пока тот был в песочнице)");
            }
        }
        plugin.state().save();
    }

    /* ---------------- locations ---------------- */

    public Location safeSpawn(World w) {
        Location s = w.getSpawnLocation();
        int y = w.getHighestBlockYAt(s.getBlockX(), s.getBlockZ()) + 1;
        return new Location(w, s.getBlockX() + 0.5, y, s.getBlockZ() + 0.5, s.getYaw(), s.getPitch());
    }

    /** If the destination is inside solid blocks — lift to the surface. */
    private void snapSafe(Location loc) {
        Block feet = loc.getBlock();
        Block head = loc.clone().add(0, 1, 0).getBlock();
        if (feet.getType().isSolid() || head.getType().isSolid()) {
            int y = loc.getWorld().getHighestBlockYAt(loc.getBlockX(), loc.getBlockZ()) + 1;
            loc.setY(y);
        }
    }

    private static Location toLoc(World w, double[] a) {
        if (w == null || a == null) return null;
        return new Location(w, a[0], a[1], a[2], (float) a[3], (float) a[4]);
    }

    private static double[] locArr(Location l) {
        return new double[]{l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch()};
    }
}
