package com.hardcorerevival.util;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/** Small helpers for pretty chat/actionbar output. */
public final class Msg {
    private Msg() {
    }

    /** Formats a duration as {@code 2д 03:04:05} or {@code 03:04:05}. */
    public static String formatDuration(long ms) {
        if (ms < 0) ms = 0;
        long totalSec = (ms + 999) / 1000;
        long days = totalSec / 86400;
        long hours = (totalSec % 86400) / 3600;
        long minutes = (totalSec % 3600) / 60;
        long seconds = totalSec % 60;
        if (days > 0) {
            return String.format("%dd %02d:%02d:%02d", days, hours, minutes, seconds);
        }
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    public static MutableComponent icon(String icon, ChatFormatting color, String text) {
        return Component.literal(icon + " ").withStyle(color).append(Component.literal(text));
    }
}
