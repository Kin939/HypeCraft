package com.hardcorerevival.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.time.Duration;

/** Particles, sounds, titles, action bars and time formatting. */
public final class Effects {

    private Effects() {
    }

    public static String formatDuration(long ms) {
        if (ms < 0) ms = 0;
        long totalSec = (ms + 999) / 1000;
        long days = totalSec / 86400;
        long hours = (totalSec % 86400) / 3600;
        long minutes = (totalSec % 3600) / 60;
        long seconds = totalSec % 60;
        if (days > 0) {
            return String.format("%dd %02d:%02d:%02d", days, hours, minutes, seconds);
        }
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    public static Component c(String text, NamedTextColor color) {
        return Component.text(text, color);
    }

    public static Component itemName(String text, NamedTextColor color) {
        return Component.text(text).color(color).decoration(TextDecoration.ITALIC, false);
    }

    public static Component lore(String text, NamedTextColor color) {
        return Component.text(text).color(color).decoration(TextDecoration.ITALIC, false);
    }

    /** White sparks burst + the ghastling "purreow". */
    public static void reviveBurst(Location loc) {
        World w = loc.getWorld();
        double x = loc.getX(), y = loc.getY() + 1.0, z = loc.getZ();
        w.spawnParticle(Particle.END_ROD, x, y, z, 70, 0.7, 0.9, 0.7, 0.12);
        w.spawnParticle(Particle.FIREWORK, x, y, z, 25, 0.5, 0.8, 0.5, 0.18);
        w.spawnParticle(Particle.SWEEP_ATTACK, x, y, z, 3, 0.3, 0.3, 0.3, 0.0);
        for (Player p : w.getNearbyPlayers(loc, 15)) {
            p.playSound(loc, Sound.ENTITY_GHASTLING_AMBIENT, org.bukkit.SoundCategory.PLAYERS, 1.6f, 0.9f);
            p.playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, org.bukkit.SoundCategory.PLAYERS, 0.8f, 1.4f);
        }
    }

    public static void spectateDoom(Location loc) {
        // Только близко стоящие — больше не гремит на весь сервер.
        for (Player p : loc.getWorld().getNearbyPlayers(loc, 15)) {
            p.playSound(loc, Sound.ENTITY_WITHER_SPAWN, org.bukkit.SoundCategory.PLAYERS, 0.5f, 1.6f);
        }
    }

    public static void title(Player p, String title, NamedTextColor titleColor, String subtitle, NamedTextColor subColor) {
        p.showTitle(Title.title(
                Component.text(title).color(titleColor).decoration(TextDecoration.ITALIC, false),
                Component.text(subtitle).color(subColor).decoration(TextDecoration.ITALIC, false),
                Title.Times.times(Duration.ofMillis(150), Duration.ofSeconds(3), Duration.ofMillis(600))));
    }

    public static void actionbar(Player p, String text, NamedTextColor color) {
        p.sendActionBar(Component.text(text).color(color).decoration(TextDecoration.ITALIC, false));
    }

    public static void broadcast(HardcoreRevivalPlugin plugin, Component msg) {
        if (plugin.cfg().broadcast()) {
            plugin.getServer().broadcast(msg);
        }
    }

    /** Makes any dropped nether star items near the location glow. */
    public static void glowNearbyStars(Location loc) {
        loc.getWorld().getNearbyEntities(loc, 2.5, 2.5, 2.5).forEach(e -> {
            if (e instanceof org.bukkit.entity.Item item
                    && item.getItemStack().getType() == org.bukkit.Material.NETHER_STAR) {
                item.setGlowing(true);
            }
        });
    }
}
