package com.customcrafts.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/** /customcrafts (cc) — выдача предметов для проверки. */
public final class CraftsCommand implements CommandExecutor, TabCompleter {

    private final CraftsPlugin plugin;

    public CraftsCommand(CraftsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length < 2) {
            usage(sender);
            return true;
        }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null) {
            sender.sendMessage(Component.text("⚠ Игрок \"" + args[1] + "\" не в сети.", NamedTextColor.YELLOW));
            return true;
        }
        ItemStack it = switch (args[0].toLowerCase(Locale.ROOT)) {
            case "debugstick", "stick" -> CraftsItems.debugStick();
            case "light", "свет" -> CraftsItems.invisLight();
            case "frame", "рамка" -> CraftsItems.invisFrame();
            default -> null;
        };
        if (it == null) {
            usage(sender);
            return true;
        }
        t.getInventory().addItem(it);
        sender.sendMessage(Component.text("✅ Выдано: " + t.getName(), NamedTextColor.GREEN));
        return true;
    }

    private void usage(CommandSender s) {
        s.sendMessage(Component.text("Использование:", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/customcrafts give <ник> <debugstick|light|frame>", NamedTextColor.GRAY));
        s.sendMessage(Component.text("Рецепты уже зарегистрированы — крафтите в верстаке.", NamedTextColor.GRAY));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            return Stream.of("give").filter(x -> x.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 2) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        if (args.length == 3) {
            return Stream.of("debugstick", "light", "frame")
                    .filter(x -> x.startsWith(args[2].toLowerCase(Locale.ROOT))).toList();
        }
        return List.of();
    }
}
