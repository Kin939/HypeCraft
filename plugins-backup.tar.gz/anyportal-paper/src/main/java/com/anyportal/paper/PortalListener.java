package com.anyportal.paper;

import org.bukkit.Axis;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Orientable;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Particle;

import java.util.List;

/**
 * Зажигание портала любой формы + защита кастомных порталов от
 * ванильной «хрупкости» (физика, ломание, взрывы, поршни).
 * Никаких сообщений игроку — ванильное поведение.
 */
public final class PortalListener implements Listener {

    private final AnyPortalPlugin plugin;
    private final PortalRegistry registry;

    PortalListener(AnyPortalPlugin plugin, PortalRegistry registry) {
        this.plugin = plugin;
        this.registry = registry;
    }

    /* ---------------- зажигание ---------------- */

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onIgnite(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getHand() != EquipmentSlot.HAND) return;
        ItemStack item = e.getItem();
        if (item == null || item.getType() != Material.FLINT_AND_STEEL) return;
        Block clicked = e.getClickedBlock();
        if (clicked == null || clicked.getType() != Material.OBSIDIAN) return;

        // Порталы в Энде запрещены (баланс): отменяем событие молча — ваниль
        // тоже не зажжёт свой прямоугольный. Никаких сообщений.
        if (plugin.banEnd() && clicked.getWorld().getEnvironment() == World.Environment.THE_END) {
            e.setCancelled(true);
            return;
        }

        Block seed = clicked.getRelative(e.getBlockFace());
        if (seed.getType() == Material.NETHER_PORTAL) return; // уже портал

        World w = clicked.getWorld();
        int cap = plugin.maxInteriorBlocks();

        // Пробуем обе вертикальные плоскости: вдоль X и вдоль Z.
        PortalShape.Pocket p = PortalShape.scan(w, seed.getX(), seed.getY(), seed.getZ(), true, cap);
        Axis axis = Axis.X;
        if (p == null) {
            p = PortalShape.scan(w, seed.getX(), seed.getY(), seed.getZ(), false, cap);
            axis = Axis.Z;
        }
        if (p == null) return; // не замкнуто — ваниль разберётся сама

        String id = registry.create(w, p.cells());
        if (id == null) return; // пересекается с существующим порталом

        // Заполняем нутр порталальными блоками (без физики — ваниль их не сломает,
        // форму мы держим сами).
        for (Long cell : p.cells()) {
            org.bukkit.block.Block b = w.getBlockAt(PortalRegistry.unpackX(cell),
                    PortalRegistry.unpackY(cell), PortalRegistry.unpackZ(cell));
            Orientable data = (Orientable) Material.NETHER_PORTAL.createBlockData();
            data.setAxis(axis);
            b.setBlockData(data, false);
        }

        if (plugin.particles()) {
            for (Long cell : p.cells()) {
                w.spawnParticle(Particle.PORTAL,
                        PortalRegistry.unpackX(cell) + 0.5,
                        PortalRegistry.unpackY(cell) + 0.5,
                        PortalRegistry.unpackZ(cell) + 0.5, 6, 0.2, 0.3, 0.2, 0.4);
            }
        }
        w.playSound(seed.getLocation(), Sound.BLOCK_PORTAL_TRIGGER, 0.4f, 1.0f);

        plugin.getLogger().info("Портал [" + id + "] создан в " + w.getName()
                + ": " + p.size() + " блоков (seed " + seed.getX() + " " + seed.getY() + " " + seed.getZ() + ").");

        e.setCancelled(true); // чтобы ваниль не пыталась ставить огонь поверх нутра
    }

    /* ---------------- защита от ванильной хрупкости ---------------- */

    @EventHandler(ignoreCancelled = true)
    public void onPhysics(BlockPhysicsEvent e) {
        if (e.getBlock().getType() != Material.NETHER_PORTAL) return;
        if (registry.locate(e.getBlock().getWorld().getName(),
                e.getBlock().getX(), e.getBlock().getY(), e.getBlock().getZ()) != null) {
            e.setCancelled(true); // форма нестандартная — ванильная проверка каркаса не нужна
        }
    }

    /* ---------------- ломание: рамка или нутр = весь портал ---------------- */

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        org.bukkit.block.Block b = e.getBlock();
        World w = b.getWorld();
        PortalRegistry.Portal hit = null;

        if (b.getType() == Material.NETHER_PORTAL) {
            hit = registry.locate(w.getName(), b.getX(), b.getY(), b.getZ());
        } else if (b.getType() == Material.OBSIDIAN) {
            for (BlockFace f : new BlockFace[]{BlockFace.UP, BlockFace.DOWN,
                    BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
                org.bukkit.block.Block n = b.getRelative(f);
                if (n.getType() == Material.NETHER_PORTAL) {
                    hit = registry.locate(w.getName(), n.getX(), n.getY(), n.getZ());
                    if (hit != null) break;
                }
            }
        }
        if (hit == null) return;

        e.setCancelled(true); // обсидиан рамки остаётся, исчезает только портал
        extinguish(hit, e.getPlayer());
    }

    private void extinguish(PortalRegistry.Portal portal, Player by) {
        if (registry.remove(portal.id) == null) return;
        World w = plugin.getServer().getWorld(portal.world);
        if (w == null) return;
        int n = 0;
        for (Long cell : portal.blocks) {
            org.bukkit.block.Block b = w.getBlockAt(PortalRegistry.unpackX(cell),
                    PortalRegistry.unpackY(cell), PortalRegistry.unpackZ(cell));
            if (b.getType() == Material.NETHER_PORTAL) {
                b.setType(Material.AIR, false);
                n++;
                if (plugin.particles() && (n <= 24 || n % 8 == 0)) {
                    w.spawnParticle(Particle.SMOKE,
                            b.getX() + 0.5, b.getY() + 0.5, b.getZ() + 0.5, 3, 0.15, 0.2, 0.15, 0.01);
                }
            }
        }
        w.playSound(w.getBlockAt(0, 80, 0).getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 0.6f, 0.7f);
        plugin.getLogger().info("Портал [" + portal.id + "] погашен"
                + (by != null ? " игроком " + by.getName() : "") + " (" + n + " блоков).");
    }

    /* ---------------- взрывы ---------------- */

    @EventHandler(ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        if (plugin.protectExplosions()) e.blockList().removeIf(this::isProtected);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        if (plugin.protectExplosions()) e.blockList().removeIf(this::isProtected);
    }

    private boolean isProtected(org.bukkit.block.Block b) {
        if (b.getType() == Material.NETHER_PORTAL) {
            return registry.locate(b.getWorld().getName(), b.getX(), b.getY(), b.getZ()) != null;
        }
        if (b.getType() == Material.OBSIDIAN) {
            for (BlockFace f : new BlockFace[]{BlockFace.UP, BlockFace.DOWN,
                    BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
                org.bukkit.block.Block n = b.getRelative(f);
                if (n.getType() == Material.NETHER_PORTAL
                        && registry.locate(n.getWorld().getName(), n.getX(), n.getY(), n.getZ()) != null) {
                    return true;
                }
            }
        }
        return false;
    }

    /* ---------------- поршни ---------------- */

    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        if (touchesPortal(e.getBlocks())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        if (touchesPortal(e.getBlocks())) e.setCancelled(true);
    }

    private boolean touchesPortal(List<org.bukkit.block.Block> blocks) {
        for (org.bukkit.block.Block b : blocks) {
            if (b.getType() == Material.NETHER_PORTAL
                    && registry.locate(b.getWorld().getName(), b.getX(), b.getY(), b.getZ()) != null) {
                return true;
            }
        }
        return false;
    }
}
