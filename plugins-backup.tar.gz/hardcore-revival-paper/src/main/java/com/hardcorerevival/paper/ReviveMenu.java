package com.hardcorerevival.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The nether-star revival GUI: a chest with a decorative glass "mosaic" in the
 * top and bottom rows and dead players' heads in the middle row, laid out
 * symmetrically from the center (longest dead in the exact center slot).
 * Empty state — an oxeye daisy named "Некого возрождать".
 */
public final class ReviveMenu implements InventoryHolder {

    public static final int SIZE = 27;
    public static final int CENTER = 13;
    /** Center-out slot order in the middle row (9..17). */
    private static final int[] HEAD_SLOTS = {13, 12, 14, 11, 15, 10, 16, 9, 17};
    public static final int MAX_HEADS = HEAD_SLOTS.length;

    private static final Material[] MOSAIC = {
            Material.BLACK_STAINED_GLASS_PANE,
            Material.GRAY_STAINED_GLASS_PANE,
            Material.PURPLE_STAINED_GLASS_PANE,
            Material.LIGHT_GRAY_STAINED_GLASS_PANE
    };

    private static final Set<ReviveMenu> REGISTRY = ConcurrentHashMap.newKeySet();

    private final HardcoreRevivalPlugin plugin;
    private final Inventory inventory;

    public ReviveMenu(HardcoreRevivalPlugin plugin) {
        this.plugin = plugin;
        this.inventory = Bukkit.createInventory(this, SIZE,
                Component.text("⸸ Звезда Визера: Возрождение ⸸", NamedTextColor.DARK_PURPLE)
                        .decoration(TextDecoration.ITALIC, false));
        refresh();
        REGISTRY.add(this);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    /** Opens (or re-renders) the menu for a viewer. */
    public void open(Player viewer) {
        refresh();
        viewer.openInventory(inventory);
    }

    /** Releases the menu from the refresh registry (when its last viewer closes it). */
    public void release() {
        REGISTRY.remove(this);
    }

    /** Re-fills the inventory in place — all current viewers see the update. */
    public synchronized void refresh() {
        inventory.clear();

        // Decorative mosaic: top and bottom rows.
        for (int i = 0; i < 9; i++) {
            inventory.setItem(i, pane(i));
            inventory.setItem(18 + i, pane(i + 2));
        }

        List<Map.Entry<UUID, Long>> dead = plugin.store().deadSorted();
        if (dead.isEmpty()) {
            inventory.setItem(CENTER, daisy());
            return;
        }

        int n = Math.min(dead.size(), MAX_HEADS);
        for (int i = 0; i < n; i++) {
            var e = dead.get(i);
            long left = e.getValue() - System.currentTimeMillis();
            inventory.setItem(HEAD_SLOTS[i], head(e.getKey(), left, online(e.getKey())));
        }
    }

    private static boolean online(UUID id) {
        return Bukkit.getPlayer(id) != null;
    }

    private ItemStack pane(int colorIndex) {
        ItemStack item = new ItemStack(MOSAIC[colorIndex % MOSAIC.length]);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(" "));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack daisy() {
        ItemStack item = new ItemStack(Material.OXEYE_DAISY);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Effects.itemName("Некого возрождать", NamedTextColor.WHITE));
        meta.lore(List.of(Effects.lore("✨ Все игроки живы", NamedTextColor.GRAY)));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack head(UUID target, long left, boolean online) {
        OfflinePlayer off = Bukkit.getOfflinePlayer(target);
        String name = off != null && off.getName() != null ? off.getName() : plugin.store().deathName(target);

        ItemStack item = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) item.getItemMeta();
        meta.setOwningPlayer(off);
        meta.displayName(Effects.itemName(name, NamedTextColor.AQUA));
        List<Component> lore = new ArrayList<>();
        lore.add(Effects.lore("☠ Мёртв ещё: " + Effects.formatDuration(left), NamedTextColor.RED));
        if (!online) {
            lore.add(Effects.lore("оффлайн", NamedTextColor.DARK_GRAY));
        }
        lore.add(Effects.lore("ЛКМ — возродить рядом с вами", NamedTextColor.YELLOW));
        lore.add(Effects.lore("✨ Звезда Визера будет потрачена", NamedTextColor.GRAY));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(targetKey(), PersistentDataType.STRING, target.toString());
        item.setItemMeta(meta);
        return item;
    }

    public NamespacedKey targetKey() {
        return new NamespacedKey(plugin, "revive_target");
    }

    /** @return target UUID stored on the item, or null. */
    public static UUID targetOf(HardcoreRevivalPlugin plugin, ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        String s = item.getItemMeta().getPersistentDataContainer()
                .get(new NamespacedKey(plugin, "revive_target"), PersistentDataType.STRING);
        if (s == null) return null;
        try {
            return UUID.fromString(s);
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    /** Re-renders every open menu (after a revive, for example). */
    public static void refreshAll() {
        for (ReviveMenu menu : REGISTRY) {
            menu.refresh();
        }
    }

    /** Drops menus that nobody is viewing anymore. */
    public static void cleanup() {
        REGISTRY.removeIf(m -> m.inventory.getViewers().isEmpty());
    }
}
