package com.customcrafts.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/** Предметы и рецепты плагина. */
public final class CraftsItems {

    public static NamespacedKey KIND;
    public static NamespacedKey RECIPE_LIGHT;
    public static NamespacedKey RECIPE_DEBUG;
    public static NamespacedKey RECIPE_FRAME;

    private CraftsItems() {}

    static void init(CraftsPlugin plugin) {
        KIND = new NamespacedKey(plugin, "kind");
        RECIPE_LIGHT = new NamespacedKey(plugin, "invis_light");
        RECIPE_DEBUG = new NamespacedKey(plugin, "debug_stick");
        RECIPE_FRAME = new NamespacedKey(plugin, "invis_frame");
    }

    /* ---------------- маркеры ---------------- */

    public static String kindOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(KIND, PersistentDataType.STRING);
    }

    private static void mark(ItemStack it, String kind) {
        ItemMeta meta = it.getItemMeta();
        meta.getPersistentDataContainer().set(KIND, PersistentDataType.STRING, kind);
        it.setItemMeta(meta);
    }

    /* ---------------- предметы ---------------- */

    public static ItemStack debugStick() {
        ItemStack it = new ItemStack(Material.DEBUG_STICK);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text("🪄 Палочка отладки", NamedTextColor.LIGHT_PURPLE));
        meta.lore(List.of(
                Component.text("Декоративная настройка блоков:", NamedTextColor.GRAY),
                Component.text("ПКМ по блоку — изменить значение", NamedTextColor.WHITE),
                Component.text("Shift+ПКМ — следующее свойство", NamedTextColor.WHITE),
                Component.text("Shift+ЛКМ — предыдущее свойство", NamedTextColor.WHITE),
                Component.text("Только безопасные свойства (поворот,", NamedTextColor.DARK_GRAY),
                Component.text("половина, форма, подвес, открытость…)", NamedTextColor.DARK_GRAY)));
        it.setItemMeta(meta);
        mark(it, "debug_stick");
        return it;
    }

    public static ItemStack invisLight() {
        ItemStack it = new ItemStack(Material.LIGHT);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text("☀ Невидимый свет", NamedTextColor.YELLOW));
        meta.lore(List.of(
                Component.text("Ставит невидимый источник света 15", NamedTextColor.GRAY),
                Component.text("Убрать: ударить рукой/предметом", NamedTextColor.DARK_GRAY)));
        it.setItemMeta(meta);
        mark(it, "invis_light");
        return it;
    }

    public static ItemStack invisFrame() {
        ItemStack it = new ItemStack(Material.ITEM_FRAME);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text("🖼 Невидимая рамка", NamedTextColor.AQUA));
        meta.lore(List.of(
                Component.text("Висит на стене незаметно:", NamedTextColor.GRAY),
                Component.text("виден только вложенный предмет", NamedTextColor.GRAY)));
        it.setItemMeta(meta);
        mark(it, "invis_frame");
        return it;
    }

    /* ---------------- рецепты ---------------- */

    static void register(CraftsPlugin plugin) {
        // ☀ Невидимый свет (4 шт):
        //      [редстоун-факел]
        // [факел]  [скалк]  [медный факел]
        //      [соул-факел]
        ItemStack lightResult = invisLight();
        lightResult.setAmount(4);
        ShapedRecipe light = new ShapedRecipe(RECIPE_LIGHT, lightResult);
        light.shape(" R ", "TSC", " U ");
        light.setIngredient('R', Material.REDSTONE_TORCH);
        light.setIngredient('T', Material.TORCH);
        light.setIngredient('S', Material.SCULK);
        light.setIngredient('C', Material.COPPER_TORCH);
        light.setIngredient('U', Material.SOUL_TORCH);
        Bukkit.addRecipe(light);

        // 🪄 Палочка отладки:
        // [осколок эха] [глаз]  [глаз]
        // [глаз]  [стержень бриза] [глаз]
        // [глаз]  [глаз]  [осколок эха]
        ShapedRecipe debug = new ShapedRecipe(RECIPE_DEBUG, debugStick());
        debug.shape("XEE", "EBE", "EEX");
        debug.setIngredient('X', Material.ECHO_SHARD);
        debug.setIngredient('E', Material.ENDER_EYE);
        debug.setIngredient('B', Material.BREEZE_ROD);
        Bukkit.addRecipe(debug);

        // 🖼 Невидимая рамка: [рамка][скалк] в ряд
        ShapedRecipe frame = new ShapedRecipe(RECIPE_FRAME, invisFrame());
        frame.shape("FS");
        frame.setIngredient('F', Material.ITEM_FRAME);
        frame.setIngredient('S', Material.SCULK);
        Bukkit.addRecipe(frame);
    }
}
