package com.hardcorerevival.paper;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

import java.util.UUID;

/** GUI protection: only a LEFT click on a player's head does something. */
public class MenuListener implements Listener {

    private final HardcoreRevivalPlugin plugin;

    public MenuListener(HardcoreRevivalPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean isOurMenu(Inventory top) {
        return top != null && top.getHolder() instanceof ReviveMenu;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (!isOurMenu(event.getView().getTopInventory())) return;

        // Lock everything: panes, heads, shift-clicks, number keys, drags, offhand.
        event.setCancelled(true);

        if (event.getClickedInventory() != event.getView().getTopInventory()) return;
        if (event.getClick() != ClickType.LEFT) return;
        if (!(event.getWhoClicked() instanceof Player viewer)) return;

        UUID target = ReviveMenu.targetOf(plugin, event.getCurrentItem());
        if (target == null) return;

        // Do the heavy work after the event fully resolves (anti-dupe).
        Bukkit.getScheduler().runTask(plugin, () -> {
            // Re-validate: menu may have refreshed, states may have changed.
            if (!viewer.isOnline()) return;
            RevivalLogic.handleHeadClick(plugin, viewer, target);
        });
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        if (isOurMenu(event.getView().getTopInventory())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onClose(org.bukkit.event.inventory.InventoryCloseEvent event) {
        if (event.getInventory().getHolder() instanceof ReviveMenu menu
                && event.getInventory().getViewers().size() <= 1) {
            plugin.getServer().getScheduler().runTask(plugin, ReviveMenu::cleanup);
            menu.release();
        }
    }
}
