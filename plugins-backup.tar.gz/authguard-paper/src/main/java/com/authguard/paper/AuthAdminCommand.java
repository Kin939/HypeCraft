package com.authguard.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;

/** /authadmin — ручной список мёртвых и просмотр аккаунтов. */
public final class AuthAdminCommand implements CommandExecutor, TabCompleter {

    private final AuthGuardPlugin plugin;

    public AuthAdminCommand(AuthGuardPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 0) {
            usage(sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "dead" -> dead(sender, args);
            case "bypass" -> bypass(sender, args);
            case "info" -> info(sender, args);
            case "unregister" -> unregister(sender, args);
            case "reload" -> {
                plugin.deadRegistry().reload();
                plugin.store().load();
                sender.sendMessage(Component.text("✅ Данные и список мёртвых перечитаны.", NamedTextColor.GREEN));
            }
            default -> usage(sender);
        }
        return true;
    }

    private void usage(CommandSender s) {
        s.sendMessage(Component.text("Использование:", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/authadmin dead add <ник> — добавить мёртвого (мультиаккаунты блокируются)", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/authadmin dead remove <ник> — убрать из списка", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/authadmin dead list — показать мёртвых", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/authadmin bypass add <ник> — разрешить игроку заходить с любых IP (обход IP-проверки)", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/authadmin bypass remove <ник> — вернуть проверку", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/authadmin bypass list — белый список", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/authadmin info <ник> — данные аккаунта", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/authadmin unregister <ник> — удалить аккаунт (перерегистрация)", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/authadmin reload — перечитать данные", NamedTextColor.GRAY));
    }

    private void dead(CommandSender s, String[] args) {
        if (args.length < 2) {
            usage(s);
            return;
        }
        String sub = args[1].toLowerCase(Locale.ROOT);
        if (sub.equals("list")) {
            var all = plugin.deadRegistry().all();
            s.sendMessage(Component.text("— Мёртвые (" + all.size() + ") —", NamedTextColor.DARK_RED));
            for (String n : all.stream().sorted().toList()) {
                String src = plugin.deadRegistry().manual().containsKey(n) ? "вручную" : "Hardcore Revival";
                s.sendMessage(Component.text("  " + n + " (" + src + ")", NamedTextColor.GRAY));
            }
            return;
        }
        if (args.length < 3) {
            s.sendMessage(Component.text("Использование: /authadmin dead <add|remove|list> [ник]",
                    NamedTextColor.YELLOW));
            return;
        }
        String name = args[2].toLowerCase(Locale.ROOT);
        if (sub.equals("add")) {
            plugin.deadRegistry().manual().put(name, 0L);
            plugin.store().save();
            s.sendMessage(Component.text("☠ \"" + name + "\" добавлен в мёртвые: новые аккаунты с его IP не пройдут.",
                    NamedTextColor.GREEN));
        } else if (sub.equals("remove")) {
            if (plugin.deadRegistry().manual().remove(name) == null) {
                s.sendMessage(Component.text("ℹ \"" + name + "\" не в ручном списке (смерти HR убираются сами при возрождении).",
                        NamedTextColor.GRAY));
                return;
            }
            plugin.store().save();
            s.sendMessage(Component.text("✅ \"" + name + "\" убран из ручного списка.", NamedTextColor.GREEN));
        }
    }

    private void bypass(CommandSender s, String[] args) {
        if (args.length < 2) {
            usage(s);
            return;
        }
        String sub = args[1].toLowerCase(Locale.ROOT);
        if (sub.equals("list")) {
            var all = plugin.store().ipBypass();
            s.sendMessage(Component.text("— IP-белый список (" + all.size() + ") —", NamedTextColor.GOLD));
            for (String n : all.stream().sorted().toList()) {
                s.sendMessage(Component.text("  " + n, NamedTextColor.GRAY));
            }
            if (all.isEmpty()) {
                s.sendMessage(Component.text("  (пусто — IP-проверка действует на всех)", NamedTextColor.DARK_GRAY));
            }
            return;
        }
        if (args.length < 3) {
            s.sendMessage(Component.text("Использование: /authadmin bypass <add|remove|list> [ник]",
                    NamedTextColor.YELLOW));
            return;
        }
        String name = args[2].toLowerCase(Locale.ROOT);
        if (sub.equals("add")) {
            if (plugin.store().addIpBypass(name)) {
                s.sendMessage(Component.text("✅ \"" + name + "\" в белом списке: может заходить с любых IP"
                        + " и с других аккаунтов — без кика и без повторного пароля.", NamedTextColor.GREEN));
            } else {
                s.sendMessage(Component.text("ℹ \"" + name + "\" уже в белом списке.", NamedTextColor.GRAY));
            }
        } else if (sub.equals("remove")) {
            if (plugin.store().removeIpBypass(name)) {
                s.sendMessage(Component.text("✅ \"" + name + "\" убран из белого списка — IP-проверка снова действует.",
                        NamedTextColor.GREEN));
            } else {
                s.sendMessage(Component.text("ℹ \"" + name + "\" не в белом списке.", NamedTextColor.GRAY));
            }
        }
    }

    private void info(CommandSender s, String[] args) {
        if (args.length < 2) {
            s.sendMessage(Component.text("Использование: /authadmin info <ник>", NamedTextColor.YELLOW));
            return;
        }
        String key = args[1].toLowerCase(Locale.ROOT);
        AuthGuardPlugin.Account a = plugin.accounts().get(key);
        if (a == null) {
            s.sendMessage(Component.text("ℹ Аккаунт \"" + args[1] + "\" не найден.", NamedTextColor.GRAY));
            return;
        }
        s.sendMessage(Component.text("— " + a.name + " —", NamedTextColor.AQUA));
        s.sendMessage(Component.text("IP последнего входа: " + (a.lastIp == null ? "—" : a.lastIp), NamedTextColor.GRAY));
        s.sendMessage(Component.text("Последний вход: " + new java.util.Date(a.lastLogin), NamedTextColor.GRAY));
        s.sendMessage(Component.text("Мёртв: " + (plugin.deadRegistry().isDead(key) ? "да ☠" : "нет"), NamedTextColor.GRAY));
        s.sendMessage(Component.text("Последняя позиция: " + (a.lastWorld == null ? "—" : a.lastWorld + " " + a.lastX + " " + a.lastY + " " + a.lastZ), NamedTextColor.GRAY));
    }

    private void unregister(CommandSender s, String[] args) {
        if (args.length < 2) {
            s.sendMessage(Component.text("Использование: /authadmin unregister <ник>", NamedTextColor.YELLOW));
            return;
        }
        String key = args[1].toLowerCase(Locale.ROOT);
        if (plugin.accounts().remove(key) == null) {
            s.sendMessage(Component.text("ℹ Аккаунт \"" + args[1] + "\" не найден.", NamedTextColor.GRAY));
            return;
        }
        plugin.store().save();
        s.sendMessage(Component.text("✅ Аккаунт \"" + args[1] + "\" удалён. Игрок сможет зарегистрироваться заново.",
                NamedTextColor.GREEN));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            return Stream.of("dead", "bypass", "info", "unregister", "reload")
                    .filter(x -> x.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("dead") || args[0].equalsIgnoreCase("bypass"))) {
            return Stream.of("add", "remove", "list")
                    .filter(x -> x.startsWith(args[1].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 2) {
            return plugin.accounts().keySet().stream()
                    .filter(n -> n.startsWith(args[1].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 3 && (args[0].equalsIgnoreCase("dead") || args[0].equalsIgnoreCase("bypass"))) {
            return Bukkit.getOnlinePlayers().stream().map(p -> p.getName())
                    .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[2].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        return List.of();
    }
}
