package com.hardcorerevival.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Призрак-наблюдатель: игрок в НАСТОЯЩЕМ ванильном спектаторе, а для живых его
 * «призрак» — манекен: парящая голова со скином (лицом к зрителю) + белый ник
 * над ней, плавно следующие за спектатором. При вселении призрака в игрока/моба
 * манекен убирается целиком, чтобы не висеть перед камерой; вышел — вернулся.
 */
public final class Ghost {

    /** owner uuid -> визуальные сущности (голова + ник). */
    private static final Map<UUID, List<Entity>> VISUALS = new ConcurrentHashMap<>();
    /** owner uuid -> задача синхронизации манекена. */
    private static final Map<UUID, BukkitTask> SYNC = new ConcurrentHashMap<>();

    private Ghost() {}

    public static boolean isGhost(HardcoreRevivalPlugin plugin, Player p) {
        return plugin.store().isDead(p.getUniqueId());
    }

    /* ---------------- режим ---------------- */

    /** Ванильный спектатор: невидим, не мешает сну, нативный клик-телепорт. */
    public static void applyMode(HardcoreRevivalPlugin plugin, Player p) {
        p.setGameMode(GameMode.SPECTATOR);
    }

    /* ---------------- визуал: голова + ник ---------------- */

    public static void spawnVisuals(HardcoreRevivalPlugin plugin, Player p) {
        spawnVisuals(plugin, p, true);
    }

    private static void spawnVisuals(HardcoreRevivalPlugin plugin, Player p, boolean fx) {
        UUID id = p.getUniqueId();
        if (VISUALS.containsKey(id)) return;
        Location loc = p.getLocation().add(0, 1.75, 0);
        List<Entity> list = new CopyOnWriteArrayList<>();

        // Парящая голова со скином игрока. Модель развёрнута на 180°: billboard
        // поворачивает сущность к зрителю тыльной стороной модели (+Z), а лицо
        // головы находится на противоположной стороне — переворот открывает лицо.
        ItemStack headItem = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) headItem.getItemMeta();
        try {
            meta.setPlayerProfile(p.getPlayerProfile());
        } catch (Throwable ignored) {
        }
        headItem.setItemMeta(meta);

        ItemDisplay head = p.getWorld().spawn(loc, ItemDisplay.class, d -> {
            d.setItemStack(headItem);
            d.setBillboard(Display.Billboard.FIXED); // ориентацию задаём сами — по взгляду призрака
            d.setBrightness(new Display.Brightness(15, 15));
            d.setTeleportDuration(2); // плавное следование за призраком
            d.setTransformation(new org.bukkit.util.Transformation(
                    new Vector3f(0f, 0.05f, 0f),
                    new Quaternionf().rotationY((float) Math.PI),
                    new Vector3f(1.1f, 1.1f, 1.1f), new Quaternionf()));
            d.getPersistentDataContainer().set(plugin.keysGhostVisual(), PersistentDataType.STRING, id.toString());
            d.setPersistent(false);
        });

        // Ник над головой — виден сквозь стены, как и положено призраку.
        TextDisplay name = p.getWorld().spawn(loc.add(0, 0.45, 0), TextDisplay.class, d -> {
            d.text(Component.text(p.getName(), NamedTextColor.WHITE, TextDecoration.BOLD));
            d.setBillboard(Display.Billboard.CENTER);
            d.setBrightness(new Display.Brightness(15, 15));
            d.setSeeThrough(true);
            d.setTeleportDuration(2);
            d.setBackgroundColor(org.bukkit.Color.fromARGB(0x60, 0x10, 0x10, 0x20));
            d.getPersistentDataContainer().set(plugin.keysGhostVisual(), PersistentDataType.STRING, id.toString());
            d.setPersistent(false);
        });

        list.add(head);
        list.add(name);
        VISUALS.put(id, list);
        // Сам призрак свою голову и ник не видит (в первом лице мешают).
        p.hideEntity(plugin, head);
        p.hideEntity(plugin, name);
        startSync(plugin, p);

        if (fx) {
            p.getWorld().spawnParticle(org.bukkit.Particle.WHITE_SMOKE, loc, 12, 0.3, 0.4, 0.3, 0.01);
        }
    }

    /** Манекен следует за призраком; при вселении — исчезает, при выходе — возвращается. */
    private static void startSync(HardcoreRevivalPlugin plugin, Player p) {
        UUID id = p.getUniqueId();
        if (SYNC.containsKey(id)) return;
        SYNC.put(id, Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || !plugin.store().isDead(id)) {
                removeVisuals(plugin, p);
                return;
            }
            // Вселение (в игрока или моба): камера там же, где манекен — убираем целиком.
            if (p.getSpectatorTarget() != null) {
                List<Entity> list = VISUALS.remove(id);
                if (list != null) {
                    for (Entity e : list) e.remove();
                }
                return;
            }
            // Свободный полёт — манекен должен существовать и следовать за призраком.
            if (!VISUALS.containsKey(id)) {
                spawnVisuals(plugin, p, false);
                return;
            }
            List<Entity> list = VISUALS.get(id);
            if (list.size() < 2 || !list.get(0).isValid() || !list.get(1).isValid()) {
                removeVisuals(plugin, p);
                spawnVisuals(plugin, p, false);
                return;
            }
            Location base = p.getLocation().add(0, 1.75, 0);
            list.get(0).teleport(base);
            list.get(1).teleport(base.clone().add(0, 0.45, 0));

            // Голова повторяет взгляд призрака: видно, куда он смотрит.
            if (list.get(0) instanceof ItemDisplay hd) {
                Location eye = p.getLocation();
                Quaternionf look = new Quaternionf().rotationYXZ(
                        (float) Math.toRadians(eye.getYaw()),
                        (float) Math.toRadians(-eye.getPitch()), 0f);
                hd.setInterpolationDuration(1);
                hd.setInterpolationDelay(0);
                hd.setTransformation(new org.bukkit.util.Transformation(
                        new Vector3f(0f, 0.05f, 0f), look,
                        new Vector3f(1.1f, 1.1f, 1.1f), new Quaternionf()));
            }
        }, 1L, 1L));
    }

    /** Убрать визуал призрака полностью (возрождение / выход / очистка). */
    public static void removeVisuals(HardcoreRevivalPlugin plugin, Player p) {
        UUID id = p.getUniqueId();
        BukkitTask task = SYNC.remove(id);
        if (task != null) task.cancel();
        List<Entity> list = VISUALS.remove(id);
        if (list != null) {
            for (Entity e : list) e.remove();
        }
        // Хвосты старых версий: дисплеи-пассажиры игрока.
        for (Entity e : p.getPassengers()) {
            String kind = e.getPersistentDataContainer().get(plugin.keysGhostVisual(), PersistentDataType.STRING);
            if (id.toString().equals(kind)) e.remove();
        }
    }

    /** Сироты после рестартов: все ghost-дисплеи во всех мирах. */
    public static void cleanupOrphans(HardcoreRevivalPlugin plugin) {
        for (org.bukkit.World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (e.getPersistentDataContainer().has(plugin.keysGhostVisual(), PersistentDataType.STRING)) {
                    e.remove();
                }
            }
        }
    }
}
