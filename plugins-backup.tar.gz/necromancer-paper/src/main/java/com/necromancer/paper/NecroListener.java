package com.necromancer.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.Tag;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.EntityTransformEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.CraftingInventory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Все игровые события некроманта: приручение, меню, нейтралитет нежити, гибель легиона. */
public final class NecroListener implements Listener {

    private final NecromancerPlugin plugin;
    private final Map<UUID, Long> msgCd = new HashMap<>();

    public NecroListener(NecromancerPlugin plugin) {
        this.plugin = plugin;
    }

    /* ---------- использование предметов ---------- */

    @EventHandler
    public void onInteractEntity(org.bukkit.event.player.PlayerInteractEntityEvent e) {
        ItemStack it = p_handItem(e);
        if (!NecroItems.isNecro(it)) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        if (!allowed(p, it)) {
            spam(p, "⚠ Предметы некроманта не подчиняются чужакам.");
            return;
        }
        String kind = NecroItems.kindOf(it);
        if (NecroItems.KIND_HEAD.equals(kind)) {
            if (e.getHand() == EquipmentSlot.HAND) NecroMenu.open(plugin, p);
            return;
        }
        if (!NecroItems.KIND_FLOWER.equals(kind)) return;
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (!(e.getRightClicked() instanceof LivingEntity le)) return;

        NecroMob mob = NecroMob.of(le.getType());
        if (mob == null) {
            spam(p, "✖ Эта тварь неподвластна некроманту (только указанная нежить).");
            return;
        }
        ItemStack hand = p.getInventory().getItem(EquipmentSlot.HAND);
        if (hand == null || !NecroItems.KIND_FLOWER.equals(NecroItems.kindOf(hand))) return;

        // Тратим один мак
        if (hand.getAmount() > 1) hand.setAmount(hand.getAmount() - 1);
        else p.getInventory().setItemInMainHand(null);

        ItemStack head = NecroItems.mobHead(p.getUniqueId(), mob, 0);
        p.getInventory().addItem(head).values()
                .forEach(s -> p.getWorld().dropItemNaturally(p.getLocation(), s));

        le.getWorld().spawnParticle(Particle.SCULK_SOUL,
                le.getLocation().add(0, 1, 0), 14, 0.3, 0.5, 0.3, 0.03);
        Minions.playNear(le.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 0.7f, 0.6f, 15);
        p.sendMessage(Component.text("☠ " + mob.ru + " приручён! Голова в инвентаре — ПКМ открывает легион.",
                NamedTextColor.DARK_PURPLE));
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        ItemStack it = e.getItem();
        if (!NecroItems.isNecro(it)) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        if (!allowed(p, it)) {
            spam(p, "⚠ Предметы некроманта не подчиняются чужакам.");
            return;
        }
        if (NecroItems.KIND_HEAD.equals(NecroItems.kindOf(it))) NecroMenu.open(plugin, p);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (NecroItems.isNecro(e.getItemInHand())) {
            e.setCancelled(true);
            spam(e.getPlayer(), "⚠ Предметы некроманта нельзя ставить.");
        }
    }

    /** Предмет в руке, которой вызван интеракт (в 26.3 у события нет getItem). */
    private ItemStack p_handItem(org.bukkit.event.player.PlayerInteractEntityEvent e) {
        return e.getPlayer().getInventory().getItem(e.getHand());
    }

    private boolean allowed(Player p, ItemStack it) {
        return plugin.isNecromancer(p) && p.getUniqueId().equals(NecroItems.ownerOf(it));
    }

    private void spam(Player p, String s) {
        long now = System.currentTimeMillis();
        if (now - msgCd.getOrDefault(p.getUniqueId(), 0L) < 1500) return;
        msgCd.put(p.getUniqueId(), now);
        p.sendMessage(Component.text(s, NamedTextColor.YELLOW));
    }

    /* ---------- крафт мака — только некромант ---------- */

    @EventHandler
    public void onCraft(org.bukkit.event.inventory.PrepareItemCraftEvent e) {
        CraftingInventory inv = e.getInventory();
        ItemStack result = inv.getResult();
        if (result == null || !NecroItems.KIND_FLOWER.equals(NecroItems.kindOf(result))) return;
        if (!(e.getView().getPlayer() instanceof Player p) || !plugin.isNecromancer(p)) {
            inv.setResult(null);
        }
    }

    /* ---------- нейтралитет нежити и дисциплина легиона ---------- */

    @EventHandler(ignoreCancelled = true)
    public void onTarget(EntityTargetLivingEntityEvent e) {
        LivingEntity tgt = e.getTarget();
        if (tgt == null) return;
        Pet pet = plugin.pets().get(e.getEntity().getUniqueId());
        if (pet != null) {
            // Миньон атакует только заказанную цель и никогда — хозяина.
            boolean ok = pet.isHunting() && tgt.getUniqueId().equals(pet.target);
            if (!ok) e.setCancelled(true);
            return;
        }
        if (plugin.isNecromancer(tgt.getUniqueId()) && Tag.ENTITY_TYPES_UNDEAD.isTagged(e.getEntityType())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onTransform(EntityTransformEvent e) {
        // Зомби не превращается в утопленника в воде, кадавр — в зомби и т.д.
        if (plugin.pets().containsKey(e.getEntity().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent e) {
        if (plugin.pets().remove(e.getEntity().getUniqueId()) == null) return;
        // Гир миньона не попадает в мир.
        e.getDrops().clear();
        e.setDroppedExp(0);
        e.getEntity().getWorld().spawnParticle(Particle.LARGE_SMOKE,
                e.getEntity().getLocation().add(0, 1, 0), 15, 0.35, 0.6, 0.35, 0.02);
        Minions.playNear(e.getEntity().getLocation(), Sound.ENTITY_WITHER_HURT, 0.35f, 1.5f, 16);
    }

    /* ---------- смерть некроманта ---------- */

    @EventHandler
    public void onNecroDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        if (!plugin.isNecromancer(victim)) return;
        Bukkit.broadcast(Component.text("☠ Некромант " + victim.getName()
                + " повержен! Его легион обращается в прах…", NamedTextColor.DARK_PURPLE));
        Minions.killAll(plugin, victim.getUniqueId(), true);
        List<ItemStack> stash = new ArrayList<>();
        e.getDrops().removeIf(it -> {
            if (NecroItems.isNecro(it)) {
                stash.add(it);
                return true;
            }
            return false;
        });
        if (!stash.isEmpty()) plugin.deathStash().put(victim.getUniqueId(), stash);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player player = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            List<ItemStack> stash = plugin.deathStash().remove(player.getUniqueId());
            if (stash == null || stash.isEmpty()) return;
            var left = player.getInventory().addItem(stash.toArray(new ItemStack[0]));
            if (!left.isEmpty()) {
                // Не влезло — вернём при следующем респавне, чужакам не достанется.
                plugin.deathStash().put(player.getUniqueId(), new ArrayList<>(left.values()));
            }
        });
    }

    /* ---------- миньоны после рестарта ---------- */

    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) {
            if (plugin.pets().containsKey(en.getUniqueId())) continue;
            Pet pet = Minions.readPdc(en);
            if (pet != null) plugin.pets().put(en.getUniqueId(), pet);
        }
    }

    /* ---------- меню легиона ---------- */

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof NecroMenu menu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null) return;
        if (!(e.getClickedInventory().getHolder() instanceof NecroMenu)) return;
        menu.click(e.getSlot(), p);
    }

    @EventHandler
    public void onMenuDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof NecroMenu) e.setCancelled(true);
    }
}
