package com.authguard.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EquipmentSlot;

import java.util.Locale;

/** Все события авторизации: мир-пустота, заморозка, запрет мультиаккаунтов. */
public final class AuthListener implements Listener {

    private final AuthGuardPlugin plugin;

    public AuthListener(AuthGuardPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean unauthed(Player p) {
        return !plugin.isAuthed(p);
    }

    /* ---------------- до входа: детект мультиаккаунтов ---------------- */

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        String name = e.getName().toLowerCase(Locale.ROOT);
        String ip = e.getAddress() == null ? null : e.getAddress().getHostAddress();

        // Белый список: IP-проверка (кик за IP мёртвого) для этих ников отключена.
        if (plugin.store().isIpBypassed(name)) return;

        // Зарегистрированный аккаунт — пускаем, разберёмся на PlayerJoinEvent.
        if (plugin.accounts().containsKey(name)) return;

        // Новый ник с IP мёртвого аккаунта — отказ + тревога админам (без бана, по решению).
        plugin.deadRegistry().reload();
        for (String dead : plugin.deadRegistry().all()) {
            AuthGuardPlugin.Account acc = plugin.accounts().get(dead);
            if (acc != null && acc.lastIp != null && ip != null && acc.lastIp.equals(ip)) {
                e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, Component.text(
                        "☠ Твой IP уже использован мёртвым в хардкоре аккаунтом \"" + acc.name
                                + "\". Мультиаккаунты запрещены.", NamedTextColor.DARK_RED));
                String deadName = acc.name;
                Bukkit.getScheduler().runTask(plugin, () -> {
                    String msg = "🚨 Мультиаккаунт: \"" + e.getName() + "\" с IP " + ip
                            + " (IP мёртвого \"" + deadName + "\") — вход отклонён.";
                    plugin.getLogger().warning(msg);
                    for (Player op : Bukkit.getOnlinePlayers()) {
                        if (op.hasPermission("authguard.admin")) {
                            op.sendMessage(Component.text(msg, NamedTextColor.DARK_RED));
                        }
                    }
                });
                return;
            }
        }
    }

    /* ---------------- вход: маршрут в мир авторизации ---------------- */

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        String key = p.getName().toLowerCase(Locale.ROOT);
        String ip = p.getAddress() == null ? null : p.getAddress().getAddress().getHostAddress();

        // Зарегистрирован и сессия жива (тот же IP, <3 дней) — сразу в игру.
        if (plugin.sessionValid(key, ip)) {
            // Застрял в мире авторизации (падение сервера и т.п.) — вытаскиваем,
            // попутно возвращаем спрятанные вещи.
            if (p.getWorld() == plugin.authWorld() || plugin.stash().has(p.getUniqueId())) {
                plugin.finishLogin(p, true);
                return;
            }
            // Пароль не нужен — авторизуем НА МЕСТЕ: ваниль уже вернула игрока туда,
            // где он вышел, телепорт на спавн не нужен.
            plugin.markAuthed(key);
            plugin.arrivalSmoke(p.getLocation());
            p.showTitle(net.kyori.adventure.title.Title.title(
                    Component.text("Не умри.", NamedTextColor.GOLD),
                    Component.empty(),
                    net.kyori.adventure.title.Title.Times.times(
                            java.time.Duration.ofMillis(200), java.time.Duration.ofSeconds(3),
                            java.time.Duration.ofMillis(500))));
            return;
        }

        // Запоминаем, откуда возвращать (если сейчас не в мире авторизации).
        // У ещё не зарегистрированных — во временное хранилище, перенесём в аккаунт при /register.
        AuthGuardPlugin.Account a = plugin.accounts().get(key);
        if (p.getWorld() != plugin.authWorld()) {
            AuthGuardPlugin.Account rec = (a != null) ? a
                    : plugin.pendingLast().computeIfAbsent(key, k -> new AuthGuardPlugin.Account());
            rec.lastWorld = p.getWorld().getName();
            rec.lastX = p.getLocation().getX();
            rec.lastY = p.getLocation().getY();
            rec.lastZ = p.getLocation().getZ();
            rec.lastYaw = p.getLocation().getYaw();
            rec.lastPitch = p.getLocation().getPitch();
            if (a != null) plugin.store().save();
        }

        plugin.markUnauthed(key);
        plugin.sendToAuth(p);
        plugin.showAuthTitle(p);
        plugin.startTimeout(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        String key = p.getName().toLowerCase(Locale.ROOT);
        plugin.cancelTimeout(key);
        if (plugin.isAuthed(p)) {
            AuthGuardPlugin.Account a = plugin.accounts().get(key);
            if (a != null && p.getWorld() != plugin.authWorld()) {
                a.lastWorld = p.getWorld().getName();
                a.lastX = p.getLocation().getX();
                a.lastY = p.getLocation().getY();
                a.lastZ = p.getLocation().getZ();
                a.lastYaw = p.getLocation().getYaw();
                a.lastPitch = p.getLocation().getPitch();
                a.lastLogin = System.currentTimeMillis(); // продлеваем сессию
                plugin.store().save();
            }
            plugin.markUnauthed(key);
        } else {
            // Не зарегистрирован и ушёл — обновляем его «последнее место».
            AuthGuardPlugin.Account pend = plugin.pendingLast().get(key);
            if (pend != null && p.getWorld() != plugin.authWorld()) {
                pend.lastWorld = p.getWorld().getName();
                pend.lastX = p.getLocation().getX();
                pend.lastY = p.getLocation().getY();
                pend.lastZ = p.getLocation().getZ();
                pend.lastYaw = p.getLocation().getYaw();
                pend.lastPitch = p.getLocation().getPitch();
            }
        }
    }

    /* ---------------- заморозка в мире авторизации ---------------- */

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!unauthed(e.getPlayer())) return;
        // Страховка: не даём улететь в бездну — возвращаем на платформу входа.
        if (e.getPlayer().getWorld() == plugin.authWorld()
                && e.getTo() != null && e.getTo().getY() < 40) {
            plugin.sendToAuth(e.getPlayer());
            return;
        }
        // Полный фриз: ни шагу, ни поворота головы.
        e.setTo(e.getFrom());
    }

    @EventHandler(ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        if (!unauthed(e.getPlayer())) return;
        if (plugin.internalTeleport) return;
        e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && unauthed(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onHunger(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && unauthed(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (unauthed(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (unauthed(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (unauthed(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (unauthed(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && unauthed(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInvClick(InventoryClickEvent e) {
        if (e.getWhoClicked() instanceof Player p && unauthed(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInvOpen(InventoryOpenEvent e) {
        if (e.getPlayer() instanceof Player p && unauthed(p)) e.setCancelled(true);
    }

    /* ---------------- чат и команды ---------------- */

    @EventHandler(ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        if (!unauthed(e.getPlayer())) return;
        e.setCancelled(true);
        boolean isNew = !plugin.accounts().containsKey(e.getPlayer().getName().toLowerCase(Locale.ROOT));
        e.getPlayer().sendMessage(Component.text(isNew
                ? "⚠ Сначала зарегистрируйся: /register <пароль> <пароль>"
                : "⚠ Сначала войди: /login <пароль>", NamedTextColor.YELLOW));
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!unauthed(e.getPlayer())) return;
        String root = e.getMessage().split(" ")[0].toLowerCase(Locale.ROOT).substring(1);
        // Плагин-префиксы вида plugin:login тоже принимаем.
        if (root.contains(":")) {
            root = root.substring(root.indexOf(':') + 1);
        }
        if (root.equals("login") || root.equals("l") || root.equals("register") || root.equals("reg")) {
            return;
        }
        e.setCancelled(true);
        e.getPlayer().sendMessage(Component.text("⚠ Пока не авторизуешься — только /login и /register.",
                NamedTextColor.YELLOW));
    }
}
