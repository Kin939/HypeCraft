package com.dragonloader.paper;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;

/**
 * Контуры зоны прогрузки: колонна «на всю высоту мира» из искр END_ROD —
 * прямоугольник снизу, прямоугольник сверху и четыре вертикальных ребра.
 */
final class CLEffects {

    private CLEffects() {}

    static void tick(DragonLoaderPlugin plugin) {
        double step = Math.max(0.5, plugin.getConfig().getDouble("effect.step", 1.0));
        int yMin = plugin.getConfig().getInt("effect.min-y", -64);
        int yMax = plugin.getConfig().getInt("effect.max-y", 319);
        int r = plugin.radius();

        for (var pos : plugin.loaders()) {
            World w = Bukkit.getWorld(pos.world());
            if (w == null) continue;
            boolean eggPresent = w.isChunkLoaded(pos.x() >> 4, pos.z() >> 4)
                    && w.getBlockAt(pos.x(), pos.y(), pos.z()).getType() == Material.DRAGON_EGG;
            if (eggPresent) {
                // Чанк дозагрузился и яйцо честно прочитано — лоадер верифицирован.
                plugin.verified().add(pos);
                plugin.missing().remove(pos);
                drawColumn(w, pos, r, yMin, yMax, step);
                continue;
            }
            if (!plugin.verified().contains(pos)) {
                // Чанк ещё в промежуточной загрузке — блок читать рано, снимем позже.
                continue;
            }
            // Верифицированный лоадер потерял яйцо: 2 тика подряд — снять.
            int misses = plugin.missing().merge(pos, 1, Integer::sum);
            if (misses >= 2) {
                plugin.unregister(pos);
                plugin.getLogger().info("Яйцо-прогрузчик исчез: " + pos + " — зона снята.");
            }
        }
    }

    private static void drawColumn(World w, DragonLoaderPlugin.Pos pos, int r, int yMin, int yMax, double step) {
        double minX = (pos.x() - (pos.x() & 15)) - r * 16 + 0.5;
        double maxX = (pos.x() - (pos.x() & 15)) + 16 + (r - 1) * 16 + 15.5;
        double minZ = (pos.z() - (pos.z() & 15)) - r * 16 + 0.5;
        double maxZ = (pos.z() - (pos.z() & 15)) + 16 + (r - 1) * 16 + 15.5;

        // Нижний и верхний прямоугольники.
        rect(w, minX, maxX, minZ, maxZ, yMin, step);
        rect(w, minX, maxX, minZ, maxZ, yMax, step);
        // Четыре вертикальных ребра.
        for (double y = yMin; y <= yMax; y += step) {
            particle(w, minX, y, minZ);
            particle(w, maxX, y, minZ);
            particle(w, minX, y, maxZ);
            particle(w, maxX, y, maxZ);
        }
    }

    private static void rect(World w, double minX, double maxX, double minZ, double maxZ, double y, double step) {
        for (double x = minX; x <= maxX; x += step) {
            particle(w, x, y, minZ);
            particle(w, x, y, maxZ);
        }
        for (double z = minZ; z <= maxZ; z += step) {
            particle(w, minX, y, z);
            particle(w, maxX, y, z);
        }
    }

    private static void particle(World w, double x, double y, double z) {
        w.spawnParticle(Particle.END_ROD, x, y, z, 1, 0, 0, 0, 0);
    }
}
