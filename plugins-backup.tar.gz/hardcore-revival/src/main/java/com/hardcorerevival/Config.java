package com.hardcorerevival;

import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.DoubleValue DEATH_DURATION_HOURS = BUILDER
            .comment("How long (real hours) a dead player stays a spectator before auto-revive",
                     "Runs while the player is offline and survives server restarts")
            .defineInRange("deathDurationHours", 72.0, 0.01, 8760.0);

    public static final ForgeConfigSpec.DoubleValue PROTECTION_DURATION_MINUTES = BUILDER
            .comment("How long (real minutes) of PvP protection a revived player gets")
            .defineInRange("protectionDurationMinutes", 60.0, 0.0, 14400.0);

    public static final ForgeConfigSpec.IntValue SPECTATOR_RADIUS = BUILDER
            .comment("Spectators are teleported back if they fly further than this many blocks from world spawn",
                     "Keeps them from loading chunks around the map / scouting bases")
            .defineInRange("spectatorRadiusBlocks", 100, 16, 100000);

    public static final ForgeConfigSpec.BooleanValue CONSUME_STAR = BUILDER
            .comment("Whether reviving a player with a Nether Star consumes it")
            .define("consumeNetherStar", true);

    public static final ForgeConfigSpec.BooleanValue BROADCAST = BUILDER
            .comment("Broadcast death/revive events to the whole server chat")
            .define("broadcastMessages", true);

    static final ForgeConfigSpec SPEC = BUILDER.build();
}
