package com.dragonloader.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/** /chunkloader — выдача яйца, список прогрузчиков, ручная привязка. */
public final class CLCommand implements CommandExecutor, TabCompleter {

    private final DragonLoaderPlugin plugin;

    public CLCommand(DragonLoaderPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 0) {
            usage(sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "give", "egg" -> give(sender, args);
            case "list" -> list(sender);
            case "add" -> add(sender, args);
            case "unforceall" -> {
                int removed = plugin.unforceOrphans(null);
                sender.sendMessage(Component.text("✅ Снято сирот-прогрузок: " + removed
                        + " (force-чанки, не покрытые яйцами).", NamedTextColor.GREEN));
            }
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage(Component.text("✅ Конфиг перечитан. Изменения зон применятся при следующем размещении яиц.",
                        NamedTextColor.GREEN));
            }
            default -> usage(sender);
        }
        return true;
    }

    private void usage(CommandSender s) {
        s.sendMessage(Component.text("Использование:", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/chunkloader give [ник] — выдать яйцо-прогрузчик", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/chunkloader list — список активных прогрузчиков", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/chunkloader add <x> <y> <z> [мир] — привязать стоящее яйцо", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/chunkloader unforceall — снять сирот-прогрузки (force без яиц)", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/chunkloader reload — перечитать конфиг", NamedTextColor.GRAY));
    }

    private void give(CommandSender s, String[] args) {
        Player t;
        if (args.length >= 2) {
            t = Bukkit.getPlayerExact(args[1]);
            if (t == null) {
                s.sendMessage(Component.text("⚠ Игрок \"" + args[1] + "\" не в сети.", NamedTextColor.YELLOW));
                return;
            }
        } else if (s instanceof Player p) {
            t = p;
        } else {
            s.sendMessage(Component.text("⚠ С консоли: /chunkloader give <ник>", NamedTextColor.YELLOW));
            return;
        }
        t.getInventory().addItem(new ItemStack(Material.DRAGON_EGG));
        t.sendMessage(Component.text("🐉 Яйцо дракона у тебя — поставь его, и 3×3 чанков будут жить без игроков.",
                NamedTextColor.LIGHT_PURPLE));
        s.sendMessage(Component.text("✅ Яйцо выдано: " + t.getName(), NamedTextColor.GREEN));
    }

    private void list(CommandSender s) {
        var loaders = plugin.loaders();
        if (loaders.isEmpty()) {
            s.sendMessage(Component.text("ℹ Прогрузчиков нет. Поставь яйцо дракона — оно всё загрузит.",
                    NamedTextColor.GRAY));
            return;
        }
        s.sendMessage(Component.text("— Прогрузчики (" + loaders.size() + ") —", NamedTextColor.LIGHT_PURPLE));
        for (var p : loaders) {
            s.sendMessage(Component.text("  " + DragonLoaderPlugin.prettyWorld(p.world())
                            + ": " + p.x() + " " + p.y() + " " + p.z(),
                    NamedTextColor.GRAY));
        }
    }

    private void add(CommandSender s, String[] args) {
        if (args.length < 4) {
            s.sendMessage(Component.text("⚠ Использование: /chunkloader add <x> <y> <z> [мир]", NamedTextColor.YELLOW));
            return;
        }
        String worldName = args.length >= 5 ? args[4] : (s instanceof Player p ? p.getWorld().getName() : "world");
        World w = Bukkit.getWorld(worldName);
        if (w == null) {
            s.sendMessage(Component.text("⚠ Мир \"" + worldName + "\" не найден.", NamedTextColor.YELLOW));
            return;
        }
        int x, y, z;
        try {
            x = Integer.parseInt(args[1]);
            y = Integer.parseInt(args[2]);
            z = Integer.parseInt(args[3]);
        } catch (NumberFormatException ex) {
            s.sendMessage(Component.text("⚠ Координаты — целые числа.", NamedTextColor.YELLOW));
            return;
        }
        Block b = w.getBlockAt(x, y, z);
        if (b.getType() != Material.DRAGON_EGG) {
            s.sendMessage(Component.text("⚠ Здесь нет яйца дракона (" + x + " " + y + " " + z + ").",
                    NamedTextColor.YELLOW));
            return;
        }
        if (plugin.register(b)) {
            s.sendMessage(Component.text("✅ Прогрузчик привязан: 3×3 чанков вокруг (" + x + " " + y + " " + z + ").",
                    NamedTextColor.GREEN));
        } else {
            s.sendMessage(Component.text("ℹ Это яйцо уже является прогрузчиком.", NamedTextColor.GRAY));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            return Stream.of("give", "list", "add", "unforceall", "reload")
                    .filter(x -> x.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        return List.of();
    }
}
