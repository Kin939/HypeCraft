package com.necromancer.paper;

import org.bukkit.Location;

import java.util.UUID;

/** Состояние призванного миньона. */
public final class Pet {

    public final UUID owner;
    public final NecroMob mob;
    public final int lvl;

    public volatile String mode = "patrol"; // "hunt" | "patrol"
    public volatile UUID target;            // цель охоты
    public volatile Location anchor;        // точка патруля

    public Pet(UUID owner, NecroMob mob, int lvl) {
        this.owner = owner;
        this.mob = mob;
        this.lvl = lvl;
    }

    public boolean isHunting() {
        return "hunt".equals(mode);
    }
}
