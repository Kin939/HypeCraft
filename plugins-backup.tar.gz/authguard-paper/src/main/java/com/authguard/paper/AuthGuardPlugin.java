package com.authguard.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * AuthGuard — авторизация для пиратского сервера.
 * Мир-пустота с полем перевёрнутых «Т» (символ харТкорного сервера), звуки
 * умирающей свиньи, пароли PBKDF2, сессия 3 дня при том же IP, запрет
 * мультиаккаунтов от мёртвых игроков.
 */
public final class AuthGuardPlugin extends JavaPlugin {

    /** Аккаунт в data.yml. */
    public static final class Account {
        public String name;
        public String salt;      // base64
        public String hash;      // base64 (PBKDF2)
        public String lastIp;
        public long lastLogin;
        public String lastWorld;
        public double lastX, lastY, lastZ;
        public float lastYaw, lastPitch;
    }

    private final Map<String, Account> accounts = new ConcurrentHashMap<>();
    private final Map<String, Account> pendingLast = new ConcurrentHashMap<>();
    private final Set<String> authed = ConcurrentHashMap.newKeySet();
    private final Map<String, BukkitTask> timeouts = new ConcurrentHashMap<>();
    public boolean internalTeleport = false;

    private AuthStore store;
    private DeadRegistry deadRegistry;
    private InvStash stash;
    private World authWorld;
    private final Random rnd = new Random();

    /** Палитра полных непрозрачных блоков для букв (собирается автоматически). */
    private static final List<Material> PALETTE = new ArrayList<>();

    public Map<String, Account> accounts() {
        return accounts;
    }

    /** Последние позиции ещё не зарегистрированных игроков (до создания аккаунта). */
    public Map<String, Account> pendingLast() {
        return pendingLast;
    }

    public AuthStore store() {
        return store;
    }

    public DeadRegistry deadRegistry() {
        return deadRegistry;
    }

    public InvStash stash() {
        return stash;
    }

    public boolean isAuthed(Player p) {
        return authed.contains(p.getName().toLowerCase(Locale.ROOT));
    }

    public void markAuthed(String nameLower) {
        authed.add(nameLower);
    }

    public void markUnauthed(String nameLower) {
        authed.remove(nameLower);
    }

    public World authWorld() {
        return authWorld;
    }

    public int sessionDays() {
        return Math.max(0, getConfig().getInt("session-days", 3));
    }

    public int minPasswordLength() {
        return Math.max(3, getConfig().getInt("min-password-length", 6));
    }

    /* ---------------- включение ---------------- */

    @Override
    public void onEnable() {
        saveDefaultConfig();
        deadRegistry = new DeadRegistry(this);
        store = new AuthStore(this);
        store.load();
        deadRegistry.reload();
        stash = new InvStash(this);

        authWorld = Bukkit.getWorld("auth-world");
        if (authWorld == null) {
            authWorld = Bukkit.createWorld(new WorldCreator("auth-world")
                    .generator(new VoidGenerator())
                    .environment(World.Environment.NORMAL));
            getLogger().info("Мир авторизации создан: auth-world (пустота).");
        }
        if (authWorld != null) {
            authWorld.setSpawnLocation(8, 80, 8);
            authWorld.setGameRule(GameRule.DO_MOB_SPAWNING, false);
            authWorld.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
            authWorld.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
            authWorld.setGameRule(GameRule.DO_INSOMNIA, false);
        }
        ensureAuthPlatform();

        buildPalette();
        if (!store.isLettersGenerated()) {
            scheduleLetterField();
        }

        Bukkit.getPluginManager().registerEvents(new AuthListener(this), this);

        AuthCommands authCmds = new AuthCommands(this);
        var login = getCommand("login");
        if (login != null) login.setExecutor(authCmds);
        var register = getCommand("register");
        if (register != null) register.setExecutor(authCmds);
        var admin = getCommand("authadmin");
        if (admin != null) {
            AuthAdminCommand ac = new AuthAdminCommand(this);
            admin.setExecutor(ac);
            admin.setTabCompleter(ac);
        }

        long every = Math.max(40, getConfig().getLong("reminder-interval-ticks", 100L));
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (isAuthed(p)) continue;
                boolean isNew = !accounts.containsKey(p.getName().toLowerCase(Locale.ROOT));
                p.sendActionBar(Component.text(isNew
                        ? "⚠ /register <пароль> <пароль> — создай аккаунт"
                        : "⚠ /login <пароль> — войди в аккаунт", NamedTextColor.YELLOW));
            }
        }, every, every);

        schedulePigDoom();

        getLogger().info("AuthGuard включён. Аккаунтов: " + accounts.size() + ".");
    }

    /* ---------------- невидимая платформа входа ---------------- */

    /**
     * Невидимая платформа (barrier) 3×3 под точкой входа — игрок стоит,
     * а не падает в бездну. Ставится при каждом включении, идемпотентно.
     */
    private void ensureAuthPlatform() {
        if (authWorld == null) return;
        int bx = 8, by = 79, bz = 8;
        boolean ok = true;
        for (int dx = -1; dx <= 1 && ok; dx++) {
            for (int dz = -1; dz <= 1 && ok; dz++) {
                if (authWorld.getBlockAt(bx + dx, by, bz + dz).getType() != Material.BARRIER) ok = false;
            }
        }
        if (ok) return;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                authWorld.getBlockAt(bx + dx, by, bz + dz).setType(Material.BARRIER, false);
                // очищаем над платформой и прямо под ней — вдруг туда попала буква
                for (int dy = 1; dy <= 3; dy++) {
                    authWorld.getBlockAt(bx + dx, by + dy, bz + dz).setType(Material.AIR, false);
                }
                authWorld.getBlockAt(bx + dx, by - 1, bz + dz).setType(Material.AIR, false);
            }
        }
        getLogger().info("Невидимая платформа входа (barrier 3×3) готова: " + bx + "," + by + "," + bz + ".");
    }

    /* ---------------- поле перевёрнутых «Т» ---------------- */

    private void buildPalette() {
        if (!PALETTE.isEmpty()) return;
        for (Material m : Material.values()) {
            if (!m.isBlock() || m.hasGravity()) continue;
            try {
                if (m.createBlockData().isOccluding()) PALETTE.add(m);
            } catch (Throwable ignored) {
                // не все материалы дают block data — пропускаем
            }
        }
        getLogger().info("Палитра букв: " + PALETTE.size() + " блоков.");
    }

    private Material randomBody(Random r) {
        return PALETTE.get(r.nextInt(PALETTE.size()));
    }

    private Material randomCap(Random r, Material body) {
        Material cap = randomBody(r);
        int guard = 0;
        while (cap == body && guard++ < 10) cap = randomBody(r);
        return cap != body ? cap : Material.STONE;
    }

    /** Ставит перевёрнутую «Т» (5 блоков): основание 3×1, ножка, верх из другого блока. */
    private void placeLetter(Location l, Random r) {
        Material body = randomBody(r);
        Material cap = randomCap(r, body);
        int x = l.getBlockX(), y = l.getBlockY(), z = l.getBlockZ();
        World w = l.getWorld();
        for (int dx = -1; dx <= 1; dx++) {
            Block b = w.getBlockAt(x + dx, y, z);
            b.setType(body, false);
        }
        w.getBlockAt(x, y + 1, z).setType(body, false);
        w.getBlockAt(x, y + 2, z).setType(cap, false);
    }

    /** Однократная генерация поля букв (флаг в data.yml). */
    private void scheduleLetterField() {
        int radius = Math.max(32, getConfig().getInt("letters.radius", 160));
        int count = Math.max(10, getConfig().getInt("letters.count", 350));
        int minDist = Math.max(6, getConfig().getInt("letters.min-distance", 14));
        int yMin = getConfig().getInt("letters.y-min", 72);
        int yMax = Math.max(yMin + 1, getConfig().getInt("letters.y-max", 88));

        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (authWorld == null) return;
            List<Location> spots = new ArrayList<>();
            int attempts = 0;
            while (spots.size() < count && attempts < count * 50) {
                attempts++;
                int x = 8 + rnd.nextInt(radius * 2 + 1) - radius;
                int z = 8 + rnd.nextInt(radius * 2 + 1) - radius;
                int ddx = x - 8, ddz = z - 8;
                if (ddx * ddx + ddz * ddz < 144) continue; // не сажаем буквы на платформу входа
                int y = yMin + rnd.nextInt(yMax - yMin + 1);
                boolean ok = true;
                for (Location s : spots) {
                    int dx = s.getBlockX() - x, dz = s.getBlockZ() - z, dy = s.getBlockY() - y;
                    if (dx * dx + dz * dz < minDist * minDist && Math.abs(dy) < 8) {
                        ok = false;
                        break;
                    }
                }
                if (ok) spots.add(new Location(authWorld, x, y, z));
            }
            getLogger().info("Ставлю поле перевёрнутых «Т»: " + spots.size() + " шт (это пару секунд)…");
            final int[] idx = {0};
            final BukkitTask[] self = new BukkitTask[1];
            self[0] = Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
                @Override
                public void run() {
                    int placed = 0;
                    while (idx[0] < spots.size() && placed < 25) {
                        placeLetter(spots.get(idx[0]++), rnd);
                        placed++;
                    }
                    if (idx[0] >= spots.size()) {
                        store.setLettersGenerated(true);
                        if (!spots.isEmpty()) {
                            Location f = spots.get(0);
                            getLogger().info("Поле «Т» готово. Пример: " + f.getBlockX() + " "
                                    + f.getBlockY() + " " + f.getBlockZ());
                        }
                        if (self[0] != null) self[0].cancel(); // только свою задачу
                    }
                }
            }, 1L, 1L);
        }, 40L);
    }

    /* ---------------- умирающая свинья ---------------- */

    private void schedulePigDoom() {
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (authWorld != null) {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (isAuthed(p) || p.getWorld() != authWorld) continue;
                    Location l = p.getLocation().add(rnd.nextDouble() * 10 - 5,
                            rnd.nextDouble() * 4 - 1, rnd.nextDouble() * 10 - 5);
                    float pitch = 0.6f + rnd.nextFloat() * 0.9f;
                    p.playSound(l, pickPigSound(), 0.8f, pitch);
                }
            }
            schedulePigDoom(); // и так каждую секунду
        }, 20L);
    }

    /** Свиной репертуар: визг, обиженный писк, хрюканье, седельный визг. */
    private Sound pickPigSound() {
        return switch (rnd.nextInt(10)) {
            case 0, 1, 2, 3 -> Sound.ENTITY_PIG_DEATH; // 40% — визг умирающей
            case 4, 5, 6 -> Sound.ENTITY_PIG_HURT;     // 30% — обиженный писк
            case 7, 8 -> Sound.ENTITY_PIG_AMBIENT;     // 20% — хрюканье
            default -> Sound.ENTITY_PIG_SADDLE;        // 10% — визг с седлом
        };
    }

    /* ---------------- поток авторизации ---------------- */

    public boolean sessionValid(String nameLower, String ip) {
        Account a = accounts.get(nameLower);
        if (a == null) return false;
        long days = sessionDays();
        if (days == 0) return false;
        boolean inTime = System.currentTimeMillis() - a.lastLogin < days * 86_400_000L;
        // Белый список: смена IP сессию не ломает — пароль не спрашиваем.
        if (store.isIpBypassed(nameLower)) return inTime;
        if (a.lastIp == null || ip == null) return false;
        if (!a.lastIp.equals(ip)) return false;
        return inTime;
    }

    /** Завершить вход: телепорт в обычный мир, дымок, тайтл. */
    public void finishLogin(Player p, boolean auto) {
        String key = p.getName().toLowerCase(Locale.ROOT);
        authed.add(key); // разморозка: все фриз-проверки (движение, урон и т.д.) смотрят на isAuthed
        BukkitTask t = timeouts.remove(key);
        if (t != null) t.cancel();

        Location dest = null;
        Account a = accounts.get(key);
        if (a != null && a.lastWorld != null) {
            World w = Bukkit.getWorld(a.lastWorld);
            if (w != null) {
                dest = new Location(w, a.lastX, a.lastY, a.lastZ, a.lastYaw, a.lastPitch);
            }
        }
        if (dest == null) {
            dest = Bukkit.getWorlds().get(0).getSpawnLocation();
        }

        List<ItemStack> leftovers = stash.restore(p); // вещи обратно ДО телепорта
        internalTeleport = true;
        try {
            p.teleport(dest);
        } finally {
            internalTeleport = false;
        }
        for (ItemStack it : leftovers) {
            dest.getWorld().dropItemNaturally(dest, it);
        }
        arrivalSmoke(dest);
        p.showTitle(Title.title(
                Component.text("Приятной игры", NamedTextColor.GOLD),
                Component.text("на сервере догорай игрок!", NamedTextColor.YELLOW),
                Title.Times.times(Duration.ofMillis(250), Duration.ofSeconds(4), Duration.ofMillis(600))));
        p.sendMessage(Component.text("✅ Авторизация пройдена. Приятной игры на сервере, догорай игрок!",
                NamedTextColor.GREEN));
        p.setFallDistance(0f);
    }

    /** Дымок при появлении в обычном мире (без звука). */
    public void arrivalSmoke(Location loc) {
        loc.getWorld().spawnParticle(org.bukkit.Particle.LARGE_SMOKE,
                loc.clone().add(0, 1, 0), 18, 0.35, 0.6, 0.35, 0.02);
        loc.getWorld().spawnParticle(org.bukkit.Particle.SMOKE,
                loc.clone().add(0, 1, 0), 22, 0.45, 0.8, 0.45, 0.015);
        loc.getWorld().spawnParticle(org.bukkit.Particle.CAMPFIRE_COSY_SMOKE,
                loc.clone().add(0, 1.4, 0), 6, 0.2, 0.2, 0.2, 0.004);
    }

    public void startTimeout(Player p) {
        int sec = Math.max(10, getConfig().getInt("timeout-seconds", 60));
        String key = p.getName().toLowerCase(Locale.ROOT);
        BukkitTask old = timeouts.remove(key);
        if (old != null) old.cancel();
        timeouts.put(key, Bukkit.getScheduler().runTaskLater(this, () -> {
            Player online = p.isOnline() ? p : Bukkit.getPlayerExact(p.getName());
            if (online != null && !isAuthed(online)) {
                online.kick(Component.text("⏱ Время на авторизацию истекло (" + sec + " сек).",
                        NamedTextColor.RED));
            }
        }, sec * 20L));
    }

    public void cancelTimeout(String nameLower) {
        BukkitTask t = timeouts.remove(nameLower);
        if (t != null) t.cancel();
    }

    /** Отправить игрока в мир авторизации. */
    public void sendToAuth(Player p) {
        if (authWorld == null) return;
        stash.stash(p); // вещи спрятаны и записаны на диск — не потеряются
        Location spawn = authWorld.getSpawnLocation().add(0.5, 0, 0.5); // центр barrier-платформы
        spawn.getChunk().load();
        internalTeleport = true;
        try {
            p.teleport(spawn);
        } finally {
            internalTeleport = false;
        }
        p.setFallDistance(0f);
    }

    /** Тайтл входа/регистрации — «свинота». */
    public void showAuthTitle(Player p) {
        boolean isNew = !accounts.containsKey(p.getName().toLowerCase(Locale.ROOT));
        if (isNew) {
            p.showTitle(Title.title(
                    Component.text("РЕГИСТРИРУЙСЯ СВИНОТА", NamedTextColor.GOLD),
                    Component.text("/register <пароль> <пароль>", NamedTextColor.WHITE),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(6), Duration.ofSeconds(1))));
        } else {
            p.showTitle(Title.title(
                    Component.text("ЛОГИНЬСЯ СВИНОТА", NamedTextColor.AQUA),
                    Component.text("/login <пароль>", NamedTextColor.WHITE),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(6), Duration.ofSeconds(1))));
        }
    }

    /* ---------------- пароли ---------------- */

    public static String newSalt() {
        byte[] salt = new byte[16];
        new java.security.SecureRandom().nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    public static String hash(String password, String saltB64) {
        try {
            var spec = new javax.crypto.spec.PBEKeySpec(password.toCharArray(),
                    Base64.getDecoder().decode(saltB64), 120_000, 256);
            var f = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            return Base64.getEncoder().encodeToString(f.generateSecret(spec).getEncoded());
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public static boolean verify(String password, String saltB64, String hashB64) {
        byte[] a = Base64.getDecoder().decode(hash(password, saltB64));
        byte[] b = Base64.getDecoder().decode(hashB64);
        return java.security.MessageDigest.isEqual(a, b);
    }

    /* ---------------- пустой генератор ---------------- */

    /** Пустота: ни одного блока в чанках (буквы ставит сам плагин). */
    public static final class VoidGenerator extends ChunkGenerator {
        @Override
        public ChunkData generateChunkData(World world, java.util.Random random, int x, int z, BiomeGrid biome) {
            return createChunkData(world);
        }

        @Override
        public boolean shouldGenerateNoise() {
            return false;
        }

        @Override
        public boolean shouldGenerateSurface() {
            return false;
        }

        @Override
        public boolean shouldGenerateCaves() {
            return false;
        }

        @Override
        public boolean shouldGenerateDecorations() {
            return false;
        }

        @Override
        public boolean shouldGenerateMobs() {
            return false;
        }

        @Override
        public boolean shouldGenerateStructures() {
            return false;
        }
    }
}
