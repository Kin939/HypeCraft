package com.anyportal.paper;

import org.bukkit.Material;
import org.bukkit.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Поиск «пузыря» воздуха, замкнутого обсидианом, заливкой в вертикальной плоскости.
 * Плоскость задаётся осью: вдоль X (z фиксирован) или вдоль Z (x фиксирован).
 * Любая форма годится — треугольник, ромб, круг: важно, чтобы каждая клетка нутра
 * всеми четырьмя соседями в плоскости касалась либо нутра, либо обсидиана.
 */
public final class PortalShape {

    /** Найденный нутр портала: список упакованных координат. */
    public record Pocket(List<Long> cells) {
        public int size() {
            return cells.size();
        }
    }

    private PortalShape() {}

    private static boolean fillable(Material m) {
        return m.isAir() || m == Material.FIRE || m == Material.SOUL_FIRE;
    }

    /**
     * @param alongX если true — плоскость X-Y (z фиксирован, портал с axis=x),
     *               иначе — Z-Y (x фиксирован, axis=z).
     * @return нутр портала или null, если контур не замкнут обсидианом / слишком велик.
     */
    public static Pocket scan(World w, int sx, int sy, int sz, boolean alongX, int cap) {
        if (!fillable(w.getBlockAt(sx, sy, sz).getType())) return null;

        ArrayDeque<long[]> queue = new ArrayDeque<>();
        Set<Long> seen = new HashSet<>();
        queue.add(new long[]{sx, sy, sz});
        seen.add(PortalRegistry.pack(sx, sy, sz));

        int minY = w.getMinHeight();
        int maxY = w.getMaxHeight() - 1;

        while (!queue.isEmpty()) {
            long[] c = queue.poll();
            int x = (int) c[0], y = (int) c[1], z = (int) c[2];

            // 4 соседа в плоскости портала
            int[][] dirs = alongX
                    ? new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}} // dx, dy
                    : new int[][]{{0, 1}, {0, -1}, {1, 0}, {-1, 0}}; // dz, dy
            for (int[] d : dirs) {
                int nx, nz;
                int ny = y + d[1];
                if (alongX) {
                    nx = x + d[0];
                    nz = z;
                } else {
                    nx = x;
                    nz = z + d[0];
                }
                if (ny < minY || ny > maxY) return null; // ушло за границы мира
                Material m = w.getBlockAt(nx, ny, nz).getType();
                if (m == Material.OBSIDIAN) continue;    // граница — ок
                if (!fillable(m)) return null;           // чужой блок — контур не замкнут
                Long key = PortalRegistry.pack(nx, ny, nz);
                if (seen.add(key)) {
                    if (seen.size() > cap) return null;  // слишком большой — защита
                    queue.add(new long[]{nx, ny, nz});
                }
            }
        }
        if (seen.isEmpty()) return null;
        return new Pocket(new ArrayList<>(seen));
    }
}
