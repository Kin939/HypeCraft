package com.hardcorerevival.paper;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/**
 * PvP protection (two-way). A protected player neither takes nor deals player
 * damage — melee, projectiles, potions and trident hits all count.
 */
public class ProtectionListener implements Listener {

    private final HardcoreRevivalPlugin plugin;

    public ProtectionListener(HardcoreRevivalPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        Player damager = resolvePlayerDamager(event.getDamager());
        if (damager == null || damager.equals(victim)) return;

        var store = plugin.store();
        boolean victimProtected = store.isProtected(victim.getUniqueId());
        boolean damagerProtected = store.isProtected(damager.getUniqueId());
        if (!victimProtected && !damagerProtected) return;

        event.setCancelled(true);

        long now = System.currentTimeMillis();
        if (victimProtected) {
            long left = store.protectionUntil(victim.getUniqueId()) - now;
            Effects.actionbar(damager, "✦ " + victim.getName() + " под защитой игроков: "
                    + Effects.formatDuration(left), NamedTextColor.AQUA);
        } else {
            long left = store.protectionUntil(damager.getUniqueId()) - now;
            Effects.actionbar(damager, "✦ Твоя защита ещё активна (" + Effects.formatDuration(left)
                    + ") — ты не можешь бить игроков", NamedTextColor.GOLD);
        }
        damager.playSound(damager.getLocation(),
                org.bukkit.Sound.BLOCK_NOTE_BLOCK_DIDGERIDOO, 0.6f, 0.8f);
    }

    /** The player behind a melee hit or a projectile (arrow, trident, potion…). */
    private static Player resolvePlayerDamager(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Player p) return p;
        return null;
    }
}
