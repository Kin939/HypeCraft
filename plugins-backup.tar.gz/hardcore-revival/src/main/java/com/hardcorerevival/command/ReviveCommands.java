package com.hardcorerevival.command;

import com.hardcorerevival.Config;
import com.hardcorerevival.data.RevivalSavedData;
import com.hardcorerevival.logic.RevivalManager;
import com.hardcorerevival.util.Msg;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.UUID;

/**
 * /revive            — player-facing commands
 * /revivaladmin      — operator commands (permission level 2)
 */
public final class ReviveCommands {

    private ReviveCommands() {
    }

    private static final SuggestionProvider<CommandSourceStack> DEAD_PLAYERS = (context, builder) -> {
        RevivalSavedData data = RevivalManager.data(context.getSource().getServer());
        for (RevivalSavedData.DeathEntry e : data.deathsSnapshot().values()) {
            builder.suggest(e.name());
        }
        return builder.buildFuture();
    };

    private static final SuggestionProvider<CommandSourceStack> ONLINE_PLAYERS = (context, builder) -> {
        for (ServerPlayer p : context.getSource().getServer().getPlayerList().getPlayers()) {
            builder.suggest(p.getName().getString());
        }
        return builder.buildFuture();
    };

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("revive")
                .then(Commands.literal("list").executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    RevivalManager.sendReviveMenu(player);
                    return 1;
                }))
                .then(Commands.literal("time").executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    RevivalManager.sendStatus(player);
                    return 1;
                }))
                .then(Commands.literal("accept")
                        .then(Commands.argument("target", StringArgumentType.word())
                                .suggests(DEAD_PLAYERS)
                                .executes(ctx -> {
                                    ServerPlayer reviver = ctx.getSource().getPlayerOrException();
                                    return acceptStarRevive(reviver, StringArgumentType.getString(ctx, "target"));
                                }))));

        dispatcher.register(Commands.literal("revivaladmin")
                .requires(src -> src.permissions().hasPermission(Permissions.COMMANDS_ADMIN))
                .then(Commands.literal("revive")
                        .then(Commands.argument("target", StringArgumentType.word())
                                .suggests(DEAD_PLAYERS)
                                .executes(ctx -> {
                                    UUID target = requireDead(ctx);
                                    if (target == null) return 0;
                                    ServerPlayer online = ctx.getSource().getServer().getPlayerList().getPlayer(target);
                                    if (online != null) {
                                        RevivalManager.reviveOnline(online, " (возрождён администратором)");
                                    } else {
                                        RevivalManager.reviveById(ctx.getSource().getServer(), target,
                                                " (возрождён администратором)");
                                    }
                                    ctx.getSource().sendSuccess(() -> Component.literal(
                                            "✅ Возрождён: " + nameOf(ctx.getSource().getServer(), target)), false);
                                    return 1;
                                })))
                .then(Commands.literal("spectate")
                        .then(Commands.argument("player", StringArgumentType.word())
                                .suggests(ONLINE_PLAYERS)
                                .executes(ctx -> {
                                    ServerPlayer target = requireOnline(ctx, "player");
                                    if (target == null) return 0;
                                    RevivalManager.forceSpectate(ctx.getSource().getServer(), target);
                                    ctx.getSource().sendSuccess(() -> Component.literal(
                                            "☠ " + target.getName().getString() + " отправлен наблюдателем"), false);
                                    return 1;
                                })))
                .then(Commands.literal("time")
                        .then(Commands.argument("player", StringArgumentType.word())
                                .suggests(ONLINE_PLAYERS)
                                .executes(ctx -> {
                                    ServerPlayer target = requireOnline(ctx, "player");
                                    if (target == null) return 0;
                                    RevivalManager.sendStatus(target);
                                    return 1;
                                })))
                .then(Commands.literal("settime")
                        .then(Commands.argument("player", StringArgumentType.word())
                                .suggests(ONLINE_PLAYERS)
                                .then(Commands.argument("seconds", IntegerArgumentType.integer(0))
                                        .executes(ctx -> {
                                            ServerPlayer target = requireOnline(ctx, "player");
                                            if (target == null) return 0;
                                            int seconds = IntegerArgumentType.getInteger(ctx, "seconds");
                                            MinecraftServer server = ctx.getSource().getServer();
                                            RevivalSavedData data = RevivalManager.data(server);
                                            if (!data.isDead(target.getUUID())) {
                                                ctx.getSource().sendFailure(Component.literal(
                                                        "⚠ " + target.getName().getString() + " не мёртв"));
                                                return 0;
                                            }
                                            data.setDeath(target.getUUID(),
                                                    System.currentTimeMillis() + seconds * 1000L,
                                                    target.getName().getString());
                                            RevivalManager.placeSpectator(target);
                                            ctx.getSource().sendSuccess(() -> Component.literal(
                                                    "⏱ Осталось: " + Msg.formatDuration(seconds * 1000L)), false);
                                            return 1;
                                        }))))
                .then(Commands.literal("clear")
                        .then(Commands.argument("player", StringArgumentType.word())
                                .suggests(ONLINE_PLAYERS)
                                .executes(ctx -> {
                                    ServerPlayer target = requireOnline(ctx, "player");
                                    if (target == null) return 0;
                                    RevivalManager.forceRelease(ctx.getSource().getServer(), target);
                                    ctx.getSource().sendSuccess(() -> Component.literal(
                                            "✅ Состояние сброшено: " + target.getName().getString()), false);
                                    return 1;
                                }))));
    }

    /* ---------------- star revive ---------------- */

    private static int acceptStarRevive(ServerPlayer reviver, String targetName) {
        MinecraftServer server = reviver.level().getServer();
        RevivalSavedData data = RevivalManager.data(server);

        if (data.isDead(reviver.getUUID())) {
            reviver.sendSystemMessage(Msg.icon("☠", ChatFormatting.RED, "Мёртвые не могут возрождать других."));
            return 0;
        }

        InteractionHand starHand = null;
        for (InteractionHand hand : InteractionHand.values()) {
            if (reviver.getItemInHand(hand).is(Items.NETHER_STAR)) {
                starHand = hand;
                break;
            }
        }
        if (starHand == null) {
            reviver.sendSystemMessage(Msg.icon("⚠", ChatFormatting.YELLOW, "Держи звезду Визера в руке!"));
            return 0;
        }

        UUID targetId = data.findDeadByName(targetName);
        if (targetId == null) {
            reviver.sendSystemMessage(Msg.icon("⚠", ChatFormatting.YELLOW,
                    "Игрок \"" + targetName + "\" не найден среди мёртвых."));
            return 0;
        }
        if (targetId.equals(reviver.getUUID())) {
            reviver.sendSystemMessage(Msg.icon("⚠", ChatFormatting.YELLOW, "Нельзя возродить себя."));
            return 0;
        }

        if (Config.CONSUME_STAR.get()) {
            ItemStack star = reviver.getItemInHand(starHand);
            star.shrink(1);
        }

        RevivalManager.reviveById(server, targetId,
                " (возрождён звездой Визера — " + reviver.getName().getString() + ")");
        return 1;
    }

    /* ---------------- helpers ---------------- */

    private static UUID requireDead(CommandContext<CommandSourceStack> ctx) {
        String name = StringArgumentType.getString(ctx, "target");
        RevivalSavedData data = RevivalManager.data(ctx.getSource().getServer());
        UUID id = data.findDeadByName(name);
        if (id == null) {
            ctx.getSource().sendFailure(Component.literal("⚠ \"" + name + "\" не найден среди мёртвых"));
        }
        return id;
    }

    private static ServerPlayer requireOnline(CommandContext<CommandSourceStack> ctx, String arg) {
        String name = StringArgumentType.getString(ctx, arg);
        ServerPlayer p = ctx.getSource().getServer().getPlayerList().getPlayer(name);
        if (p == null) {
            ctx.getSource().sendFailure(Component.literal("⚠ Игрок \"" + name + "\" не в сети"));
        }
        return p;
    }

    private static String nameOf(MinecraftServer server, UUID id) {
        ServerPlayer online = server.getPlayerList().getPlayer(id);
        if (online != null) return online.getName().getString();
        RevivalSavedData.DeathEntry e = RevivalManager.data(server).deathEntry(id);
        return e != null ? e.name() : id.toString();
    }
}
