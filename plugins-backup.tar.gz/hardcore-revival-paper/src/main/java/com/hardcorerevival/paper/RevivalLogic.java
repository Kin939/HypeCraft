package com.hardcorerevival.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;
import java.util.UUID;

/** The star → GUI → LMB-on-head revive flow. */
final class RevivalLogic {

    private RevivalLogic() {
    }

    /** Player just left-clicked a dead player's head in the menu. */
    static void handleHeadClick(HardcoreRevivalPlugin plugin, Player viewer, UUID target) {
        var store = plugin.store();

        if (!store.isDead(target)) {
            viewer.sendMessage(Component.text("⚠ Этот игрок уже возрождён.", NamedTextColor.YELLOW));
            viewer.closeInventory();
            ReviveMenu.refreshAll();
            return;
        }

        if (!viewer.getInventory().contains(Material.NETHER_STAR)) {
            viewer.sendMessage(Component.text("⚠ Нужна звезда Визера в инвентаре!", NamedTextColor.YELLOW));
            return;
        }

        if (plugin.cfg().consumeStarOnRevive()) {
            viewer.getInventory().removeItem(new ItemStack(Material.NETHER_STAR, 1));
        }

        Player targetPlayer = Bukkit.getPlayer(target);
        if (targetPlayer != null && targetPlayer.isOnline()) {
            Revival.reviveOnline(plugin, targetPlayer, viewer.getLocation(),
                    " (возрождён звездой Визера — " + viewer.getName() + ")");
        } else {
            store.setProtection(target, System.currentTimeMillis() + plugin.cfg().protectionMs());
            store.setReviveNextTo(target, Optional.of(viewer.getUniqueId()));
            String name = store.deathName(target);
            Effects.broadcast(plugin, Component.text("✨ ", NamedTextColor.GOLD)
                    .append(Component.text(name, NamedTextColor.YELLOW))
                    .append(Component.text(" возродится рядом с ", NamedTextColor.GRAY))
                    .append(Component.text(viewer.getName(), NamedTextColor.YELLOW))
                    .append(Component.text(" при входе на сервер", NamedTextColor.GRAY)));
        }

        viewer.closeInventory();
        ReviveMenu.refreshAll();
    }

    /** Opens the menu for a player (from the star right-click or /revive). */
    static void openMenu(HardcoreRevivalPlugin plugin, Player viewer) {
        if (plugin.store().isDead(viewer.getUniqueId())) {
            Effects.actionbar(viewer, "☠ Мёртвые не могут возрождать других", NamedTextColor.RED);
            return;
        }
        new ReviveMenu(plugin).open(viewer);
    }

    /** /revive time — personal status. */
    static void status(Player p, HardcoreRevivalPlugin plugin) {
        var store = plugin.store();
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        if (store.isDead(id)) {
            p.sendMessage(Component.text("☠ Ты мёртв. Возрождение через "
                    + Effects.formatDuration(store.deadline(id) - now), NamedTextColor.RED));
        } else if (store.isProtected(id)) {
            p.sendMessage(Component.text("✦ Защита от игроков: "
                    + Effects.formatDuration(store.protectionUntil(id) - now), NamedTextColor.GOLD));
        } else {
            p.sendMessage(Component.text("✅ Ты жив и не защищён.", NamedTextColor.GREEN));
        }
    }
}
