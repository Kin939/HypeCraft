package com.hardcorerevival.paper;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/** Right-click with a nether star opens the revival GUI. */
public class StarListener implements Listener {

    private final HardcoreRevivalPlugin plugin;

    public StarListener(HardcoreRevivalPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onStarUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action a = event.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null || item.getType() != Material.NETHER_STAR) return;

        event.setCancelled(true);
        Player p = event.getPlayer();
        if (plugin.store().isDead(p.getUniqueId())) {
            Effects.actionbar(p, "☠ Мёртвые не могут возрождать других", NamedTextColor.RED);
            return;
        }
        RevivalLogic.openMenu(plugin, p);
    }
}
