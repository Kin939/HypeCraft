package com.authguard.paper;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Хранилище аккаунтов и ручного списка мёртвых — data.yml. */
public final class AuthStore {

    private final AuthGuardPlugin plugin;
    private final File file;

    /** Белый список IP-проверки: эти ники могут заходить с любых IP без кика и пароля. */
    private final Set<String> ipBypass = new HashSet<>();

    public AuthStore(AuthGuardPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    public boolean isIpBypassed(String nameLower) {
        return ipBypass.contains(nameLower);
    }

    public boolean addIpBypass(String nameLower) {
        boolean added = ipBypass.add(nameLower);
        if (added) save();
        return added;
    }

    public boolean removeIpBypass(String nameLower) {
        boolean removed = ipBypass.remove(nameLower);
        if (removed) save();
        return removed;
    }

    public Set<String> ipBypass() {
        return ipBypass;
    }

    public void load() {
        plugin.accounts().clear();
        plugin.deadRegistry().manual().clear();
        ipBypass.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);

        for (String n : y.getStringList("ip-bypass")) {
            ipBypass.add(n.toLowerCase(Locale.ROOT));
        }

        ConfigurationSection acc = y.getConfigurationSection("accounts");
        if (acc != null) {
            for (String key : acc.getKeys(false)) {
                ConfigurationSection s = acc.getConfigurationSection(key);
                if (s == null) continue;
                AuthGuardPlugin.Account a = new AuthGuardPlugin.Account();
                a.name = s.getString("name", key);
                a.salt = s.getString("salt", "");
                a.hash = s.getString("hash", "");
                a.lastIp = s.getString("last-ip", null);
                a.lastLogin = s.getLong("last-login", 0L);
                a.lastWorld = s.getString("last-world", null);
                a.lastX = s.getDouble("last-x", 0);
                a.lastY = s.getDouble("last-y", 0);
                a.lastZ = s.getDouble("last-z", 0);
                a.lastYaw = (float) s.getDouble("last-yaw", 0);
                a.lastPitch = (float) s.getDouble("last-pitch", 0);
                plugin.accounts().put(key.toLowerCase(Locale.ROOT), a);
            }
        }

        ConfigurationSection dead = y.getConfigurationSection("dead-manual");
        if (dead != null) {
            for (String key : dead.getKeys(false)) {
                plugin.deadRegistry().manual().put(key.toLowerCase(Locale.ROOT), dead.getLong(key, 0L));
            }
        }
    }

    /** Поле букв «Т» уже сгенерировано (однократно). */
    public boolean isLettersGenerated() {
        if (!file.exists()) return false;
        return YamlConfiguration.loadConfiguration(file).getBoolean("letters-generated", false);
    }

    public void setLettersGenerated(boolean v) {
        YamlConfiguration y = file.exists()
                ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
        y.set("letters-generated", v);
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (Exception ex) {
            plugin.getLogger().warning("data.yml: " + ex.getMessage());
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<String, AuthGuardPlugin.Account> e : plugin.accounts().entrySet()) {
            AuthGuardPlugin.Account a = e.getValue();
            String base = "accounts." + e.getKey() + ".";
            y.set(base + "name", a.name);
            y.set(base + "salt", a.salt);
            y.set(base + "hash", a.hash);
            y.set(base + "last-ip", a.lastIp == null ? "" : a.lastIp);
            y.set(base + "last-login", a.lastLogin);
            y.set(base + "last-world", a.lastWorld == null ? "" : a.lastWorld);
            y.set(base + "last-x", a.lastX);
            y.set(base + "last-y", a.lastY);
            y.set(base + "last-z", a.lastZ);
            y.set(base + "last-yaw", a.lastYaw);
            y.set(base + "last-pitch", a.lastPitch);
        }
        for (Map.Entry<String, Long> e : plugin.deadRegistry().manual().entrySet()) {
            y.set("dead-manual." + e.getKey(), e.getValue());
        }
        y.set("ip-bypass", ipBypass.isEmpty() ? null : new ArrayList<>(ipBypass));
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (Exception ex) {
            plugin.getLogger().warning("data.yml: " + ex.getMessage());
        }
    }
}
