package com.authguard.paper;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Кто «мёртв»: (1) живые смерти Hardcore Revival из deaths.yml,
 * (2) ручной список админа (бессрочный). Имена — lowercase.
 */
public final class DeadRegistry {

    private final AuthGuardPlugin plugin;
    /** Ник -> дедлайн смерти из Hardcore Revival. */
    private final Map<String, Long> hrDead = new ConcurrentHashMap<>();
    /** Ник -> 0 (ручной список, бессрочно). */
    private final Map<String, Long> manual = new ConcurrentHashMap<>();

    public DeadRegistry(AuthGuardPlugin plugin) {
        this.plugin = plugin;
    }

    public Map<String, Long> manual() {
        return manual;
    }

    public void reload() {
        hrDead.clear();
        File f = new File(plugin.getDataFolder().getParentFile(), "HardcoreRevival/deaths.yml");
        if (!f.exists()) return;
        try {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
            ConfigurationSection d = y.getConfigurationSection("deaths");
            if (d == null) return;
            long now = System.currentTimeMillis();
            for (String uuid : d.getKeys(false)) {
                long deadline = d.getLong(uuid + ".deadline", 0L);
                String name = d.getString(uuid + ".name", null);
                if (name == null || name.isEmpty()) continue;
                // Считаем мёртвым, только пока таймер смерти реально идёт.
                if (deadline > now) {
                    hrDead.put(name.toLowerCase(Locale.ROOT), deadline);
                }
            }
        } catch (Exception ex) {
            plugin.getLogger().warning("HardcoreRevival/deaths.yml: " + ex.getMessage());
        }
    }

    /** Полный набор мёртвых (HR + ручной). */
    public Set<String> all() {
        Set<String> all = new HashSet<>(hrDead.keySet());
        all.addAll(manual.keySet());
        return all;
    }

    public boolean isDead(String nameLower) {
        return hrDead.containsKey(nameLower) || manual.containsKey(nameLower);
    }
}
