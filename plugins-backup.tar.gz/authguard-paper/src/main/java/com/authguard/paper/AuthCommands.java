package com.authguard.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** /login и /register (алиасы /l, /reg). */
public final class AuthCommands implements CommandExecutor {

    private final AuthGuardPlugin plugin;

    public AuthCommands(AuthGuardPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String alias, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Component.text("⚠ Только для игроков.", NamedTextColor.YELLOW));
            return true;
        }
        String key = p.getName().toLowerCase(java.util.Locale.ROOT);

        if (plugin.isAuthed(p)) {
            p.sendMessage(Component.text("ℹ Ты уже авторизован.", NamedTextColor.GRAY));
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("register")) {
            handleRegister(p, key, args);
        } else {
            handleLogin(p, key, args);
        }
        return true;
    }

    private void handleRegister(Player p, String key, String[] args) {
        if (plugin.accounts().containsKey(key)) {
            p.sendMessage(Component.text("ℹ Аккаунт уже существует. Вход: /login <пароль>",
                    NamedTextColor.GRAY));
            return;
        }
        if (args.length < 2) {
            p.sendMessage(Component.text("Использование: /register <пароль> <повтор пароля>",
                    NamedTextColor.YELLOW));
            return;
        }
        String pass = args[0];
        if (!pass.equals(args[1])) {
            p.sendMessage(Component.text("✖ Пароли не совпадают.", NamedTextColor.RED));
            return;
        }
        int min = plugin.minPasswordLength();
        if (pass.length() < min) {
            p.sendMessage(Component.text("✖ Пароль слишком короткий: минимум " + min + " символов.",
                    NamedTextColor.RED));
            return;
        }
        if (pass.equalsIgnoreCase(p.getName())) {
            p.sendMessage(Component.text("✖ Пароль не должен совпадать с ником.", NamedTextColor.RED));
            return;
        }

        AuthGuardPlugin.Account a = new AuthGuardPlugin.Account();
        a.name = p.getName();
        a.salt = AuthGuardPlugin.newSalt();
        a.hash = AuthGuardPlugin.hash(pass, a.salt);
        a.lastIp = p.getAddress() == null ? null : p.getAddress().getAddress().getHostAddress();
        a.lastLogin = System.currentTimeMillis();
        plugin.accounts().put(key, a);

        // Возврат на последнее место, где игрок был до авторизации
        // (для новых игроков копим с момента захода во временном хранилище).
        AuthGuardPlugin.Account pend = plugin.pendingLast().remove(key);
        if (pend != null && pend.lastWorld != null) {
            a.lastWorld = pend.lastWorld;
            a.lastX = pend.lastX;
            a.lastY = pend.lastY;
            a.lastZ = pend.lastZ;
            a.lastYaw = pend.lastYaw;
            a.lastPitch = pend.lastPitch;
        }
        plugin.store().save();
        plugin.finishLogin(p, false);
    }

    private void handleLogin(Player p, String key, String[] args) {
        AuthGuardPlugin.Account a = plugin.accounts().get(key);
        if (a == null) {
            p.sendMessage(Component.text("ℹ Аккаунта нет. Регистрация: /register <пароль> <пароль>",
                    NamedTextColor.GRAY));
            return;
        }
        if (args.length < 1) {
            p.sendMessage(Component.text("Использование: /login <пароль>", NamedTextColor.YELLOW));
            return;
        }
        if (!AuthGuardPlugin.verify(args[0], a.salt, a.hash)) {
            p.sendMessage(Component.text("✖ Неверный пароль.", NamedTextColor.RED));
            return;
        }
        a.lastIp = p.getAddress() == null ? null : p.getAddress().getAddress().getHostAddress();
        a.lastLogin = System.currentTimeMillis();
        plugin.store().save();
        plugin.finishLogin(p, false);
    }
}
