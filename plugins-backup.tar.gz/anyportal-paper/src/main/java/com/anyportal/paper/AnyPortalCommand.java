package com.anyportal.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;

/** /anyportal — список, инфо, удаление, перезагрузка реестра порталов. */
public final class AnyPortalCommand implements CommandExecutor, TabCompleter {

    private final AnyPortalPlugin plugin;
    private final PortalRegistry registry;

    public AnyPortalCommand(AnyPortalPlugin plugin, PortalRegistry registry) {
        this.plugin = plugin;
        this.registry = registry;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 0) {
            usage(sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "list" -> list(sender);
            case "info" -> info(sender, args);
            case "remove" -> remove(sender, args);
            case "removeall" -> {
                int n = registry.all().size();
                registry.clear();
                sender.sendMessage(Component.text("✅ Удалено порталов: " + n + ".", NamedTextColor.GREEN));
            }
            case "reload" -> {
                registry.load();
                sender.sendMessage(Component.text("✅ Реестр порталов перечитан: "
                        + registry.all().size() + " шт.", NamedTextColor.GREEN));
            }
            default -> usage(sender);
        }
        return true;
    }

    private void usage(CommandSender s) {
        s.sendMessage(Component.text("Использование:", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/anyportal list — все порталы", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/anyportal info <id> — детали портала", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/anyportal remove <id> — погасить портал", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/anyportal removeall — погасить всё", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/anyportal reload — перечитать portals.yml", NamedTextColor.GRAY));
    }

    private void list(CommandSender s) {
        var all = registry.all();
        s.sendMessage(Component.text("— Порталы AnyPortal (" + all.size() + ") —", NamedTextColor.LIGHT_PURPLE));
        if (all.isEmpty()) {
            s.sendMessage(Component.text("  (пусто — зажги обсидианный контур любой формы огнивом)",
                    NamedTextColor.DARK_GRAY));
            return;
        }
        Map<String, Integer> byWorld = new java.util.TreeMap<>();
        for (PortalRegistry.Portal p : all.values()) {
            byWorld.merge(p.world, 1, Integer::sum);
        }
        for (var e : byWorld.entrySet()) {
            s.sendMessage(Component.text("  " + e.getKey() + ": " + e.getValue() + " шт.", NamedTextColor.GRAY));
        }
        s.sendMessage(Component.text("  ID: " + String.join(", ", all.keySet().stream().sorted().toList()),
                NamedTextColor.DARK_GRAY));
    }

    private void info(CommandSender s, String[] args) {
        if (args.length < 2) {
            s.sendMessage(Component.text("Использование: /anyportal info <id>", NamedTextColor.YELLOW));
            return;
        }
        PortalRegistry.Portal p = registry.byPrefix(args[1]);
        if (p == null) {
            s.sendMessage(Component.text("ℹ Портал \"" + args[1] + "\" не найден.", NamedTextColor.GRAY));
            return;
        }
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        for (Long v : p.blocks) {
            minX = Math.min(minX, PortalRegistry.unpackX(v));
            maxX = Math.max(maxX, PortalRegistry.unpackX(v));
            minY = Math.min(minY, PortalRegistry.unpackY(v));
            maxY = Math.max(maxY, PortalRegistry.unpackY(v));
            minZ = Math.min(minZ, PortalRegistry.unpackZ(v));
            maxZ = Math.max(maxZ, PortalRegistry.unpackZ(v));
        }
        s.sendMessage(Component.text("— Портал [" + p.id + "] —", NamedTextColor.LIGHT_PURPLE));
        s.sendMessage(Component.text("Мир: " + p.world + ", блоков нутра: " + p.blocks.size(),
                NamedTextColor.GRAY));
        s.sendMessage(Component.text("Габариты: " + (maxX - minX + 1) + "×" + (maxY - minY + 1)
                + "×" + (maxZ - minZ + 1), NamedTextColor.GRAY));
    }

    private void remove(CommandSender s, String[] args) {
        if (args.length < 2) {
            s.sendMessage(Component.text("Использование: /anyportal remove <id>", NamedTextColor.YELLOW));
            return;
        }
        PortalRegistry.Portal p = registry.byPrefix(args[1]);
        if (p == null) {
            s.sendMessage(Component.text("ℹ Портал \"" + args[1] + "\" не найден.", NamedTextColor.GRAY));
            return;
        }
        World w = Bukkit.getWorld(p.world);
        int n = 0;
        if (w != null) {
            for (Long cell : p.blocks) {
                org.bukkit.block.Block b = w.getBlockAt(PortalRegistry.unpackX(cell),
                        PortalRegistry.unpackY(cell), PortalRegistry.unpackZ(cell));
                if (b.getType() == org.bukkit.Material.NETHER_PORTAL) {
                    b.setType(org.bukkit.Material.AIR, false);
                    n++;
                }
            }
        }
        registry.remove(p.id);
        s.sendMessage(Component.text("✅ Портал [" + p.id + "] погашен (блоков: " + n + ").",
                NamedTextColor.GREEN));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            return Stream.of("list", "info", "remove", "removeall", "reload")
                    .filter(x -> x.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("info") || args[0].equalsIgnoreCase("remove"))) {
            return registry.all().keySet().stream()
                    .filter(id -> id.startsWith(args[1].toLowerCase(Locale.ROOT))).toList();
        }
        return List.of();
    }
}
