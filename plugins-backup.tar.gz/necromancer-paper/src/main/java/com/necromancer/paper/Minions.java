package com.necromancer.paper;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Легион: призыв миньонов, экипировка по уровню, учёт и гибель. */
public final class Minions {

    private static final Material[][] ARMOR = {
            {Material.COPPER_HELMET, Material.COPPER_CHESTPLATE, Material.COPPER_LEGGINGS, Material.COPPER_BOOTS},
            {Material.IRON_HELMET, Material.IRON_CHESTPLATE, Material.IRON_LEGGINGS, Material.IRON_BOOTS},
            {Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS},
            {Material.NETHERITE_HELMET, Material.NETHERITE_CHESTPLATE, Material.NETHERITE_LEGGINGS, Material.NETHERITE_BOOTS}
    };
    private static final Material[] SWORDS = {
            Material.COPPER_SWORD, Material.IRON_SWORD, Material.DIAMOND_SWORD, Material.NETHERITE_SWORD
    };
    private static final Material[] AXES = {
            Material.COPPER_AXE, Material.IRON_AXE, Material.DIAMOND_AXE, Material.NETHERITE_AXE
    };

    private static final String PET_KIND = "pet";

    private Minions() {}

    /* ---------- экипировка ---------- */

    public static void equip(LivingEntity mob, NecroMob type, int lvl) {
        EntityEquipment eq = mob.getEquipment();
        if (eq == null) return;
        // Миньоны ничего не роняют — гир не должен попадать в экономику.
        eq.setItemInMainHandDropChance(0f);
        eq.setItemInOffHandDropChance(0f);
        eq.setHelmetDropChance(0f);
        eq.setChestplateDropChance(0f);
        eq.setLeggingsDropChance(0f);
        eq.setBootsDropChance(0f);
        eq.setArmorContents(new ItemStack[]{null, null, null, null});
        eq.setItemInOffHand(null);
        if (lvl >= 1) {
            Material[] set = ARMOR[lvl - 1];
            eq.setHelmet(new ItemStack(set[0]));
            eq.setChestplate(new ItemStack(set[1]));
            eq.setLeggings(new ItemStack(set[2]));
            eq.setBoots(new ItemStack(set[3]));
        }
        if (type.archer) {
            ItemStack bow = new ItemStack(Material.BOW);
            if (lvl >= 1) {
                bow.addUnsafeEnchantment(Enchantment.POWER, lvl == 4 ? 5 : lvl);
                if (lvl >= 3) bow.addUnsafeEnchantment(Enchantment.FLAME, 2);
            }
            eq.setItemInMainHand(bow);
        } else {
            Material w;
            if (lvl <= 0) w = null;
            else if (type == NecroMob.DROWNED && lvl == 3) w = Material.TRIDENT;
            else if (type.axe) w = AXES[lvl - 1];
            else w = SWORDS[lvl - 1];
            eq.setItemInMainHand(w == null ? null : new ItemStack(w));
        }
    }

    /* ---------- призыв ---------- */

    public static Mob summon(NecromancerPlugin plugin, Player owner, ItemStack head, Location loc, UUID huntTarget) {
        if (countPets(plugin, owner.getUniqueId()) >= NecromancerPlugin.MAX_PETS) return null;
        NecroMob type = NecroItems.mobOf(head);
        int lvl = NecroItems.levelOf(head);

        Mob mob = (Mob) loc.getWorld().spawn(loc, type.clazz);
        mob.setRemoveWhenFarAway(false);
        mob.setPersistent(true);
        mob.setCanPickupItems(false);
        equip(mob, type, lvl);
        // Скрытая огнестойкость — легион не сгорает на солнце (решение пользователя).
        mob.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE,
                PotionEffect.INFINITE_DURATION, 0, false, false, false));

        Pet pet = new Pet(owner.getUniqueId(), type, lvl);
        if (huntTarget != null) {
            pet.mode = "hunt";
            pet.target = huntTarget;
        }
        pet.anchor = loc.clone();
        writePdc(mob, pet);
        plugin.pets().put(mob.getUniqueId(), pet);

        geyser(plugin, loc);
        Sound amb = type.archer ? Sound.ENTITY_SKELETON_AMBIENT : Sound.ENTITY_ZOMBIE_AMBIENT;
        playNear(loc, amb, 0.8f, 0.55f, 16);
        if (huntTarget != null) {
            Player tgt = Bukkit.getPlayer(huntTarget);
            if (tgt != null && tgt.isOnline()) mob.setTarget(tgt);
        }
        return mob;
    }

    /** Подобрать проходимую точку рядом с целью. */
    public static Location findSpawnSpot(Location around) {
        for (int i = 0; i < 6; i++) {
            Location l = around.clone().add(Math.random() * 4 - 2, 0, Math.random() * 4 - 2);
            if (l.getBlock().isPassable() && l.clone().add(0, 1, 0).getBlock().isPassable()) return l;
        }
        return around;
    }

    /** Серный гейзер: колонна частиц «выкапывания из-под земли». */
    public static void geyser(NecromancerPlugin plugin, Location loc) {
        for (int i = 0; i < 14; i++) {
            int k = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                try {
                    loc.getWorld().spawnParticle(Particle.GEYSER_PLUME,
                            loc.clone().add(0.5, 0, 0.5), 2, 0.2, k * 0.10, 0.2, 0.0);
                    if (k % 3 == 0) {
                        loc.getWorld().spawnParticle(Particle.SULFUR_BUBBLES,
                                loc.clone().add(0.5, 0.3, 0.5), 5, 0.3, 0.25, 0.3, 0.02);
                    }
                } catch (Throwable fallback) {
                    loc.getWorld().spawnParticle(Particle.SMOKE,
                            loc.clone().add(0.5, k * 0.12, 0.5), 4, 0.2, 0.05, 0.2, 0.01);
                    if (k % 4 == 0) {
                        loc.getWorld().spawnParticle(Particle.LAVA,
                                loc.clone().add(0.5, 0.3, 0.5), 2, 0.25, 0.2, 0.25, 0.0);
                    }
                }
            }, 2L * i);
        }
        playNear(loc, Sound.BLOCK_GRAVEL_BREAK, 0.9f, 0.5f, 16);
    }

    /** Локальный звук: слышат только игроки в радиусе, не весь сервер. */
    public static void playNear(Location loc, Sound s, float vol, float pitch, double radius) {
        for (Player p : loc.getWorld().getNearbyPlayers(loc, radius)) {
            p.playSound(loc, s, vol, pitch);
        }
    }

    /* ---------- PDC миньона (переживает рестарт) ---------- */

    public static void writePdc(Entity mob, Pet pet) {
        PersistentDataContainer pdc = mob.getPersistentDataContainer();
        pdc.set(NecroKeys.KIND, PersistentDataType.STRING, PET_KIND);
        pdc.set(NecroKeys.OWNER, PersistentDataType.STRING, pet.owner.toString());
        pdc.set(NecroKeys.MOB, PersistentDataType.STRING, pet.mob.name());
        pdc.set(NecroKeys.LVL, PersistentDataType.INTEGER, pet.lvl);
        pdc.set(NecroKeys.MODE, PersistentDataType.STRING, pet.mode);
        pdc.set(NecroKeys.TARGET, PersistentDataType.STRING, pet.target == null ? "" : pet.target.toString());
        Location a = pet.anchor;
        pdc.set(NecroKeys.ANCHOR, PersistentDataType.STRING,
                a == null ? "" : a.getWorld().getName() + ";" + a.getX() + ";" + a.getY() + ";" + a.getZ());
    }

    /** Восстановить миньона из PDC или null, если это не миньон. */
    public static Pet readPdc(Entity e) {
        PersistentDataContainer pdc = e.getPersistentDataContainer();
        if (!PET_KIND.equals(pdc.get(NecroKeys.KIND, PersistentDataType.STRING))) return null;
        try {
            UUID owner = UUID.fromString(pdc.get(NecroKeys.OWNER, PersistentDataType.STRING));
            NecroMob mob = NecroMob.valueOf(pdc.get(NecroKeys.MOB, PersistentDataType.STRING));
            int lvl = pdc.getOrDefault(NecroKeys.LVL, PersistentDataType.INTEGER, 0);
            Pet pet = new Pet(owner, mob, lvl);
            pet.mode = pdc.getOrDefault(NecroKeys.MODE, PersistentDataType.STRING, "patrol");
            String t = pdc.get(NecroKeys.TARGET, PersistentDataType.STRING);
            pet.target = t == null || t.isEmpty() ? null : UUID.fromString(t);
            String a = pdc.get(NecroKeys.ANCHOR, PersistentDataType.STRING);
            if (a != null && !a.isEmpty()) {
                String[] p = a.split(";");
                World w = Bukkit.getWorld(p[0]);
                if (w != null) {
                    pet.anchor = new Location(w, Double.parseDouble(p[1]), Double.parseDouble(p[2]), Double.parseDouble(p[3]));
                }
            }
            return pet;
        } catch (Exception ex) {
            return null;
        }
    }

    public static void scanAllWorlds(NecromancerPlugin plugin) {
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (plugin.pets().containsKey(e.getUniqueId())) continue;
                Pet pet = readPdc(e);
                if (pet != null) plugin.pets().put(e.getUniqueId(), pet);
            }
        }
    }

    /* ---------- управление ---------- */

    public static int countPets(NecromancerPlugin plugin, UUID owner) {
        int n = 0;
        for (Pet p : plugin.pets().values()) {
            if (p.owner.equals(owner)) n++;
        }
        return n;
    }

    /** Убить всех миньонов владельца (обращение в прах). */
    public static void killAll(NecromancerPlugin plugin, UUID owner, boolean poof) {
        Iterator<Map.Entry<UUID, Pet>> it = plugin.pets().entrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            if (!e.getValue().owner.equals(owner)) continue;
            it.remove();
            Entity mob = Bukkit.getEntity(e.getKey());
            if (mob instanceof LivingEntity le && le.isValid()) {
                if (poof) {
                    le.getWorld().spawnParticle(Particle.LARGE_SMOKE,
                            le.getLocation().add(0, 1, 0), 25, 0.4, 0.7, 0.4, 0.02);
                    le.getWorld().spawnParticle(Particle.SMOKE,
                            le.getLocation().add(0, 1, 0), 20, 0.5, 0.9, 0.5, 0.02);
                    playNear(le.getLocation(), Sound.ENTITY_WITHER_HURT, 0.4f, 1.4f, 16);
                }
                le.remove();
            }
        }
    }
}
